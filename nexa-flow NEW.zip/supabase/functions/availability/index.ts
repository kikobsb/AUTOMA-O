// POST  Authorization: Bearer nxf_...   (permissão appointments:read)
// { service_id, from: "YYYY-MM-DD", to: "YYYY-MM-DD", professional_id?, step_minutes? } -> horários livres
import { admin, authApiKey, bad, dbError, isUuid, json, readJson } from '../_shared/http.ts';

const DATE = /^\d{4}-\d{2}-\d{2}$/;

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return json(req, 204, null);
  const auth = await authApiKey(req, 'appointments:read');
  if (auth instanceof Response) return auth;
  const b = await readJson(req);
  if (b instanceof Response) return b;

  if (!isUuid(b.service_id)) return bad(req, 'service_id');
  if (typeof b.from !== 'string' || !DATE.test(b.from)) return bad(req, 'from');
  const to = typeof b.to === 'string' ? b.to : b.from;
  if (!DATE.test(to)) return bad(req, 'to');
  if (b.professional_id != null && !isUuid(b.professional_id)) return bad(req, 'professional_id');
  const step = b.step_minutes == null ? 30 : Number(b.step_minutes);
  if (!Number.isInteger(step)) return bad(req, 'step_minutes');

  const { data, error } = await admin().rpc('get_available_slots', {
    p_workspace: auth.workspaceId, p_service: b.service_id, p_from: b.from, p_to: to,
    p_professional: b.professional_id ?? null, p_step_minutes: step,
  });
  if (error) return dbError(req, error);
  return json(req, 200, { slots: (data ?? []).slice(0, 200) });
});
