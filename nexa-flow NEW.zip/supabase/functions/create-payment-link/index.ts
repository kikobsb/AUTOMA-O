// POST  Authorization: Bearer <JWT do usuário gestor/admin>  OU  Bearer nxf_... (permissão payments:write)
// { workspace_id?, contact_id, amount_cents, description, deal_id? }  -> { payment_id, payment_link }
import { admin, authApiKey, authUser, bad, cors, isUuid, json, readJson } from '../_shared/http.ts';
import { bearerToken, buildCheckoutBody, clampStr, extractCheckoutUrl, signPaymentId } from '../_shared/logic.ts';

const IP_API = Deno.env.get('INFINITEPAY_API_BASE') ?? 'https://api.infinitepay.io';
const WEBHOOK_SECRET = Deno.env.get('INFINITEPAY_WEBHOOK_SECRET')!;       // segredo nosso, para assinar a URL do webhook
const PUBLIC_FN_BASE = Deno.env.get('PUBLIC_FUNCTIONS_URL')!;              // https://<ref>.supabase.co/functions/v1
const APP_URL = Deno.env.get('APP_URL');                                    // opcional: para onde o cliente volta após pagar

const MIN_CENTS = 100;        // R$ 1,00
const MAX_CENTS = 5_000_000;  // R$ 50.000,00 por link (trava de segurança)

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(req) });

  const token = bearerToken(req.headers.get('authorization'));
  const auth = token?.startsWith('nxf_') ? await authApiKey(req, 'payments:write') : await authUser(req);
  if (auth instanceof Response) return auth;
  if (auth.kind === 'user' && auth.role === 'atendente') return json(req, 403, { error: 'forbidden' });

  const b = await readJson(req);
  if (b instanceof Response) return b;
  // o workspace vem SEMPRE da credencial; um workspace_id no corpo diferente é tentativa de cruzar tenants
  if (b.workspace_id != null && b.workspace_id !== auth.workspaceId) return json(req, 403, { error: 'forbidden' });

  if (!isUuid(b.contact_id)) return bad(req, 'contact_id');
  if (b.deal_id != null && !isUuid(b.deal_id)) return bad(req, 'deal_id');
  const cents = b.amount_cents;
  if (typeof cents !== 'number' || !Number.isInteger(cents) || cents < MIN_CENTS || cents > MAX_CENTS) return bad(req, 'amount_cents');
  const description = clampStr(b.description, 120);
  if (!description) return bad(req, 'description');

  const db = admin();
  const { data: ws } = await db.from('workspaces').select('id, infinitepay_handle, status').eq('id', auth.workspaceId).maybeSingle();
  if (!ws || ws.status !== 'active') return json(req, 403, { error: 'workspace_inactive' });
  if (!ws.infinitepay_handle) return json(req, 422, { error: 'infinitepay_handle_missing', detail: 'Cadastre a InfiniteTag em Configurações.' });

  const { data: contact } = await db.from('contacts').select('id, name, phone').eq('id', b.contact_id).eq('workspace_id', auth.workspaceId).maybeSingle();
  if (!contact) return json(req, 404, { error: 'contact_not_found' });
  if (b.deal_id) {
    const { data: deal } = await db.from('deals').select('id').eq('id', b.deal_id).eq('workspace_id', auth.workspaceId).maybeSingle();
    if (!deal) return json(req, 404, { error: 'deal_not_found' });
  }

  const { data: pay, error: insErr } = await db.from('payments').insert({
    workspace_id: auth.workspaceId, contact_id: contact.id, deal_id: b.deal_id ?? null,
    amount: cents / 100, method: 'checkout', status: 'pendente', gateway: 'infinitepay', description,
  }).select('id').single();
  if (insErr || !pay) { console.error('payment_insert', insErr?.message); return json(req, 500, { error: 'internal' }); }

  const sig = await signPaymentId(WEBHOOK_SECRET, pay.id);
  const webhookUrl = `${PUBLIC_FN_BASE}/infinitepay-webhook?p=${pay.id}&sig=${sig}`;

  let link: string | null = null;
  try {
    const r = await fetch(`${IP_API}/invoices/public/checkout/links`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(buildCheckoutBody({
        handle: ws.infinitepay_handle, paymentId: pay.id, amountCents: cents, description, webhookUrl,
        redirectUrl: APP_URL, customer: { name: contact.name, phone: contact.phone ?? undefined },
      })),
      signal: AbortSignal.timeout(15_000),
    });
    if (r.ok) link = extractCheckoutUrl(await r.json().catch(() => null));
    else console.error('infinitepay_create_link', r.status);
  } catch (e) {
    console.error('infinitepay_create_link_exception', (e as Error).message);
  }

  if (!link) {
    await db.from('payments').update({ status: 'falhou' }).eq('id', pay.id);
    return json(req, 502, { error: 'gateway_error', detail: 'A InfinitePay não devolveu o link. Confira a InfiniteTag e tente de novo.' });
  }
  await db.from('payments').update({ payment_link: link }).eq('id', pay.id);
  return json(req, 201, { payment_id: pay.id, payment_link: link });
});
