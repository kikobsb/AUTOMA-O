// POST  Authorization: Bearer nxf_...   (permissão messages:write)
// Recebe uma mensagem do WhatsApp/Instagram (via n8n), grava e devolve o contexto para a IA.
import { admin, authApiKey, bad, dbError, json, readJson } from '../_shared/http.ts';
import { clampStr } from '../_shared/logic.ts';

const CHANNELS = ['whatsapp', 'instagram', 'facebook', 'telegram', 'email', 'webchat'];

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return json(req, 204, null);
  const auth = await authApiKey(req, 'messages:write');
  if (auth instanceof Response) return auth;
  const b = await readJson(req);
  if (b instanceof Response) return b;

  const channel = clampStr(b.channel, 20);
  const externalContact = clampStr(b.external_contact_id, 120);
  const externalId = clampStr(b.external_id, 200);
  const content = typeof b.content === 'string' ? b.content : null;
  if (!channel || !CHANNELS.includes(channel)) return bad(req, 'channel');
  if (!externalContact) return bad(req, 'external_contact_id');
  if (!externalId) return bad(req, 'external_id');
  if (content === null || content.length > 8000) return bad(req, 'content');

  const { data, error } = await admin().rpc('ingest_incoming_message', {
    p_workspace: auth.workspaceId,
    p_channel: channel,
    p_external_contact_id: externalContact,
    p_contact_name: clampStr(b.contact_name, 120),
    p_phone: clampStr(b.phone, 30),
    p_content: content,
    p_external_id: externalId,
    p_message_type: clampStr(b.message_type, 20) ?? 'text',
    p_attachment_url: clampStr(b.attachment_url, 1000),
  });
  if (error) return dbError(req, error);
  return json(req, 200, data);
});
