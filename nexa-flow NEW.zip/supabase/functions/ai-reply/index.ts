// POST  Authorization: Bearer nxf_...   (permissão messages:write)
// Grava a resposta gerada pela IA. O banco recusa se um humano assumiu a conversa nesse meio tempo.
import { admin, authApiKey, bad, dbError, isUuid, json, readJson } from '../_shared/http.ts';
import { clampStr } from '../_shared/logic.ts';

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return json(req, 204, null);
  const auth = await authApiKey(req, 'messages:write');
  if (auth instanceof Response) return auth;
  const b = await readJson(req);
  if (b instanceof Response) return b;

  if (!isUuid(b.conversation_id)) return bad(req, 'conversation_id');
  const content = clampStr(b.content, 8000);
  if (!content) return bad(req, 'content');

  const { data, error } = await admin().rpc('ingest_ai_reply', {
    p_workspace: auth.workspaceId,
    p_conversation: b.conversation_id,
    p_content: content,
    p_needs_human: b.needs_human === true,
    p_external_id: clampStr(b.external_id, 200),
  });
  if (error) return dbError(req, error);
  return json(req, 200, data); // { skipped: 'ai_paused' } => NÃO envie a resposta ao cliente
});
