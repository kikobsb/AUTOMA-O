// Chamado pela InfinitePay quando um pagamento é concluído. NÃO confia no corpo recebido:
//  1) a URL traz ?p=<payment_id>&sig=<HMAC> gerado por nós (prova que a URL é nossa);
//  2) o pagamento é conferido de novo na API da InfinitePay (payment_check);
//  3) só então confirm_payment() (idempotente) marca como pago, validando valor.
import { admin } from '../_shared/http.ts';
import { evaluatePaymentCheck, isUuid, verifyPaymentSig } from '../_shared/logic.ts';

const IP_API = Deno.env.get('INFINITEPAY_API_BASE') ?? 'https://api.infinitepay.io';
const WEBHOOK_SECRET = Deno.env.get('INFINITEPAY_WEBHOOK_SECRET')!;

const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

Deno.serve(async req => {
  if (req.method !== 'POST') return reply(405, { error: 'method_not_allowed' });
  const url = new URL(req.url);
  const paymentId = url.searchParams.get('p') ?? '';
  if (!isUuid(paymentId) || !(await verifyPaymentSig(WEBHOOK_SECRET, paymentId, url.searchParams.get('sig')))) {
    return reply(401, { error: 'invalid_signature' });
  }

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return reply(400, { error: 'invalid_json' }); }
  // o order_nsu que a InfinitePay devolve tem de ser o NOSSO payment id
  if (body.order_nsu !== paymentId) return reply(400, { error: 'order_mismatch' });

  const db = admin();
  const { data: pay } = await db.from('payments').select('id, workspace_id, amount, status').eq('id', paymentId).maybeSingle();
  if (!pay) return reply(404, { error: 'payment_not_found' });
  if (pay.status === 'pago') return reply(200, { ok: true, already_paid: true });

  const { data: ws } = await db.from('workspaces').select('infinitepay_handle').eq('id', pay.workspace_id).maybeSingle();
  if (!ws?.infinitepay_handle) return reply(422, { error: 'handle_missing' });

  const expectedCents = Math.round(Number(pay.amount) * 100);

  // verificação independente no gateway
  let check: unknown = null;
  try {
    const r = await fetch(`${IP_API}/invoices/public/checkout/payment_check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        handle: ws.infinitepay_handle, order_nsu: paymentId,
        transaction_nsu: body.transaction_nsu, slug: body.invoice_slug,
      }),
      signal: AbortSignal.timeout(15_000),
    });
    if (!r.ok) { console.error('payment_check_status', r.status); return reply(502, { error: 'gateway_unreachable' }); } // 5xx => a InfinitePay reenvia
    check = await r.json();
  } catch (e) {
    console.error('payment_check_exception', (e as Error).message);
    return reply(502, { error: 'gateway_unreachable' });
  }

  const verdict = evaluatePaymentCheck(check, expectedCents);
  if (!verdict.ok) { console.warn('payment_rejected', paymentId, verdict.reason); return reply(422, { error: 'not_confirmed', reason: verdict.reason }); }

  const { error } = await db.rpc('confirm_payment', {
    p_payment: paymentId,
    p_amount_cents: expectedCents,
    p_paid_amount_cents: verdict.paidCents,
    p_gateway_ref: typeof body.transaction_nsu === 'string' ? body.transaction_nsu : null,
    p_receipt_url: typeof body.receipt_url === 'string' && body.receipt_url.startsWith('https://') ? body.receipt_url : null,
    p_capture_method: typeof body.capture_method === 'string' ? body.capture_method : 'checkout',
  });
  if (error) { console.error('confirm_payment', error.message); return reply(error.code === 'P0001' ? 422 : 500, { error: 'confirm_failed' }); }
  return reply(200, { ok: true });
});
