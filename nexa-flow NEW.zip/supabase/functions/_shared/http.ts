import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';
import { bearerToken, isUuid } from './logic.ts';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ANON = Deno.env.get('SUPABASE_ANON_KEY')!;

// Origens do navegador autorizadas (só create-payment-link é chamada pelo app). Ex.: "https://app.seudominio.com"
const ALLOWED_ORIGINS = (Deno.env.get('ALLOWED_ORIGINS') ?? '').split(',').map(s => s.trim()).filter(Boolean);

export function cors(req: Request): Record<string, string> {
  const origin = req.headers.get('origin') ?? '';
  const ok = ALLOWED_ORIGINS.includes(origin);
  return {
    ...(ok ? { 'Access-Control-Allow-Origin': origin, Vary: 'Origin' } : {}),
    'Access-Control-Allow-Headers': 'authorization, content-type, apikey, x-client-info',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
}

export function json(req: Request, status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...cors(req) } });
}

export const admin = (): SupabaseClient => createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } });

export type ApiCtx = { kind: 'api_key'; workspaceId: string; permissions: string[] };
export type UserCtx = { kind: 'user'; workspaceId: string; role: 'admin' | 'gestor' | 'atendente'; profileId: string };

/** Autentica por chave de API (n8n). Devolve Response de erro ou o contexto. */
export async function authApiKey(req: Request, permission: string): Promise<ApiCtx | Response> {
  const token = bearerToken(req.headers.get('authorization'));
  if (!token) return json(req, 401, { error: 'unauthorized' });
  const { data, error } = await admin().rpc('verify_api_key', { p_key: token });
  const row = Array.isArray(data) ? data[0] : null;
  if (error || !row) return json(req, 401, { error: 'unauthorized' });
  if (!row.permissions?.includes(permission)) return json(req, 403, { error: 'forbidden', missing_permission: permission });
  return { kind: 'api_key', workspaceId: row.workspace_id, permissions: row.permissions };
}

/** Autentica um usuário logado (JWT do Supabase Auth) e resolve workspace/papel pelo banco. */
export async function authUser(req: Request): Promise<UserCtx | Response> {
  const token = bearerToken(req.headers.get('authorization'));
  if (!token) return json(req, 401, { error: 'unauthorized' });
  const userClient = createClient(SUPABASE_URL, ANON, { auth: { persistSession: false }, global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: u, error } = await userClient.auth.getUser(token);
  if (error || !u.user) return json(req, 401, { error: 'unauthorized' });
  const { data: p } = await admin().from('profiles').select('id, workspace_id, role, is_active').eq('auth_user_id', u.user.id).maybeSingle();
  if (!p || !p.is_active) return json(req, 403, { error: 'forbidden' });
  return { kind: 'user', workspaceId: p.workspace_id, role: p.role, profileId: p.id };
}

export async function readJson(req: Request): Promise<Record<string, unknown> | Response> {
  if (req.method !== 'POST') return json(req, 405, { error: 'method_not_allowed' });
  const len = Number(req.headers.get('content-length') ?? '0');
  if (len > 64_000) return json(req, 413, { error: 'payload_too_large' });
  try {
    const b = await req.json();
    if (!b || typeof b !== 'object' || Array.isArray(b)) return json(req, 400, { error: 'invalid_json' });
    return b as Record<string, unknown>;
  } catch {
    return json(req, 400, { error: 'invalid_json' });
  }
}

export const bad = (req: Request, field: string) => json(req, 400, { error: 'invalid_field', field });
export { isUuid };

/** Erros de negócio levantados pelo Postgres (P0001) viram 4xx legível; o resto vira 500 sem vazar detalhes. */
export function dbError(req: Request, err: { message: string; code?: string }): Response {
  if (err.code === 'P0001') return json(req, 422, { error: err.message.split(':')[0].trim(), detail: err.message });
  if (err.code === '42501') return json(req, 403, { error: 'forbidden' });
  console.error('db_error', err.code, err.message);
  return json(req, 500, { error: 'internal' });
}
