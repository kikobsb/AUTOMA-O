// Lógica pura (sem Deno, sem rede): testável com `node --experimental-strip-types`.

export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const isUuid = (v: unknown): v is string => typeof v === 'string' && UUID_RE.test(v);

export function bearerToken(header: string | null): string | null {
  if (!header) return null;
  const m = /^Bearer\s+(\S+)$/i.exec(header.trim());
  return m ? m[1] : null;
}

const enc = new TextEncoder();

export async function hmacHex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Comparação em tempo constante (strings de mesmo tamanho; tamanhos diferentes = falso). */
export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** O webhook da InfinitePay não é assinado. Nós assinamos a URL que entregamos a ela. */
export const signPaymentId = (secret: string, paymentId: string) => hmacHex(secret, `payment:${paymentId}`);

export async function verifyPaymentSig(secret: string, paymentId: string, sig: string | null): Promise<boolean> {
  if (!sig || !isUuid(paymentId)) return false;
  return timingSafeEqual(await signPaymentId(secret, paymentId), sig.toLowerCase());
}

export interface CheckoutInput {
  handle: string;
  paymentId: string;
  amountCents: number;
  description: string;
  webhookUrl: string;
  redirectUrl?: string;
  customer?: { name?: string; phone?: string };
}

export function buildCheckoutBody(i: CheckoutInput): Record<string, unknown> {
  const body: Record<string, unknown> = {
    handle: i.handle,
    order_nsu: i.paymentId, // nosso id é a referência: é com ele que conciliamos
    webhook_url: i.webhookUrl,
    items: [{ quantity: 1, price: i.amountCents, description: i.description.slice(0, 120) }],
  };
  if (i.redirectUrl) body.redirect_url = i.redirectUrl;
  if (i.customer?.name || i.customer?.phone) {
    body.customer = { ...(i.customer.name ? { name: i.customer.name } : {}), ...(i.customer.phone ? { phone_number: i.customer.phone } : {}) };
  }
  return body;
}

/** A resposta de criação de link já variou de nome de campo; aceita os candidatos conhecidos, só https. */
export function extractCheckoutUrl(resp: unknown): string | null {
  if (!resp || typeof resp !== 'object') return null;
  const r = resp as Record<string, unknown>;
  for (const k of ['url', 'link', 'checkout_url', 'payment_url', 'invoice_url']) {
    const v = r[k];
    if (typeof v === 'string' && /^https:\/\//i.test(v)) return v;
  }
  if (r.data && typeof r.data === 'object') return extractCheckoutUrl(r.data);
  return null;
}

export const toCents = (v: unknown): number | null =>
  typeof v === 'number' && Number.isInteger(v) && v >= 0 ? v : null;

export interface PaymentCheckResult { ok: boolean; reason?: string; paidCents?: number }

/**
 * Decide se a confirmação do gateway vale. Regras:
 *  - gateway precisa dizer explicitamente `paid === true`;
 *  - valor pago em centavos (inteiro) precisa ser >= valor da cobrança que NÓS criamos.
 */
export function evaluatePaymentCheck(resp: unknown, expectedCents: number): PaymentCheckResult {
  if (!resp || typeof resp !== 'object') return { ok: false, reason: 'resposta inválida do gateway' };
  const r = resp as Record<string, unknown>;
  if (r.success === false) return { ok: false, reason: 'gateway recusou a consulta' };
  if (r.paid !== true) return { ok: false, reason: 'gateway diz que não está pago' };
  const paid = toCents(r.paid_amount) ?? toCents(r.amount);
  if (paid === null) return { ok: false, reason: 'gateway não informou o valor pago' };
  if (paid < expectedCents) return { ok: false, reason: `valor pago (${paid}) menor que o cobrado (${expectedCents})` };
  return { ok: true, paidCents: paid };
}

export function clampStr(v: unknown, max: number): string | null {
  if (typeof v !== 'string') return null;
  const t = v.trim();
  return t.length === 0 || t.length > max ? null : t;
}

export const REAIS_TO_CENTS = (reais: number) => Math.round(reais * 100);
