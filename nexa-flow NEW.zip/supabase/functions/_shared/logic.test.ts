import assert from 'node:assert/strict';
import {
  bearerToken, buildCheckoutBody, evaluatePaymentCheck, extractCheckoutUrl, isUuid, signPaymentId, timingSafeEqual, verifyPaymentSig,
} from './logic.ts';

const ID = '3f2b8a4e-1c7d-4e5a-9b6f-0a1b2c3d4e5f';
let n = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); n++; console.log('ok -', name); };

await t('bearerToken', () => {
  assert.equal(bearerToken('Bearer abc'), 'abc');
  assert.equal(bearerToken('bearer abc'), 'abc');
  assert.equal(bearerToken('Basic abc'), null);
  assert.equal(bearerToken('Bearer a b'), null);
  assert.equal(bearerToken(null), null);
});
await t('isUuid', () => {
  assert.ok(isUuid(ID)); assert.ok(!isUuid('x')); assert.ok(!isUuid(`${ID}'; drop`)); assert.ok(!isUuid(5));
});
await t('assinatura do webhook: aceita a correta', async () => {
  const sig = await signPaymentId('s3cret', ID);
  assert.equal(sig.length, 64);
  assert.ok(await verifyPaymentSig('s3cret', ID, sig));
  assert.ok(await verifyPaymentSig('s3cret', ID, sig.toUpperCase()));
});
await t('assinatura: rejeita segredo errado, id trocado, vazio e lixo', async () => {
  const sig = await signPaymentId('s3cret', ID);
  assert.ok(!(await verifyPaymentSig('outro', ID, sig)));
  assert.ok(!(await verifyPaymentSig('s3cret', '00000000-0000-4000-8000-000000000000', sig)));
  assert.ok(!(await verifyPaymentSig('s3cret', ID, null)));
  assert.ok(!(await verifyPaymentSig('s3cret', ID, '')));
  assert.ok(!(await verifyPaymentSig('s3cret', ID, 'a'.repeat(64))));
  assert.ok(!(await verifyPaymentSig('s3cret', 'nao-uuid', sig)));
});
await t('timingSafeEqual', () => {
  assert.ok(timingSafeEqual('abc', 'abc')); assert.ok(!timingSafeEqual('abc', 'abd')); assert.ok(!timingSafeEqual('abc', 'ab'));
});
await t('payment_check: pago com valor exato', () => {
  assert.deepEqual(evaluatePaymentCheck({ success: true, paid: true, amount: 15000, paid_amount: 15000 }, 15000), { ok: true, paidCents: 15000 });
});
await t('payment_check: pago a maior (juros de parcelamento) é aceito', () => {
  assert.equal(evaluatePaymentCheck({ paid: true, amount: 15000, paid_amount: 15600 }, 15000).ok, true);
});
await t('payment_check: PAGO A MENOR é rejeitado (fraude clássica)', () => {
  const r = evaluatePaymentCheck({ paid: true, amount: 15000, paid_amount: 100 }, 15000);
  assert.equal(r.ok, false);
});
await t('payment_check: paid=false, ausente, string "true" e lixo são rejeitados', () => {
  for (const v of [{ paid: false, paid_amount: 15000 }, { paid_amount: 15000 }, { paid: 'true', paid_amount: 15000 }, null, 'x', 42, { success: false, paid: true, paid_amount: 15000 }]) {
    assert.equal(evaluatePaymentCheck(v, 15000).ok, false, JSON.stringify(v));
  }
});
await t('payment_check: valor fracionado/negativo/texto é rejeitado', () => {
  for (const pa of [150.5, -1, '15000', null, undefined, NaN]) {
    assert.equal(evaluatePaymentCheck({ paid: true, paid_amount: pa }, 15000).ok, false, String(pa));
  }
});
await t('extractCheckoutUrl: aceita https em vários campos, rejeita http/javascript', () => {
  assert.equal(extractCheckoutUrl({ url: 'https://x.com/a' }), 'https://x.com/a');
  assert.equal(extractCheckoutUrl({ link: 'https://x.com/b' }), 'https://x.com/b');
  assert.equal(extractCheckoutUrl({ data: { checkout_url: 'https://x.com/c' } }), 'https://x.com/c');
  assert.equal(extractCheckoutUrl({ url: 'http://x.com' }), null);
  assert.equal(extractCheckoutUrl({ url: 'javascript:alert(1)' }), null);
  assert.equal(extractCheckoutUrl(null), null);
  assert.equal(extractCheckoutUrl({}), null);
});
await t('buildCheckoutBody: centavos inteiros, order_nsu = id, descrição truncada', () => {
  const b = buildCheckoutBody({ handle: 'clinica', paymentId: ID, amountCents: 15000, description: 'x'.repeat(300), webhookUrl: 'https://f/w?p=1', customer: { name: 'Ana', phone: '+5561999999999' } }) as any;
  assert.equal(b.order_nsu, ID);
  assert.equal(b.items[0].price, 15000);
  assert.equal(b.items[0].description.length, 120);
  assert.equal(b.customer.name, 'Ana');
  assert.equal(b.handle, 'clinica');
});
console.log(`\n${n} testes passaram`);
