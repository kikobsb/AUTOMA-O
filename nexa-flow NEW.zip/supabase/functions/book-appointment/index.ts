// POST  Authorization: Bearer nxf_...   (permissão appointments:write)
// { contact_id, service_id, professional_id, starts_at (ISO), notes? }
// A IA só consegue marcar horário que get_available_slots oferece; o banco revalida e impede choque.
import { admin, authApiKey, bad, dbError, isUuid, json, readJson } from '../_shared/http.ts';
import { clampStr } from '../_shared/logic.ts';

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return json(req, 204, null);
  const auth = await authApiKey(req, 'appointments:write');
  if (auth instanceof Response) return auth;
  const b = await readJson(req);
  if (b instanceof Response) return b;

  if (!isUuid(b.contact_id)) return bad(req, 'contact_id');
  if (!isUuid(b.service_id)) return bad(req, 'service_id');
  if (!isUuid(b.professional_id)) return bad(req, 'professional_id');
  if (typeof b.starts_at !== 'string' || Number.isNaN(Date.parse(b.starts_at))) return bad(req, 'starts_at');

  const { data, error } = await admin().rpc('book_appointment', {
    p_workspace: auth.workspaceId, p_contact: b.contact_id, p_service: b.service_id,
    p_professional: b.professional_id, p_starts_at: new Date(b.starts_at).toISOString(),
    p_source: 'ia', p_notes: clampStr(b.notes, 500), p_created_by: null,
  });
  if (error) {
    if (/slot_unavailable/.test(error.message)) return json(req, 409, { error: 'slot_unavailable' });
    return dbError(req, error);
  }
  return json(req, 201, { appointment: data });
});
