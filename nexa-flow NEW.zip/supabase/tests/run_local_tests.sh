#!/usr/bin/env bash
# Roda a bateria contra um Postgres LOCAL (nao usa o Supabase real).
# Uso: PGHOST=127.0.0.1 PGPORT=54329 PGUSER=postgres ./run_local_tests.sh
set -uo pipefail
cd "$(dirname "$0")"
export PGHOST="${PGHOST:-127.0.0.1}" PGPORT="${PGPORT:-5432}" PGUSER="${PGUSER:-postgres}"
DB=nexa_test
psql -q -c "DROP DATABASE IF EXISTS $DB" -c "CREATE DATABASE $DB" >/dev/null 2>&1
for f in 00_supabase_stub.sql ../migrations/*.sql 01_security_and_flows.test.sql; do
  echo "-- $f"
  out=$(psql -q -v ON_ERROR_STOP=1 -d $DB -f "$f" 2>&1); rc=$?
  echo "$out" | grep -v "NOTICE:  policy\|NOTICE:  trigger\|does not exist, skipping" | sed 's/^psql:[^ ]* //' || true
  if [ $rc -ne 0 ]; then echo ">>> ERRO em $f (rc=$rc)"; exit 1; fi
done
