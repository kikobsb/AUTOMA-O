-- Bateria de testes (Postgres real + stub do Supabase). Falha com EXCEPTION se algo quebrar.
-- IDs fixos
\set A    '''a0000000-0000-0000-0000-000000000001'''
\set alice '''11111111-1111-1111-1111-111111111111'''
\set bob   '''22222222-2222-2222-2222-222222222222'''
\set carol '''33333333-3333-3333-3333-333333333333'''
\set dave  '''44444444-4444-4444-4444-444444444444'''
\set erin  '''55555555-5555-5555-5555-555555555555'''

-- ---------- helpers ----------
CREATE OR REPLACE FUNCTION t_ok(cond boolean, msg text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF cond IS NOT TRUE THEN RAISE EXCEPTION 'FALHOU: %', msg; END IF; RAISE NOTICE 'ok   %', msg; END $$;

-- executa SQL como usuario logado e exige ERRO (qualquer um) ; retorna a mensagem
CREATE OR REPLACE FUNCTION t_fails(q text, msg text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN EXECUTE q; EXCEPTION WHEN OTHERS THEN RAISE NOTICE 'ok   % [%]', msg, left(SQLERRM, 70); RETURN; END;
  RAISE EXCEPTION 'FALHOU (deveria negar): %', msg;
END $$;

-- executa DML e retorna linhas afetadas
CREATE OR REPLACE FUNCTION t_rows(q text) RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE n bigint; BEGIN EXECUTE q; GET DIAGNOSTICS n = ROW_COUNT; RETURN n; END $$;

CREATE OR REPLACE FUNCTION t_as(uid text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN PERFORM set_config('request.jwt.claim.sub', uid, true); EXECUTE 'SET LOCAL ROLE authenticated'; END $$;

-- ---------- SETUP (superuser) ----------
INSERT INTO auth.users (id, email, email_confirmed_at) VALUES
  (:alice, 'alice@test.dev', now()), (:bob, 'bob@test.dev', now()),
  (:carol, 'carol@test.dev', now()), (:dave, 'dave@test.dev', NULL), (:erin, 'erin@test.dev', now());
UPDATE profiles SET email = 'alice@test.dev' WHERE id = 'b0000000-0000-0000-0000-000000000001'; -- admin
UPDATE profiles SET email = 'bob@test.dev'   WHERE id = 'b0000000-0000-0000-0000-000000000003'; -- atendente
INSERT INTO profiles (workspace_id, name, email, role) VALUES (:A, 'Dave Convidado', 'dave@test.dev', 'atendente');

-- =====================================================================
\echo '== 1. Login: vinculo com convite =='
DO $$ DECLARE r record; n int; BEGIN
  PERFORM t_as('11111111-1111-1111-1111-111111111111');
  SELECT count(*) INTO n FROM claim_profile(); PERFORM t_ok(n = 1, 'alice assume o convite de admin');
  PERFORM t_ok(app_role() = 'admin' AND app_workspace_id() = 'a0000000-0000-0000-0000-000000000001', 'alice = admin do workspace A');
  RESET ROLE; PERFORM t_as('22222222-2222-2222-2222-222222222222');
  SELECT count(*) INTO n FROM claim_profile(); PERFORM t_ok(n = 1 AND app_role() = 'atendente', 'bob assume convite como atendente');
  RESET ROLE; PERFORM t_as('44444444-4444-4444-4444-444444444444');
  SELECT count(*) INTO n FROM claim_profile(); PERFORM t_ok(n = 0, 'dave (e-mail NAO confirmado) NAO sequestra convite');
  RESET ROLE; PERFORM t_as('55555555-5555-5555-5555-555555555555');
  SELECT count(*) INTO n FROM claim_profile(); PERFORM t_ok(n = 0, 'erin (sem convite) nao entra em nenhum workspace');
  PERFORM t_ok(app_workspace_id() IS NULL, 'erin sem workspace nao enxerga nada');
END $$;

\echo '== 2. Onboarding: criar workspace =='
DO $$ DECLARE ws uuid; n int; BEGIN
  PERFORM t_as('33333333-3333-3333-3333-333333333333');
  ws := create_workspace('Clínica Carol Estética');
  PERFORM t_ok(app_role() = 'admin' AND app_workspace_id() = ws, 'carol cria workspace B e vira admin');
  SELECT count(*) INTO n FROM stages; PERFORM t_ok(n = 7, 'funil padrao com 7 etapas criado');
  PERFORM t_fails($q$SELECT create_workspace('Outro')$q$, 'carol nao cria segundo workspace');
  RESET ROLE; PERFORM t_as('44444444-4444-4444-4444-444444444444');
  PERFORM t_fails($q$SELECT create_workspace('Dave Inc')$q$, 'e-mail nao confirmado nao cria workspace');
  RESET ROLE; PERFORM t_as('11111111-1111-1111-1111-111111111111');
  PERFORM t_fails($q$SELECT create_workspace('Alice 2')$q$, 'quem ja e membro nao cria outro workspace');
END $$;

\echo '== 3. Isolamento entre clinicas (carol = admin de B tenta ver/alterar A) =='
DO $$ DECLARE t text; n bigint; BEGIN
  PERFORM t_as('33333333-3333-3333-3333-333333333333');
  FOREACH t IN ARRAY ARRAY['contacts','conversations','messages','deals','deal_activities','payments','lead_attributions',
      'quick_replies','ai_agents','automations','campaigns','webhooks','api_keys'] LOOP
    EXECUTE format('SELECT count(*) FROM %I', t) INTO n;
    PERFORM t_ok(n = 0, 'carol ve 0 linhas de '||t||' do workspace A');
  END LOOP;
  SELECT count(*) INTO n FROM workspaces; PERFORM t_ok(n = 1, 'carol ve so o proprio workspace');
  SELECT count(*) INTO n FROM profiles;   PERFORM t_ok(n = 1, 'carol ve so a propria equipe');
  PERFORM t_fails($q$INSERT INTO contacts (workspace_id, name) VALUES ('a0000000-0000-0000-0000-000000000001','Invasor')$q$, 'nao cria contato no workspace A');
  PERFORM t_ok(t_rows($q$UPDATE contacts SET name='HACK'$q$) = 0, 'update em contatos de A afeta 0 linhas');
  PERFORM t_ok(t_rows($q$DELETE FROM contacts$q$) = 0, 'delete em contatos de A afeta 0 linhas');
  PERFORM t_ok(t_rows($q$UPDATE workspaces SET name='HACK' WHERE id='a0000000-0000-0000-0000-000000000001'$q$) = 0, 'nao renomeia workspace A');
  PERFORM t_fails($q$INSERT INTO messages (workspace_id, conversation_id, sender_type, content)
     VALUES ((SELECT app_workspace_id()), 'f0000000-0000-0000-0000-000000000001', 'agent', 'x')$q$,
     'nao grava mensagem do workspace B em conversa de A (referencia cruzada)');
  PERFORM t_fails($q$INSERT INTO deals (workspace_id, pipeline_id, stage_id, title)
     VALUES ((SELECT app_workspace_id()), 'c0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'x')$q$,
     'nao cria negocio de B no funil de A');
END $$;

\echo '== 4. Atendente (bob) =='
DO $$ DECLARE n bigint; BEGIN
  PERFORM t_as('22222222-2222-2222-2222-222222222222');
  SELECT count(*) INTO n FROM contacts; PERFORM t_ok(n = 12, 'bob ve os 12 contatos do proprio workspace');
  PERFORM t_ok(t_rows($q$UPDATE conversations SET status='em_atendimento' WHERE id='f0000000-0000-0000-0000-000000000001'$q$) = 1, 'bob atualiza conversa');
  SELECT count(*) INTO n FROM api_keys;  PERFORM t_ok(n = 0, 'bob NAO ve chaves de API');
  SELECT count(*) INTO n FROM webhooks;  PERFORM t_ok(n = 0, 'bob NAO ve webhooks');
  SELECT count(*) INTO n FROM campaigns; PERFORM t_ok(n = 0, 'bob NAO ve campanhas');
  PERFORM t_fails($q$INSERT INTO payments (workspace_id, amount, method) VALUES ((SELECT app_workspace_id()), 10, 'pix')$q$, 'bob nao cria cobranca');
  PERFORM t_ok(t_rows($q$UPDATE payments SET status='pago'$q$) = 0, 'bob nao da baixa em pagamento');
  PERFORM t_ok(t_rows($q$UPDATE profiles SET role='admin' WHERE auth_user_id = auth.uid()$q$) = 0, 'bob nao se promove a admin');
  PERFORM t_ok(t_rows($q$UPDATE workspaces SET name='x'$q$) = 0, 'bob nao renomeia workspace');
  PERFORM t_ok(t_rows($q$DELETE FROM contacts$q$) = 0, 'bob nao exclui contatos');
  PERFORM t_fails($q$DELETE FROM messages$q$, 'bob nao apaga mensagens');
  PERFORM t_fails($q$UPDATE messages SET content='adulterada'$q$, 'bob nao adultera conteudo de mensagem');
  PERFORM t_fails($q$SELECT create_api_key('x', ARRAY['messages:write'])$q$, 'bob nao gera chave de API');
  PERFORM t_fails($q$INSERT INTO services (workspace_id, name, duration_minutes) VALUES ((SELECT app_workspace_id()),'x',30)$q$, 'bob nao cadastra servico');
END $$;

\echo '== 5. Admin (alice): segredos e protecoes =='
DO $$ DECLARE r jsonb; k text; n bigint; BEGIN
  PERFORM t_as('11111111-1111-1111-1111-111111111111');
  PERFORM t_ok(t_rows($q$UPDATE workspaces SET name='Nexa Flow Renomeada'$q$) = 1, 'admin renomeia o proprio workspace');
  PERFORM t_fails($q$UPDATE workspaces SET plan='enterprise'$q$, 'admin NAO muda o proprio plano');
  PERFORM t_fails($q$UPDATE workspaces SET status='active', trial_ends_at=NULL$q$, 'admin NAO mexe em status/trial');
  PERFORM t_fails($q$SELECT secret FROM webhooks$q$, 'navegador NAO le segredo de webhook');
  PERFORM t_fails($q$SELECT * FROM webhooks$q$, 'select * em webhooks e negado (front usa colunas explicitas)');
  PERFORM t_fails($q$SELECT key_hash FROM api_keys$q$, 'navegador NAO le hash de chave');
  PERFORM t_fails($q$UPDATE profiles SET auth_user_id = '44444444-4444-4444-4444-444444444444' WHERE email='dave@test.dev'$q$, 'admin NAO vincula conta de terceiro a convite');
  PERFORM t_fails($q$INSERT INTO profiles (workspace_id,name,email,role,auth_user_id) VALUES ((SELECT app_workspace_id()),'X','x@x.dev','admin','44444444-4444-4444-4444-444444444444')$q$, 'admin NAO cria perfil ja vinculado');
  PERFORM t_ok(t_rows($q$INSERT INTO profiles (workspace_id,name,email,role) VALUES ((SELECT app_workspace_id()),'Novo','novo@test.dev','atendente')$q$) = 1, 'admin convida membro');

  r := create_api_key('n8n producao', ARRAY['messages:write','appointments:read','appointments:write']);
  k := r->>'api_key';
  PERFORM t_ok(k ~ '^nxf_[0-9a-f]{48}$', 'chave gerada no formato nxf_<48 hex>');
  PERFORM t_ok((SELECT key_masked FROM api_keys WHERE id = (r->>'id')::uuid) NOT LIKE '%'||substr(k,10,30)||'%', 'chave completa NAO fica guardada em texto');
  PERFORM t_fails($q$SELECT create_api_key('x', ARRAY['admin:all'])$q$, 'permissao desconhecida e recusada');
  PERFORM set_config('test.key', k, true);
  PERFORM t_fails($q$SELECT create_webhook('x','http://insecure.test/hook',ARRAY['message.created'])$q$, 'webhook exige https');
  r := create_webhook('n8n saida', 'https://n8n.example.com/webhook/saida', ARRAY['message.created']);
  PERFORM t_ok(r->>'secret' ~ '^whsec_[0-9a-f]{48}$', 'segredo de webhook gerado no servidor');
  PERFORM set_config('test.secret', r->>'secret', true);
END $$;
-- a chave valida no backend (service_role), e so ate ser revogada
DO $$ DECLARE k text; r record; BEGIN
  SELECT key_masked INTO k FROM api_keys WHERE name='n8n producao';
  PERFORM t_ok(k IS NOT NULL, 'chave existe');
END $$;

\echo '== 6. Guarda do ultimo admin =='
DO $$ BEGIN
  PERFORM t_as('11111111-1111-1111-1111-111111111111');
  PERFORM t_fails($q$UPDATE profiles SET role='gestor' WHERE auth_user_id = auth.uid()$q$, 'ultimo admin nao se rebaixa');
  PERFORM t_fails($q$UPDATE profiles SET is_active=false WHERE auth_user_id = auth.uid()$q$, 'ultimo admin nao se desativa');
  PERFORM t_ok(t_rows($q$UPDATE profiles SET role='admin' WHERE email='bob@test.dev'$q$) = 1, 'admin promove bob a admin');
  PERFORM t_ok(t_rows($q$UPDATE profiles SET role='gestor' WHERE auth_user_id = auth.uid()$q$) = 1, 'com outro admin ativo, alice pode se rebaixar');
END $$;
-- restaura
UPDATE profiles SET role='admin' WHERE id='b0000000-0000-0000-0000-000000000001';
UPDATE profiles SET role='atendente' WHERE id='b0000000-0000-0000-0000-000000000003';

\echo '== 7. Chave de API (backend) =='
DO $$ DECLARE r record; k text := (SELECT 'x'); n int; BEGIN
  -- recria uma chave para testar verify_api_key com o texto completo
  PERFORM t_as('11111111-1111-1111-1111-111111111111');
  PERFORM set_config('test.key2', (create_api_key('teste verify', ARRAY['messages:write']))->>'api_key', true);
  RESET ROLE;
  SET LOCAL ROLE service_role;
  SELECT * INTO r FROM verify_api_key(current_setting('test.key2'));
  PERFORM t_ok(r.workspace_id = 'a0000000-0000-0000-0000-000000000001' AND r.permissions = ARRAY['messages:write'], 'verify_api_key resolve workspace e permissoes');
  SELECT count(*) INTO n FROM verify_api_key('nxf_'||repeat('0',48)); PERFORM t_ok(n = 0, 'chave errada nao autentica');
  SELECT count(*) INTO n FROM verify_api_key('lixo'); PERFORM t_ok(n = 0, 'formato invalido nao autentica');
  RESET ROLE;
  UPDATE api_keys SET is_active=false WHERE name='teste verify';
  SET LOCAL ROLE service_role;
  SELECT count(*) INTO n FROM verify_api_key(current_setting('test.key2')); PERFORM t_ok(n = 0, 'chave revogada para de funcionar');
  RESET ROLE;
  SET LOCAL ROLE authenticated;
  PERFORM t_fails($q$SELECT * FROM verify_api_key('nxf_'||repeat('0',48))$q$, 'verify_api_key nao e chamavel pelo navegador');
END $$;

\echo '== 8. Agenda =='
DO $$ DECLARE
  svc uuid; svc60 uuid; pro uuid; ct uuid := 'e0000000-0000-0000-0000-000000000001';
  d date := (current_date + 1); s record; first_start timestamptz; n int; a appointments; sun date;
BEGIN
  PERFORM t_as('11111111-1111-1111-1111-111111111111');
  INSERT INTO services (workspace_id, name, duration_minutes, price) VALUES ((SELECT app_workspace_id()), 'Consulta', 30, 200) RETURNING id INTO svc;
  INSERT INTO services (workspace_id, name, duration_minutes, price) VALUES ((SELECT app_workspace_id()), 'Procedimento', 60, 500) RETURNING id INTO svc60;
  INSERT INTO professionals (workspace_id, name) VALUES ((SELECT app_workspace_id()), 'Dra. Ana') RETURNING id INTO pro;
  INSERT INTO availability_rules (workspace_id, professional_id, weekday, start_time, end_time)
    SELECT (SELECT app_workspace_id()), pro, w, '09:00', '12:00' FROM generate_series(1,5) w;
  INSERT INTO availability_rules (workspace_id, professional_id, weekday, start_time, end_time)
    SELECT (SELECT app_workspace_id()), pro, w, '14:00', '18:00' FROM generate_series(1,5) w;
  PERFORM set_config('test.svc', svc::text, true); PERFORM set_config('test.svc60', svc60::text, true); PERFORM set_config('test.pro', pro::text, true);

  SELECT count(*) INTO n FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14);
  PERFORM t_ok(n > 0, 'existem horarios livres nos proximos 14 dias ('||n||')');
  SELECT count(*) INTO n FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14)
    WHERE extract(dow FROM starts_at AT TIME ZONE 'America/Sao_Paulo') IN (0,6);
  PERFORM t_ok(n = 0, 'nenhum horario em sabado/domingo');
  SELECT count(*) INTO n FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14)
    WHERE ((starts_at AT TIME ZONE 'America/Sao_Paulo')::time NOT BETWEEN '09:00' AND '11:30')
      AND ((starts_at AT TIME ZONE 'America/Sao_Paulo')::time NOT BETWEEN '14:00' AND '17:30');
  PERFORM t_ok(n = 0, 'todos os horarios respeitam a jornada (fuso America/Sao_Paulo)');
  SELECT count(*) INTO n FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14) WHERE starts_at < now();
  PERFORM t_ok(n = 0, 'nenhum horario no passado');
  PERFORM t_fails($q$SELECT * FROM get_available_slots((SELECT app_workspace_id()), current_setting('test.svc')::uuid, current_date, current_date + 90)$q$, 'janela > 31 dias recusada');

  SELECT * INTO s FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14) ORDER BY starts_at LIMIT 1;
  first_start := s.starts_at;
  a := book_appointment((SELECT app_workspace_id()), ct, svc, pro, first_start, 'manual');
  PERFORM t_ok(a.status = 'agendado' AND a.ends_at = first_start + interval '30 minutes', 'agendamento criado com duracao do servico');
  SELECT count(*) INTO n FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14) WHERE starts_at = first_start;
  PERFORM t_ok(n = 0, 'horario ocupado some da lista');
  PERFORM t_fails(format($q$SELECT book_appointment((SELECT app_workspace_id()), %L, %L, %L, %L)$q$, ct, svc, pro, first_start), 'mesmo horario nao agenda duas vezes');
  PERFORM t_fails(format($q$SELECT book_appointment((SELECT app_workspace_id()), %L, %L, %L, %L)$q$, ct, svc60, pro, first_start - interval '30 minutes'), 'servico de 60min que invade o horario ocupado e recusado');
  PERFORM t_fails(format($q$INSERT INTO appointments (workspace_id, contact_id, professional_id, service_id, starts_at, ends_at)
     VALUES ((SELECT app_workspace_id()), %L, %L, %L, %L, %L)$q$, ct, pro, svc, first_start + interval '10 minutes', first_start + interval '40 minutes'),
     'trava do BANCO impede sobreposicao mesmo por INSERT direto');
  -- fora do expediente: proximo domingo, e 20h de um dia util
  sun := current_date + ((7 - extract(dow FROM current_date)::int) % 7 + 7)::int;
  PERFORM t_fails(format($q$SELECT book_appointment((SELECT app_workspace_id()), %L, %L, %L, %L)$q$, ct, svc, pro, (sun + time '10:00') AT TIME ZONE 'America/Sao_Paulo'), 'domingo e recusado');
  PERFORM t_fails(format($q$SELECT book_appointment((SELECT app_workspace_id()), %L, %L, %L, %L)$q$, ct, svc, pro, (first_start::date + time '23:00')), 'horario fora do expediente e recusado');
  PERFORM t_fails(format($q$SELECT book_appointment((SELECT app_workspace_id()), %L, %L, %L, %L)$q$, ct, svc, pro, now() - interval '1 day'), 'horario no passado e recusado');
  UPDATE appointments SET status='cancelado' WHERE id = a.id;
  SELECT count(*) INTO n FROM get_available_slots((SELECT app_workspace_id()), svc, current_date, current_date + 14) WHERE starts_at = first_start;
  PERFORM t_ok(n = 1, 'cancelar libera o horario novamente');

  -- atendente pode agendar; outra clinica nao
  RESET ROLE; PERFORM t_as('22222222-2222-2222-2222-222222222222');
  a := book_appointment('a0000000-0000-0000-0000-000000000001', ct, svc, pro, first_start, 'manual');
  PERFORM t_ok(a.id IS NOT NULL, 'atendente agenda paciente');
  RESET ROLE; PERFORM t_as('33333333-3333-3333-3333-333333333333');
  PERFORM t_fails(format($q$SELECT book_appointment('a0000000-0000-0000-0000-000000000001', %L, %L, %L, %L)$q$, ct, svc, pro, first_start + interval '1 day'), 'carol nao agenda na clinica A');
  PERFORM t_ok((SELECT count(*) FROM appointments) = 0, 'carol nao ve agendamentos de A');
END $$;

\echo '== 9. Ingestao de mensagens (n8n) =='
DO $$ DECLARE r jsonb; r2 jsonb; ws uuid := 'a0000000-0000-0000-0000-000000000001'; n int; c uuid; cv uuid; BEGIN
  SET LOCAL ROLE service_role;
  r := ingest_incoming_message(ws, 'whatsapp', '5561999990000', 'Paciente Teste', NULL, 'Oi, quero agendar', 'wamid.AAA');
  PERFORM t_ok((r->>'duplicate')::boolean = false, 'primeira mensagem criada');
  c := (r->>'contact_id')::uuid; cv := (r->>'conversation_id')::uuid;
  PERFORM t_ok((SELECT phone FROM contacts WHERE id = c) = '+5561999990000', 'telefone do WhatsApp normalizado');
  PERFORM t_ok((SELECT count(*) FROM deals WHERE contact_id = c) = 1, 'novo lead entra no funil');
  PERFORM t_ok(jsonb_array_length(r->'history') = 1, 'historico com 1 mensagem');
  PERFORM t_ok(r->'agent'->>'name' IS NOT NULL, 'persona do agente de IA vem no contexto');
  PERFORM t_ok(jsonb_array_length(r->'services') >= 2, 'servicos cadastrados vem no contexto (IA nao inventa servico/preco)');
  PERFORM t_ok((r->>'ai_paused')::boolean = false, 'IA liberada');
  r2 := ingest_incoming_message(ws, 'whatsapp', '5561999990000', 'Paciente Teste', NULL, 'Oi, quero agendar', 'wamid.AAA');
  PERFORM t_ok((r2->>'duplicate')::boolean AND r2->>'message_id' = r->>'message_id', 'reenvio do webhook e deduplicado');
  PERFORM t_ok((SELECT unread_count FROM conversations WHERE id = cv) = 1 AND (SELECT count(*) FROM messages WHERE conversation_id = cv) = 1, 'reenvio nao duplica mensagem nem contador');
  r2 := ingest_incoming_message(ws, 'whatsapp', '5561999990000', 'Paciente Teste', NULL, 'Tem horario amanha?', 'wamid.BBB');
  PERFORM t_ok(r2->>'conversation_id' = r->>'conversation_id' AND r2->>'contact_id' = r->>'contact_id', 'mesmo contato reaproveita conversa');
  PERFORM t_ok((SELECT unread_count FROM conversations WHERE id = cv) = 2 AND jsonb_array_length(r2->'history') = 2, 'contador e historico crescem');
  PERFORM t_ok((SELECT count(*) FROM contacts WHERE external_id = '5561999990000') = 1, 'sem contato duplicado');
  r2 := ingest_ai_reply(ws, cv, 'Claro! Tenho horarios amanha.', false, 'ai-1');
  PERFORM t_ok((r2->>'skipped')::text = 'false', 'resposta da IA registrada no CRM');
  PERFORM t_ok((SELECT unread_count FROM conversations WHERE id = cv) = 0, 'resposta da IA zera nao lidas');
  r2 := ingest_ai_reply(ws, cv, 'Claro! Tenho horarios amanha.', false, 'ai-1');
  PERFORM t_ok(r2->>'skipped' = 'duplicate', 'resposta da IA tambem e idempotente');
  PERFORM t_fails($q$SELECT ingest_incoming_message('a0000000-0000-0000-0000-000000000001','fax','1','x',NULL,'x','z1')$q$, 'canal invalido recusado');
  PERFORM t_fails($q$SELECT ingest_incoming_message('a0000000-0000-0000-0000-000000000001','whatsapp','','x',NULL,'x','z2')$q$, 'id externo vazio recusado');
  PERFORM t_fails($q$SELECT ingest_ai_reply('33333333-0000-0000-0000-000000000000', (SELECT id FROM conversations LIMIT 1), 'x')$q$, 'IA nao escreve em conversa de outro workspace');
  PERFORM set_config('test.cv', cv::text, false); PERFORM set_config('test.c', c::text, false);
END $$;

\echo '== 10. Humano assume: IA pausa e webhook de saida dispara =='
DO $$ DECLARE r jsonb; cv uuid := current_setting('test.cv')::uuid; ws uuid := 'a0000000-0000-0000-0000-000000000001'; n int; h record; BEGIN
  PERFORM t_as('22222222-2222-2222-2222-222222222222');   -- bob (atendente)
  INSERT INTO messages (workspace_id, conversation_id, sender_type, sender_name, content)
    VALUES (ws, cv, 'agent', 'Bob', 'Oi, sou o Bob da recepcao');
  PERFORM t_ok((SELECT ai_paused FROM conversations WHERE id = cv), 'mensagem de humano pausa a IA automaticamente');
  RESET ROLE;
  SELECT count(*) INTO n FROM net.calls WHERE url = 'https://n8n.example.com/webhook/saida';
  PERFORM t_ok(n = 1, 'webhook de saida (message.created) disparado 1 vez');
  SELECT * INTO h FROM net.calls ORDER BY id DESC LIMIT 1;
  PERFORM t_ok(h.headers->>'X-Webhook-Secret' LIKE 'whsec_%' AND h.body->>'event' = 'message.created' AND h.body->'contact'->>'external_id' = '5561999990000', 'payload traz evento, contato e segredo no header');
  -- nota interna NAO dispara
  PERFORM t_as('22222222-2222-2222-2222-222222222222');
  INSERT INTO messages (workspace_id, conversation_id, sender_type, sender_name, content, is_note, message_type)
    VALUES (ws, cv, 'agent', 'Bob', 'anotacao interna', true, 'note');
  RESET ROLE;
  SELECT count(*) INTO n FROM net.calls; PERFORM t_ok(n = 1, 'nota interna NAO vai para o paciente');
  SET LOCAL ROLE service_role;
  r := ingest_incoming_message(ws, 'whatsapp', '5561999990000', 'Paciente Teste', NULL, 'Obrigado', 'wamid.CCC');
  PERFORM t_ok((r->>'ai_paused')::boolean, 'n8n recebe ai_paused=true quando humano assumiu');
  r := ingest_ai_reply(ws, cv, 'Resposta que NAO deve existir', false, 'ai-2');
  PERFORM t_ok(r->>'skipped' = 'ai_paused', 'servidor DESCARTA resposta da IA se humano assumiu');
  PERFORM t_ok((SELECT count(*) FROM messages WHERE content = 'Resposta que NAO deve existir') = 0, 'resposta da IA nao foi gravada');
  -- handoff pedido pela IA
  r := ingest_incoming_message(ws, 'instagram', 'ig_123', 'Maria IG', NULL, 'Quero falar com uma pessoa', 'ig.1');
  r := ingest_ai_reply(ws, (r->>'conversation_id')::uuid, 'Vou chamar um atendente.', true, 'ai-3');
  PERFORM t_ok((SELECT ai_paused AND status = 'aguardando' FROM conversations WHERE id = (SELECT conversation_id FROM messages WHERE external_id='ig.1')), 'IA pede humano: conversa pausada e em "aguardando"');
  PERFORM t_ok((SELECT count(*) FROM messages WHERE message_type='system' AND content LIKE 'A IA transferiu%') = 1, 'transferencia registrada como mensagem de sistema');
  RESET ROLE;
  UPDATE workspaces SET status='suspended' WHERE id = ws;
  SET LOCAL ROLE service_role;
  PERFORM t_fails($q$SELECT ingest_incoming_message('a0000000-0000-0000-0000-000000000001','whatsapp','999','x',NULL,'x','susp1')$q$, 'workspace suspenso nao recebe mensagens');
  RESET ROLE;
  UPDATE workspaces SET status='active' WHERE id = ws;
END $$;

\echo '== 11. Pagamentos =='
DO $$ DECLARE p1 uuid; p2 uuid; p3 uuid; r jsonb; ws uuid := 'a0000000-0000-0000-0000-000000000001'; BEGIN
  PERFORM t_as('11111111-1111-1111-1111-111111111111');
  INSERT INTO payments (workspace_id, amount, method, description, gateway) VALUES (ws, 150.00, 'checkout', 'Consulta', 'infinitepay') RETURNING id INTO p1;
  INSERT INTO payments (workspace_id, amount, method, description, gateway) VALUES (ws, 100.00, 'checkout', 'Retorno', 'infinitepay') RETURNING id INTO p2;
  INSERT INTO payments (workspace_id, amount, method, description, gateway) VALUES (ws, 80.00, 'checkout', 'Limpeza', 'infinitepay') RETURNING id INTO p3;
  PERFORM t_fails(format($q$SELECT confirm_payment(%L, 15000, 15000, 's', 'u', 'pix')$q$, p1), 'navegador NAO confirma pagamento');
  RESET ROLE; SET LOCAL ROLE service_role;
  r := confirm_payment(p1, 15000, 15150, 'slug1', 'https://recibo/1', 'credit_card');
  PERFORM t_ok((r->>'already_paid')::boolean = false AND (SELECT status = 'pago' AND method = 'credit_card' AND paid_amount = 151.50 FROM payments WHERE id = p1), 'pagamento confirmado (valor pago > valor, parcelamento)');
  r := confirm_payment(p1, 15000, 15150, 'slug1', 'https://recibo/1', 'credit_card');
  PERFORM t_ok((r->>'already_paid')::boolean, 'reentrega do webhook e idempotente');
  PERFORM t_fails(format($q$SELECT confirm_payment(%L, 9999, 9999, 's', 'u', 'pix')$q$, p2), 'valor diferente do cobrado e recusado');
  PERFORM t_fails(format($q$SELECT confirm_payment(%L, 10000, 9000, 's', 'u', 'pix')$q$, p2), 'pagamento a menor e recusado');
  PERFORM t_ok((SELECT status FROM payments WHERE id = p2) = 'pendente', 'pagamento recusado continua pendente');
  RESET ROLE; PERFORM t_as('22222222-2222-2222-2222-222222222222');
  PERFORM t_ok(t_rows(format($q$UPDATE payments SET status='pago' WHERE id=%L$q$, p3)) = 0, 'atendente nao da baixa manual');
  RESET ROLE; PERFORM t_as('11111111-1111-1111-1111-111111111111');
  PERFORM t_ok(t_rows(format($q$UPDATE payments SET status='pago', paid_at=now() WHERE id=%L$q$, p3)) = 1, 'admin da baixa manual');
END $$;

\echo '== TODOS OS TESTES PASSARAM =='
