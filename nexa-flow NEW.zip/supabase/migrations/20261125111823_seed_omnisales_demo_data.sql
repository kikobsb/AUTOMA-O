/*
# Seed OmniSales demo data (pt-BR)

1. Data
- 1 workspace "Nexa Flow" (professional plan).
- 6 team members (admin, gestor, 4 atendentes).
- 12 contacts across WhatsApp/Instagram/site chat with tags.
- 8 conversations with varied statuses + messages (text, audio, image, notes).
- 4 quick replies with dynamic variables.
- 1 default pipeline with 7 stages (Novo Lead → Ganho/Perdido).
- 12 deals spread across stages with values, temperatures, owners.
- Deal activities timeline.
- 3 AI agents (SDR, Suporte, Agendamento).
- 4 automations with nodes.
- 5 campaigns with delivery reports.
- 8 payments (paid/pending/failed) via pix/card/boleto.
- Lead attributions with UTMs.
- 3 webhooks + 2 API keys.

2. Notes
- All rows use explicit UUIDs so children link deterministically.
- Idempotent: skips if workspace slug 'nexa-flow' already exists.
*/

DO $seed$
DECLARE
  ws_id uuid := 'a0000000-0000-0000-0000-000000000001';
  u_admin uuid := 'b0000000-0000-0000-0000-000000000001';
  u_gestor uuid := 'b0000000-0000-0000-0000-000000000002';
  u_atend1 uuid := 'b0000000-0000-0000-0000-000000000003';
  u_atend2 uuid := 'b0000000-0000-0000-0000-000000000004';
  u_atend3 uuid := 'b0000000-0000-0000-0000-000000000005';
  u_atend4 uuid := 'b0000000-0000-0000-0000-000000000006';
  pipe_id uuid := 'c0000000-0000-0000-0000-000000000001';
  st_novo uuid := 'd0000000-0000-0000-0000-000000000001';
  st_qualif uuid := 'd0000000-0000-0000-0000-000000000002';
  st_demo uuid := 'd0000000-0000-0000-0000-000000000003';
  st_proposta uuid := 'd0000000-0000-0000-0000-000000000004';
  st_pagamento uuid := 'd0000000-0000-0000-0000-000000000005';
  st_ganho uuid := 'd0000000-0000-0000-0000-000000000006';
  st_perdido uuid := 'd0000000-0000-0000-0000-000000000007';
  c1 uuid := 'e0000000-0000-0000-0000-000000000001';
  c2 uuid := 'e0000000-0000-0000-0000-000000000002';
  c3 uuid := 'e0000000-0000-0000-0000-000000000003';
  c4 uuid := 'e0000000-0000-0000-0000-000000000004';
  c5 uuid := 'e0000000-0000-0000-0000-000000000005';
  c6 uuid := 'e0000000-0000-0000-0000-000000000006';
  c7 uuid := 'e0000000-0000-0000-0000-000000000007';
  c8 uuid := 'e0000000-0000-0000-0000-000000000008';
  c9 uuid := 'e0000000-0000-0000-0000-000000000009';
  c10 uuid := 'e0000000-0000-0000-0000-000000000010';
  c11 uuid := 'e0000000-0000-0000-0000-000000000011';
  c12 uuid := 'e0000000-0000-0000-0000-000000000012';
  conv1 uuid := 'f0000000-0000-0000-0000-000000000001';
  conv2 uuid := 'f0000000-0000-0000-0000-000000000002';
  conv3 uuid := 'f0000000-0000-0000-0000-000000000003';
  conv4 uuid := 'f0000000-0000-0000-0000-000000000004';
  conv5 uuid := 'f0000000-0000-0000-0000-000000000005';
  conv6 uuid := 'f0000000-0000-0000-0000-000000000006';
  conv7 uuid := 'f0000000-0000-0000-0000-000000000007';
  conv8 uuid := 'f0000000-0000-0000-0000-000000000008';
BEGIN
  IF EXISTS (SELECT 1 FROM workspaces WHERE slug = 'nexa-flow') THEN
    RETURN;
  END IF;

  INSERT INTO workspaces (id, name, slug, plan, status, trial_ends_at) VALUES
    (ws_id, 'Nexa Flow', 'nexa-flow', 'professional', 'active', now() + interval '12 days');

  INSERT INTO profiles (id, workspace_id, name, email, role) VALUES
    (u_admin,  ws_id, 'Ricardo Almeida', 'ricardo@nexaflow.com.br', 'admin'),
    (u_gestor, ws_id, 'Fernanda Lima',   'fernanda@nexaflow.com.br', 'gestor'),
    (u_atend1, ws_id, 'Juliana Castro',  'juliana@nexaflow.com.br', 'atendente'),
    (u_atend2, ws_id, 'Marcos Vieira',   'marcos@nexaflow.com.br',  'atendente'),
    (u_atend3, ws_id, 'Patrícia Souza',  'patricia@nexaflow.com.br','atendente'),
    (u_atend4, ws_id, 'Thiago Ramos',    'thiago@nexaflow.com.br',  'atendente');

  INSERT INTO contacts (id, workspace_id, name, phone, email, channel, tags, stage_id, deal_value, company, owner_id, notes) VALUES
    (c1,  ws_id, 'Ana Beatriz Costa',  '11987650001', 'ana.costa@gmail.com',      'whatsapp',   '{cliente,novo}',        st_qualif,   2500,  'Padaria Pão Nosso',       u_atend1, 'Quer automatizar pedidos pelo WhatsApp.'),
    (c2,  ws_id, 'Carlos Eduardo Lima', '11987650002', 'carlos.lima@outlook.com',  'whatsapp',   '{quente}',              st_proposta, 8900,  'CE Lima Consultoria',     u_atend2, 'Decisor. Pediu proposta formal.'),
    (c3,  ws_id, 'Mariana Ferreira',    '11987650003', 'mariana.f@gmail.com',      'instagram',  '{leads-instagram}',     st_novo,     1200,  'MF Studio Beleza',        u_atend1, 'Veio pelo anúncio do Reels.'),
    (c4,  ws_id, 'Roberto Nakamura',    '11987650004', 'roberto@techtanque.com.br','site_chat',  '{enterprise}',          st_demo,     15000, 'TechTanque Sistemas',     u_gestor, 'Empresa grande, 50+ atendentes.'),
    (c5,  ws_id, 'Fernanda Ribeiro',    '11987650005', 'fer.ribeiro@gmail.com',    'whatsapp',   '{cliente,renovacao}',   st_pagamento,4900,  'Studio Pilates Vida',     u_atend3, 'Aguardando pagamento do Pix.'),
    (c6,  ws_id, 'João Pedro Alves',    '11987650006', 'jp.alves@gmail.com',       'instagram',  '{leads-instagram}',     st_novo,     800,   'JP Barbershop',           u_atend4, 'Comentou no post do Reel.'),
    (c7,  ws_id, 'Luiza Martins',       '11987650007', 'luiza.martins@gmail.com',  'whatsapp',   '{quente,cliente}',      st_ganho,    7200,  'LM Doces Gourmet',        u_atend2, 'Pagou via Pix. Onboarding agendado.'),
    (c8,  ws_id, 'Eduardo Prado',       '11987650008', 'edu.prado@gmail.com',      'site_chat',  '{frio}',                st_perdido,  0,     'Prado Imóveis',           u_atend3, 'Preço acima do orçamento.'),
    (c9,  ws_id, 'Camila Torres',       '11987650009', 'camila.torres@gmail.com',  'whatsapp',   '{novo}',                st_qualif,   3200,  'CT Fitness',              u_atend1, 'Quer agendar demonstração.'),
    (c10, ws_id, 'Gustavo Henrique',    '11987650010', 'gustavo.h@gmail.com',      'whatsapp',   '{renovacao}',           st_demo,     5600,  'GH Auto Peças',           u_atend4, 'Cliente antigo, plano anual.'),
    (c11, ws_id, 'Beatriz Nogueira',    '11987650011', 'bia.nogueira@gmail.com',   'instagram',  '{novo}',                st_novo,     950,   'Bia Nogueira Modas',      u_atend3, 'Perguntou sobre preços no direct.'),
    (c12, ws_id, 'Rafael Mendes',       '11987650012', 'rafael.mendes@gmail.com',  'site_chat',  '{enterprise,quente}',   st_qualif,   12000, 'Mendes Logística',        u_gestor, 'Indicado por cliente. Muito promissor.');

  INSERT INTO conversations (id, workspace_id, contact_id, channel, status, unread_count, assignee_id, ai_paused, last_message_at, last_message_preview) VALUES
    (conv1, ws_id, c1,  'whatsapp',  'em_atendimento', 2, u_atend1, false, now() - interval '4 minutes',  'Audio (0:32)'),
    (conv2, ws_id, c2,  'whatsapp',  'aguardando',     0, u_atend2, false, now() - interval '2 hours',    'Consegue enviar a proposta hoje?'),
    (conv3, ws_id, c3,  'instagram', 'aberta',         3, u_atend1, false, now() - interval '10 minutes', 'manda uns prints de como fica o funil tb'),
    (conv4, ws_id, c4,  'site_chat', 'em_atendimento', 1, u_gestor, true,  now() - interval '40 minutes', 'Podemos agendar a demo pra amanhã?'),
    (conv5, ws_id, c5,  'whatsapp',  'aguardando',     0, u_atend3, false, now() - interval '1 hour',     'Enviei o Pix agora, confere aí pfvr'),
    (conv6, ws_id, c6,  'instagram', 'aberta',         0, u_atend4, false, now() - interval '3 hours',    'Vi no Instagram e quero saber mais'),
    (conv7, ws_id, c7,  'whatsapp',  'resolvida',      0, u_atend2, false, now() - interval '2 days',     'Pagamento confirmado! Obrigado 😄'),
    (conv8, ws_id, c12, 'site_chat', 'aberta',         2, NULL,     false, now() - interval '25 minutes', 'Preciso de atendimento personalizado');

  INSERT INTO messages (workspace_id, conversation_id, sender_type, sender_id, sender_name, content, message_type, is_note, created_at) VALUES
    (ws_id, conv1, 'contact', NULL, 'Ana Beatriz Costa', 'Oi! Vi o anúncio de vocês sobre atendimento automático, funciona pra padaria?', 'text', false, now() - interval '26 minutes'),
    (ws_id, conv1, 'ai', NULL, 'Nexa IA', 'Olá Ana! Tudo bem? Sim, funciona perfeitamente! Recebemos pedidos, confirmamos e ainda informamos o cliente quando fica pronto. Posso te mostrar como funciona?', 'text', false, now() - interval '25 minutes'),
    (ws_id, conv1, 'contact', NULL, 'Ana Beatriz Costa', 'Quero sim! Mas eu tenho várias dúvidas, posso mandar um áudio?', 'text', false, now() - interval '20 minutes'),
    (ws_id, conv1, 'contact', NULL, 'Ana Beatriz Costa', 'Audio message', 'audio', false, now() - interval '4 minutes'),
    (ws_id, conv1, 'agent', u_atend1, 'Juliana Castro', 'Cliente prefere áudio, responder em áudio também. Interessada no plano Professional.', 'note', true, now() - interval '3 minutes'),
    (ws_id, conv2, 'contact', NULL, 'Carlos Eduardo Lima', 'Bom dia! Recebi a demonstração e gostei muito. Consegue enviar a proposta formal hoje?', 'text', false, now() - interval '2 hours'),
    (ws_id, conv2, 'agent', u_atend2, 'Marcos Vieira', 'Bom dia, Carlos! Vou preparar com o desconto de 10% que combinamos e te envio até o fim da tarde.', 'text', false, now() - interval '2 hours' + interval '5 minutes'),
    (ws_id, conv3, 'contact', NULL, 'Mariana Ferreira', 'Oi! Vi vocês no anúncio. Quanto custa o plano pra salão de beleza?', 'text', false, now() - interval '19 minutes'),
    (ws_id, conv3, 'ai', NULL, 'Nexa IA', 'Oi Mariana! Temos planos a partir de R$ 197/mês. Para salões, o mais indicado é o plano que inclui agendamento automático. Quer que eu te mande a tabela completa?', 'text', false, now() - interval '18 minutes'),
    (ws_id, conv3, 'contact', NULL, 'Mariana Ferreira', 'Quero sim! E dá pra marcar horário pros clientes sozinho?', 'text', false, now() - interval '11 minutes'),
    (ws_id, conv3, 'contact', NULL, 'Mariana Ferreira', 'manda uns prints de como fica o funil tb', 'text', false, now() - interval '10 minutes'),
    (ws_id, conv4, 'contact', NULL, 'Roberto Nakamura', 'Cheguei pelo site de vocês. Preciso de uma solução pra 50 atendentes com API própria.', 'text', false, now() - interval '1 hour'),
    (ws_id, conv4, 'agent', u_gestor, 'Fernanda Lima', 'Olá Roberto! Temos o plano Enterprise com API pública, webhooks e SSO. Posso agendar uma demo técnica?', 'text', false, now() - interval '50 minutes'),
    (ws_id, conv4, 'contact', NULL, 'Roberto Nakamura', 'Podemos agendar a demo pra amanhã às 10h?', 'text', false, now() - interval '40 minutes'),
    (ws_id, conv5, 'agent', u_atend3, 'Patrícia Souza', 'Fernanda, gerei o link de pagamento: R$ 4.900,00 via Pix. Segue o link!', 'text', false, now() - interval '3 hours'),
    (ws_id, conv5, 'contact', NULL, 'Fernanda Ribeiro', 'Enviei o Pix agora, confere aí pfvr', 'text', false, now() - interval '1 hour'),
    (ws_id, conv6, 'contact', NULL, 'João Pedro Alves', 'Vi o post de vocês e quero saber se funciona pra barbearia', 'text', false, now() - interval '3 hours'),
    (ws_id, conv6, 'ai', NULL, 'Nexa IA', 'Oi João! Funciona sim! Confirmações automáticas de horário, lembretes e até cobrança. Quer ver uma demonstração?', 'text', false, now() - interval '3 hours' + interval '2 minutes'),
    (ws_id, conv7, 'contact', NULL, 'Luiza Martins', 'Paguei o Pix agora! Consegue liberar meu acesso hoje ainda?', 'text', false, now() - interval '2 days'),
    (ws_id, conv7, 'system', NULL, NULL, 'Pagamento de R$ 7.200,00 confirmado via Pix.', 'system', false, now() - interval '2 days' + interval '10 minutes'),
    (ws_id, conv7, 'agent', u_atend2, 'Marcos Vieira', 'Pagamento confirmado! Acesso liberado e onboarding agendado pra sexta às 14h.', 'text', false, now() - interval '2 days' + interval '15 minutes'),
    (ws_id, conv8, 'contact', NULL, 'Rafael Mendes', 'Olá, sou da Mendes Logística. Preciso de atendimento personalizado pra 20 vendedores.', 'text', false, now() - interval '30 minutes');

  INSERT INTO quick_replies (workspace_id, shortcut, title, content) VALUES
    (ws_id, '/ola', 'Saudação', 'Olá {{nome}}! Tudo bem? Como posso te ajudar hoje?'),
    (ws_id, '/preco', 'Tabela de preços', '{{nome}}, nossos planos começam em R$ 197/mês. O Professional com IA custa R$ 497/mês. Quer que eu te envie a proposta completa?'),
    (ws_id, '/pix', 'Enviar link de pagamento', 'Perfeito, {{nome}}! Gerei o link de pagamento pra você: https://pay.nexaflow.com.br/a7x9k2'),
    (ws_id, '/agendar', 'Agendar demonstração', '{{nome}}, posso te agendar pra uma demonstração! Temos horários hoje às 15h ou amanhã às 10h. Qual prefere?');

  INSERT INTO pipelines (id, workspace_id, name, is_default) VALUES
    (pipe_id, ws_id, 'Vendas Nexa Flow', true);

  INSERT INTO stages (id, workspace_id, pipeline_id, name, color, position, is_won, is_lost) VALUES
    (st_novo,     ws_id, pipe_id, 'Novo Lead',             '#64748B', 1, false, false),
    (st_qualif,   ws_id, pipe_id, 'Qualificado',           '#0EA5E9', 2, false, false),
    (st_demo,     ws_id, pipe_id, 'Demonstração Agendada', '#8B5CF6', 3, false, false),
    (st_proposta, ws_id, pipe_id, 'Proposta Enviada',      '#F59E0B', 4, false, false),
    (st_pagamento,ws_id, pipe_id, 'Aguardando Pagamento',  '#EC4899', 5, false, false),
    (st_ganho,    ws_id, pipe_id, 'Ganho',                 '#10B981', 6, true,  false),
    (st_perdido,  ws_id, pipe_id, 'Perdido',               '#EF4444', 7, false, true);

  INSERT INTO deals (id, workspace_id, pipeline_id, stage_id, contact_id, title, value, temperature, source, owner_id, next_task, next_task_at, utm_source, utm_campaign, utm_medium) VALUES
    ('11000000-0000-0000-0000-000000000001', ws_id, pipe_id, st_novo,     c3,  'MF Studio Beleza - Plano Starter',     1200,  'morno', 'instagram', u_atend1, 'Responder direct com tabela de preços', now() + interval '2 hours', 'instagram', 'reels-out-25', 'social'),
    ('11000000-0000-0000-0000-000000000002', ws_id, pipe_id, st_novo,     c6,  'JP Barbershop - Plano Starter',         800,  'frio',  'instagram', u_atend4, 'Enviar catálogo',                      now() + interval '1 day',   'instagram', 'reels-out-25', 'social'),
    ('11000000-0000-0000-0000-000000000003', ws_id, pipe_id, st_novo,     c11, 'Bia Nogueira Modas - Plano Starter',    950,  'morno', 'instagram', u_atend3, 'Ligar às 14h',                         now() + interval '4 hours', 'instagram', 'feed-out-25',  'social'),
    ('11000000-0000-0000-0000-000000000004', ws_id, pipe_id, st_qualif,   c1,  'Padaria Pão Nosso - Professional',     2500,  'quente','whatsapp',  u_atend1, 'Enviar áudio de resposta',             now() - interval '5 minutes','google',  'marca-soft',   'cpc'),
    ('11000000-0000-0000-0000-000000000005', ws_id, pipe_id, st_qualif,   c9,  'CT Fitness - Professional',            3200,  'quente','whatsapp',  u_atend1, 'Agendar demo',                         now() + interval '1 day',   'facebook',  'leads-out-25', 'ads'),
    ('11000000-0000-0000-0000-000000000006', ws_id, pipe_id, st_qualif,   c12, 'Mendes Logística - Enterprise',       12000,  'quente','site_chat', u_gestor, 'Reunião de escopo com diretoria',      now() + interval '2 days',  NULL,        NULL,           NULL),
    ('11000000-0000-0000-0000-000000000007', ws_id, pipe_id, st_demo,     c4,  'TechTanque - Enterprise',             15000,  'quente','site_chat', u_gestor, 'Demo técnica amanhã 10h',              now() + interval '20 hours','google',    'marca-soft',   'organic'),
    ('11000000-0000-0000-0000-000000000008', ws_id, pipe_id, st_demo,     c10, 'GH Auto Peças - Anual',                5600,  'morno', 'whatsapp',  u_atend4, 'Follow-up pós demo',                   now() + interval '3 days',  'facebook',  'remarketing',  'ads'),
    ('11000000-0000-0000-0000-000000000009', ws_id, pipe_id, st_proposta, c2,  'CE Lima Consultoria - Professional',  8900,  'quente','whatsapp',  u_atend2, 'Enviar proposta formal',               now() + interval '6 hours', 'indicacao', NULL,           'referral'),
    ('11000000-0000-0000-0000-000000000010', ws_id, pipe_id, st_pagamento,c5,  'Studio Pilates Vida - Professional',  4900,  'quente','whatsapp',  u_atend3, 'Confirmar Pix',                        now() - interval '30 minutes','facebook', 'leads-out-25', 'ads'),
    ('11000000-0000-0000-0000-000000000011', ws_id, pipe_id, st_ganho,    c7,  'LM Doces Gourmet - Professional',     7200,  'quente','whatsapp',  u_atend2, NULL,                                   NULL,                       'google',    'marca',        'organic'),
    ('11000000-0000-0000-0000-000000000012', ws_id, pipe_id, st_perdido,  c8,  'Prado Imóveis - Professional',        6200,  'frio',  'site_chat', u_atend3, NULL,                                   NULL,                       'google',    'concorrente',  'cpc');

  UPDATE deals SET closed_at = now() - interval '3 days' WHERE id = '11000000-0000-0000-0000-000000000011';
  UPDATE deals SET lost_reason = 'Preço acima do orçamento. Escolheu concorrente mais barato.' WHERE id = '11000000-0000-0000-0000-000000000012';

  INSERT INTO deal_activities (workspace_id, deal_id, user_id, activity_type, title, description, created_at) VALUES
    (ws_id, '11000000-0000-0000-0000-000000000009', u_atend2, 'call',        'Ligação de alinhamento', 'Carlos confirmou verba e pediu proposta com desconto de 10%.', now() - interval '1 day'),
    (ws_id, '11000000-0000-0000-0000-000000000009', u_atend2, 'follow_up',   'Follow-up agendado', 'Enviar proposta formal até 17h.', now() - interval '2 hours'),
    (ws_id, '11000000-0000-0000-0000-000000000007', u_gestor, 'meeting',     'Demo técnica agendada', 'Amanhã às 10h, com o time de TI da TechTanque.', now() - interval '5 hours'),
    (ws_id, '11000000-0000-0000-0000-000000000004', NULL,     'ai_action',   'Agente IA qualificou o lead', 'Detectou interesse em automação de pedidos. Score: 78/100.', now() - interval '20 minutes'),
    (ws_id, '11000000-0000-0000-0000-000000000011', u_atend2, 'payment',     'Pagamento recebido', 'Pix de R$ 7.200,00 confirmado. Negócio marcado como Ganho.', now() - interval '3 days'),
    (ws_id, '11000000-0000-0000-0000-000000000012', u_atend3, 'stage_change','Negócio perdido', 'Motivo: preço acima do orçamento.', now() - interval '6 days');

  INSERT INTO ai_agents (id, workspace_id, name, goal, persona, tone, restrictions, knowledge_base, tools, is_active, working_hours, response_delay_seconds, conversations_handled, resolution_rate) VALUES
    ('d1000000-0000-0000-0000-000000000001', ws_id, 'Nina - SDR de Qualificação', 'sdr',
      'Você é a Nina, SDR da Nexa Flow. Proativa e objetiva. Missão: qualificar leads descobrindo porte da empresa, volume de atendimentos, dor principal e prazo de decisão.',
      'amigavel',
      'Nunca prometa descontos. Nunca invente preços. Se perguntarem algo técnico demais, transfira para atendente humano.',
      'Planos: Starter R$197/mês (1 número, 1.000 disparos). Professional R$497/mês (3 números, IA incluída, 10.000 disparos). Enterprise: sob consulta, API completa e SSO.',
      '[{"name":"qualificar_lead","description":"Salva score e respostas no CRM"},{"name":"mover_no_funil","description":"Move o card para a etapa Qualificado"},{"name":"agendar_reuniao","description":"Consulta agenda e agenda demo"},{"name":"transferir_humano","description":"Transfere para atendente"}]',
      true, '24_7', 3, 342, 68.5),
    ('d1000000-0000-0000-0000-000000000002', ws_id, 'Bruno - Suporte Técnico', 'suporte',
      'Você é o Bruno, agente de suporte da Nexa Flow. Paciente e didático, resolve dúvidas de configuração de canais, disparos e automações.',
      'profissional',
      'Não acesse dados de pagamento. Encaminhe cancelamentos para o time humano sempre.',
      'FAQ: Como conectar WhatsApp: Configurações > Canais > Conectar. Como criar disparo: Disparos > Nova campanha. Erros comuns de template reprovado: variáveis fora de ordem.',
      '[{"name":"consultar_base","description":"Busca resposta na base de conhecimento"},{"name":"abrir_ticket","description":"Cria ticket para o time humano"},{"name":"transferir_humano","description":"Transfere para atendente"}]',
      true, '24_7', 5, 518, 81.2),
    ('d1000000-0000-0000-0000-000000000003', ws_id, 'Sofia - Agendamento', 'agendamento',
      'Você é a Sofia, especialista em agendamentos. Consulta a agenda do time e marca demonstrações e reuniões de onboarding.',
      'amigavel',
      'Só agende dentro do horário comercial do time (seg-sex 9h-18h). Confirme sempre o fuso de São Paulo.',
      'Agenda do time: seg-sex 9h-18h. Demos duram 30 minutos. Onboarding dura 45 minutos.',
      '[{"name":"consultar_horarios","description":"Lista horários livres na agenda"},{"name":"agendar_reuniao","description":"Cria evento e convida o lead"},{"name":"mover_no_funil","description":"Move o card para Demonstração Agendada"}]',
      false, 'comercial', 4, 127, 74.3);

  INSERT INTO automations (id, workspace_id, name, description, trigger_type, trigger_config, nodes, is_active, runs_count, last_run_at) VALUES
    ('e1000000-0000-0000-0000-000000000001', ws_id, 'Boas-vindas WhatsApp', 'Responde automaticamente novos contatos no WhatsApp',
      'nova_mensagem', '{"filter":"primeira_mensagem"}',
      '[{"type":"trigger","label":"Nova mensagem recebida"},{"type":"action","label":"Enviar mensagem","config":"Olá! Seja bem-vindo à Nexa Flow. Sou a assistente virtual. Como posso te ajudar?"},{"type":"condition","label":"É cliente?","yes":"Acionar Agente de IA","no":"Adicionar tag: novo"}]',
      true, 1204, now() - interval '12 minutes'),
    ('e1000000-0000-0000-0000-000000000002', ws_id, 'Palavra-chave: PREÇO', 'Envia tabela quando o cliente menciona preço',
      'palavra_chave', '{"keywords":["preço","preco","valor","quanto custa"]}',
      '[{"type":"trigger","label":"Palavra-chave: preço, valor, quanto custa"},{"type":"action","label":"Enviar mensagem","config":"Confira nossos planos: Starter R$197 | Professional R$497 | Enterprise sob consulta"},{"type":"action","label":"Adicionar tag","config":"interesse-preco"},{"type":"action","label":"Notificar equipe","config":"Canal: vendas"}]',
      true, 487, now() - interval '1 hour'),
    ('e1000000-0000-0000-0000-000000000003', ws_id, 'Comentário no Instagram', 'Responde comentários em Reels no direct',
      'comentario_instagram', '{"post_filter":"reels"}',
      '[{"type":"trigger","label":"Comentário em post/reel"},{"type":"action","label":"Enviar mensagem no direct","config":"Oi! Vi seu comentário. Te mandei uma mensagem no direct com todos os detalhes!"},{"type":"action","label":"Mover card no CRM","config":"Etapa: Novo Lead"}]',
      true, 233, now() - interval '3 hours'),
    ('e1000000-0000-0000-0000-000000000004', ws_id, 'Lead em Proposta Enviada', 'Follow-up automático pós-proposta',
      'etapa_funil', '{"stage":"Proposta Enviada"}',
      '[{"type":"trigger","label":"Lead entrou em: Proposta Enviada"},{"type":"delay","label":"Aguardar 2 dias"},{"type":"condition","label":"Pagou?","yes":"Mover para Ganho","no":"Enviar mensagem: Olá! Conseguiu ver a proposta? Podemos tirar dúvidas!"}]',
      false, 89, now() - interval '2 days');

  INSERT INTO campaigns (id, workspace_id, name, channel, template_name, template_content, segment_type, segment_config, status, scheduled_at, batch_size, batch_interval_minutes, total_recipients, sent_count, delivered_count, read_count, replied_count, failed_count, opt_out_count) VALUES
    ('f1000000-0000-0000-0000-000000000001', ws_id, 'Black Friday - Clientes ativos', 'whatsapp', 'black_friday_25',
      'Olá {{1}}! Black Friday Nexa Flow: 40% OFF no plano anual até sexta. Quer garantir? Responda QUERO e um consultor te atende.',
      'tag', '{"tag":"cliente"}', 'agendada', now() + interval '2 days', 50, 10, 320, 0, 0, 0, 0, 0, 0),
    ('f1000000-0000-0000-0000-000000000002', ws_id, 'Reativação de leads frios', 'whatsapp', 'reativacao_nov',
      'Oi {{1}}! Passando pra saber se ainda tem interesse em automatizar o atendimento da {{2}}. Temos condições especiais esse mês!',
      'tag', '{"tag":"frio"}', 'concluida', now() - interval '5 days', 40, 8, 150, 150, 138, 97, 34, 12, 7),
    ('f1000000-0000-0000-0000-000000000003', ws_id, 'Pesquisa de satisfação - Outubro', 'whatsapp', 'nps_out',
      'Olá {{1}}! De 0 a 10, quanto você recomendaria a Nexa Flow? Sua opinião é muito importante!',
      'etapa_funil', '{"stage":"Ganho"}', 'concluida', now() - interval '15 days', 60, 15, 89, 89, 85, 71, 52, 4, 1),
    ('f1000000-0000-0000-0000-000000000004', ws_id, 'Webinar: IA no Atendimento', 'whatsapp', 'webinar_ia',
      '{{1}}, nosso webinar sobre IA no atendimento é amanhã às 19h! Garanta sua vaga: https://nexaflow.com.br/webinar',
      'todos', '{}', 'em_andamento', now() - interval '2 hours', 30, 5, 210, 145, 132, 88, 41, 9, 3),
    ('f1000000-0000-0000-0000-000000000005', ws_id, 'Renovação Anual - Lote 2', 'whatsapp', 'renovacao_anual',
      'Olá {{1}}! Seu plano renova em breve. Renove agora com 15% OFF e continue com IA e automações. Posso gerar o link?',
      'tag', '{"tag":"renovacao"}', 'rascunho', NULL, 45, 10, 0, 0, 0, 0, 0, 0, 0);

  INSERT INTO payments (id, workspace_id, deal_id, contact_id, amount, method, status, gateway, payment_link, description, paid_at, expires_at, created_at) VALUES
    ('21000000-0000-0000-0000-000000000001', ws_id, '11000000-0000-0000-0000-000000000011', c7,  7200.00, 'pix',         'pago',      'mercadopago', 'https://pay.nexaflow.com.br/xk29dm', 'LM Doces Gourmet - Plano Professional anual', now() - interval '3 days', NULL, now() - interval '4 days'),
    ('21000000-0000-0000-0000-000000000002', ws_id, '11000000-0000-0000-0000-000000000010', c5,  4900.00, 'pix',         'pendente',  'mercadopago', 'https://pay.nexaflow.com.br/pq81mn', 'Studio Pilates Vida - Plano Professional', NULL, now() + interval '1 day', now() - interval '3 hours'),
    ('21000000-0000-0000-0000-000000000003', ws_id, '11000000-0000-0000-0000-000000000009', c2,  8900.00, 'credit_card', 'pendente',  'stripe',      'https://pay.nexaflow.com.br/zw44kl', 'CE Lima Consultoria - Professional anual', NULL, now() + interval '7 days', now() - interval '2 hours'),
    ('21000000-0000-0000-0000-000000000004', ws_id, '11000000-0000-0000-0000-000000000008', c10, 5600.00, 'boleto',      'pendente',  'asaas',       'https://pay.nexaflow.com.br/gh77pp', 'GH Auto Peças - Plano anual', NULL, now() + interval '5 days', now() - interval '1 day'),
    ('21000000-0000-0000-0000-000000000005', ws_id, '11000000-0000-0000-0000-000000000012', c8,  6200.00, 'credit_card', 'falhou',    'stripe',      'https://pay.nexaflow.com.br/pr09xz', 'Prado Imóveis - Professional', NULL, NULL, now() - interval '8 days'),
    ('21000000-0000-0000-0000-000000000006', ws_id, NULL, c1,  2497.00, 'pix',         'pago',      'mercadopago', 'https://pay.nexaflow.com.br/an55tt', 'Padaria Pão Nosso - Setup + 1º mês', now() - interval '10 days', NULL, now() - interval '11 days'),
    ('21000000-0000-0000-0000-000000000007', ws_id, NULL, c4,  18000.00,'credit_card', 'pago',      'stripe',      'https://pay.nexaflow.com.br/tt31vv', 'TechTanque - Implantação Enterprise', now() - interval '20 days', NULL, now() - interval '21 days'),
    ('21000000-0000-0000-0000-000000000008', ws_id, NULL, c9,  3200.00, 'boleto',      'expirado',  'asaas',       'https://pay.nexaflow.com.br/ct88bb', 'CT Fitness - Taxa de adesão', NULL, now() - interval '2 days', now() - interval '12 days');

  INSERT INTO lead_attributions (workspace_id, contact_id, utm_source, utm_medium, utm_campaign, utm_content, utm_term, fbclid, gclid, channel, landing_page, event_type, occurred_at) VALUES
    (ws_id, c1,  'google',   'cpc',      'marca-soft',   'anuncio-1', 'atendimento ia whatsapp', NULL, 'EAIaQw1', 'site_chat', 'https://nexaflow.com.br/',                'primeiro_clique', now() - interval '20 days'),
    (ws_id, c1,  NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'whatsapp', 'https://wa.me/5511999999999', 'conversao', now() - interval '20 days'),
    (ws_id, c2,  'indicacao', 'referral', NULL, NULL, NULL, NULL, NULL, NULL, 'https://nexaflow.com.br/planos', 'primeiro_clique', now() - interval '30 days'),
    (ws_id, c3,  'instagram', 'social',   'reels-out-25', 'reel-8812', NULL, 'FB.abc123', NULL, 'instagram', 'https://instagram.com/nexaflow', 'primeiro_clique', now() - interval '10 hours'),
    (ws_id, c4,  'google',   'organic',  'marca-soft',   NULL, 'crm omnichannel', NULL, 'GID.88z', 'site_chat', 'https://nexaflow.com.br/precos', 'primeiro_clique', now() - interval '35 days'),
    (ws_id, c5,  'facebook', 'ads',      'leads-out-25', 'carousel-2', NULL, 'FB.xy987', NULL, 'whatsapp', 'https://nexaflow.com.br/whatsapp', 'primeiro_clique', now() - interval '25 days'),
    (ws_id, c5,  NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'whatsapp', NULL, 'venda', now() - interval '3 hours'),
    (ws_id, c6,  'instagram', 'social',   'reels-out-25', 'reel-7741', NULL, 'FB.jk456', NULL, 'instagram', 'https://instagram.com/nexaflow', 'primeiro_clique', now() - interval '3 hours'),
    (ws_id, c7,  'google',   'organic',  'marca',        NULL, 'sistema atendimento whatsapp', NULL, NULL, 'whatsapp', 'https://nexaflow.com.br/', 'primeiro_clique', now() - interval '45 days'),
    (ws_id, c7,  NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'whatsapp', NULL, 'venda', now() - interval '3 days'),
    (ws_id, c8,  'google',   'cpc',      'concorrente',  'anuncio-3', 'crm barato', NULL, 'GID.11x', 'site_chat', 'https://nexaflow.com.br/precos', 'primeiro_clique', now() - interval '40 days'),
    (ws_id, c9,  'facebook', 'ads',      'leads-out-25', 'video-1', NULL, 'FB.qq222', NULL, 'whatsapp', 'https://nexaflow.com.br/whatsapp', 'primeiro_clique', now() - interval '15 days'),
    (ws_id, c10, 'facebook', 'ads',      'remarketing',  'static-4', NULL, 'FB.re333', NULL, 'whatsapp', 'https://nexaflow.com.br/planos', 'primeiro_clique', now() - interval '60 days'),
    (ws_id, c11, 'instagram', 'social',   'feed-out-25', 'post-2210', NULL, 'FB.kl777', NULL, 'instagram', 'https://instagram.com/nexaflow', 'primeiro_clique', now() - interval '2 hours'),
    (ws_id, c12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'site_chat', 'https://nexaflow.com.br/enterprise', 'primeiro_clique', now() - interval '30 minutes');

  INSERT INTO webhooks (id, workspace_id, name, url, events, is_active, secret, last_delivery_at, last_status) VALUES
    ('22000000-0000-0000-0000-000000000001', ws_id, 'n8n - Automação Faturamento', 'https://n8n.nexaflow.com.br/webhook/faturamento', ARRAY['lead.created','payment.confirmed','deal.stage_changed'], true, 'whsec_8f3k9d2m', now() - interval '25 minutes', '200 OK'),
    ('22000000-0000-0000-0000-000000000002', ws_id, 'ERP Analytics', 'https://erp.mendeslog.com.br/api/webhooks/nexaflow', ARRAY['lead.created','message.received','payment.confirmed'], true, 'whsec_2m9f8k1d', now() - interval '2 hours', '200 OK'),
    ('22000000-0000-0000-0000-000000000003', ws_id, 'Slack - Alertas de Vendas', 'https://hooks.slack.com/services/T00/B00/nexaflow', ARRAY['deal.stage_changed'], false, 'whsec_7d2k9f3m', now() - interval '5 days', '500 Internal Server Error');

  INSERT INTO api_keys (id, workspace_id, name, key_prefix, key_masked, permissions, last_used_at, is_active) VALUES
    ('23000000-0000-0000-0000-000000000001', ws_id, 'Integração n8n', 'nx_live', 'nx_live_7f3k...9d2m', ARRAY['leads:write','messages:send','flows:trigger','deals:write'], now() - interval '12 minutes', true),
    ('23000000-0000-0000-0000-000000000002', ws_id, 'Site institucional', 'nx_live', 'nx_live_2m8p...4k7n', ARRAY['leads:write'], now() - interval '3 hours', true);
END
$seed$;