/*
# Autenticação real + RLS por workspace + papéis (substitui as políticas "demo_public_access")

## Problema corrigido
A migração original criou, em TODAS as tabelas, a política
  USING (true) WITH CHECK (true) TO anon, authenticated
ou seja: qualquer pessoa com o link do app (chave anon é pública) podia ler, alterar
e apagar dados de todos os workspaces, inclusive telefones, e-mails, mensagens,
pagamentos e segredos de webhook.

## O que esta migração faz
1. Liga `profiles` ao Supabase Auth (`auth_user_id`).
2. Remove TODAS as políticas abertas e revoga todo acesso do papel `anon`.
3. Cria políticas por workspace e por papel (admin / gestor / atendente).
4. Restringe colunas sensíveis (plano/status do workspace, segredo de webhook).
5. Impede deixar o workspace sem nenhum admin ativo.
6. `claim_profile()`: vincula o usuário logado ao convite feito pelo admin (mesmo e-mail,
   e-mail JÁ CONFIRMADO, para impedir sequestro de convite).
7. `create_workspace()`: cria workspace + funil padrão + admin para um usuário novo.

## Matriz de permissões
- atendente: contatos, conversas, mensagens, negócios, respostas rápidas (ler/criar/editar).
- gestor: tudo do atendente + excluir contatos/negócios, funil, agentes de IA, automações,
  campanhas, criar cobranças.
- admin: tudo do gestor + equipe, webhooks, chaves de API, dados do workspace,
  baixa manual de pagamento.
- plano/status/trial do workspace: somente service_role (backend).
*/

-- =====================================================================
-- 1. Vínculo com o Supabase Auth
-- =====================================================================
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS auth_user_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE SET NULL;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_email_lower_uniq ON profiles (lower(email));

ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS infinitepay_handle text;

-- =====================================================================
-- 2. Funções auxiliares (SECURITY DEFINER para não recursar no RLS de profiles)
-- =====================================================================
CREATE OR REPLACE FUNCTION app_workspace_id() RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT workspace_id FROM profiles WHERE auth_user_id = auth.uid() AND is_active LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app_role() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM profiles WHERE auth_user_id = auth.uid() AND is_active LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app_profile_id() RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id FROM profiles WHERE auth_user_id = auth.uid() AND is_active LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app_is_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce((SELECT role = 'admin' FROM profiles WHERE auth_user_id = auth.uid() AND is_active LIMIT 1), false)
$$;

CREATE OR REPLACE FUNCTION app_is_manager() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce((SELECT role IN ('admin','gestor') FROM profiles WHERE auth_user_id = auth.uid() AND is_active LIMIT 1), false)
$$;

REVOKE ALL ON FUNCTION app_workspace_id(), app_role(), app_profile_id(), app_is_admin(), app_is_manager() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION app_workspace_id(), app_role(), app_profile_id(), app_is_admin(), app_is_manager() TO authenticated, service_role;

-- =====================================================================
-- 3. Derrubar as políticas abertas e revogar o acesso anônimo
-- =====================================================================
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'workspaces','profiles','contacts','conversations','messages','quick_replies','pipelines',
    'stages','deals','deal_activities','ai_agents','automations','campaigns','payments',
    'lead_attributions','webhooks','api_keys'
  ] LOOP
    EXECUTE format('DROP POLICY IF EXISTS demo_public_access ON %I', t);
    EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- Tabelas futuras no schema public não devem nascer abertas para anon
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon;

-- =====================================================================
-- 4. Grants mínimos para o papel `authenticated` (o RLS filtra as linhas)
-- =====================================================================
GRANT SELECT ON workspaces TO authenticated;
GRANT UPDATE (name, primary_color, timezone, infinitepay_handle) ON workspaces TO authenticated;

GRANT SELECT ON profiles TO authenticated;
GRANT INSERT (workspace_id, name, email, role, avatar_url, is_active) ON profiles TO authenticated;
GRANT UPDATE (name, role, avatar_url, is_active) ON profiles TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON contacts TO authenticated;
GRANT SELECT, INSERT, UPDATE ON conversations TO authenticated;
GRANT SELECT, INSERT ON messages TO authenticated;
GRANT UPDATE (read_at) ON messages TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON quick_replies TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON pipelines, stages TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON deals TO authenticated;
GRANT SELECT, INSERT ON deal_activities TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON ai_agents, automations, campaigns TO authenticated;
GRANT SELECT, INSERT ON lead_attributions TO authenticated;

GRANT SELECT, INSERT ON payments TO authenticated;
GRANT UPDATE (status, paid_at) ON payments TO authenticated;

-- webhooks: o segredo NUNCA é lido pelo navegador (só via create_webhook, uma vez)
GRANT SELECT (id, workspace_id, name, url, events, is_active, last_delivery_at, last_status, created_at)
  ON webhooks TO authenticated;
GRANT UPDATE (name, url, events, is_active) ON webhooks TO authenticated;
GRANT DELETE ON webhooks TO authenticated;

-- api_keys: só metadados (o hash entra na migração seguinte e fica fora do SELECT)
GRANT SELECT (id, workspace_id, name, key_prefix, key_masked, permissions, last_used_at, is_active, created_at)
  ON api_keys TO authenticated;
GRANT UPDATE (is_active) ON api_keys TO authenticated;
GRANT DELETE ON api_keys TO authenticated;

-- service_role (backend / Edge Functions) mantém acesso total
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;

-- =====================================================================
-- 5. Políticas
-- =====================================================================
-- 5.1 Tabelas de operação: qualquer membro lê/cria/edita dentro do próprio workspace
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['contacts','conversations','messages','deals','deal_activities','lead_attributions','quick_replies'] LOOP
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT TO authenticated USING (workspace_id = (SELECT app_workspace_id()))', t||'_sel', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT TO authenticated WITH CHECK (workspace_id = (SELECT app_workspace_id()))', t||'_ins', t);
  END LOOP;
  FOREACH t IN ARRAY ARRAY['contacts','conversations','messages','deals','quick_replies'] LOOP
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE TO authenticated USING (workspace_id = (SELECT app_workspace_id())) WITH CHECK (workspace_id = (SELECT app_workspace_id()))', t||'_upd', t);
  END LOOP;
END $$;

-- exclusões: contatos/negócios só gestor+; respostas rápidas qualquer membro; mensagens nunca
CREATE POLICY contacts_del ON contacts FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));
CREATE POLICY deals_del ON deals FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));
CREATE POLICY quick_replies_del ON quick_replies FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()));

-- 5.2 Configuração comercial: todos leem, só gestor+ escreve
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['pipelines','stages','ai_agents','automations'] LOOP
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT TO authenticated USING (workspace_id = (SELECT app_workspace_id()))', t||'_sel', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT TO authenticated WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))', t||'_ins', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE TO authenticated USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager())) WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))', t||'_upd', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE TO authenticated USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))', t||'_del', t);
  END LOOP;
END $$;

-- 5.3 Campanhas: somente gestor+
CREATE POLICY campaigns_sel ON campaigns FOR SELECT TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));
CREATE POLICY campaigns_ins ON campaigns FOR INSERT TO authenticated
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));
CREATE POLICY campaigns_upd ON campaigns FOR UPDATE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));
CREATE POLICY campaigns_del ON campaigns FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));

-- 5.4 Pagamentos: todos leem; gestor+ cria cobrança; baixa manual só admin
CREATE POLICY payments_sel ON payments FOR SELECT TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()));
CREATE POLICY payments_ins ON payments FOR INSERT TO authenticated
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));
CREATE POLICY payments_upd ON payments FOR UPDATE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()))
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));

-- 5.5 Workspace e equipe
CREATE POLICY workspaces_sel ON workspaces FOR SELECT TO authenticated
  USING (id = (SELECT app_workspace_id()));
CREATE POLICY workspaces_upd ON workspaces FOR UPDATE TO authenticated
  USING (id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()))
  WITH CHECK (id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));

CREATE POLICY profiles_sel ON profiles FOR SELECT TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()));
CREATE POLICY profiles_ins ON profiles FOR INSERT TO authenticated
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));
CREATE POLICY profiles_upd ON profiles FOR UPDATE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()))
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));

-- 5.6 Integrações: somente admin
CREATE POLICY webhooks_sel ON webhooks FOR SELECT TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));
CREATE POLICY webhooks_upd ON webhooks FOR UPDATE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()))
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));
CREATE POLICY webhooks_del ON webhooks FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));

CREATE POLICY api_keys_sel ON api_keys FOR SELECT TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));
CREATE POLICY api_keys_upd ON api_keys FOR UPDATE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()))
  WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));
CREATE POLICY api_keys_del ON api_keys FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_admin()));

-- =====================================================================
-- 6. Nunca deixar o workspace sem admin ativo
-- =====================================================================
CREATE OR REPLACE FUNCTION guard_last_admin() RETURNS trigger
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF OLD.role = 'admin' AND OLD.is_active
     AND (NEW.role <> 'admin' OR NOT NEW.is_active)
     AND NOT EXISTS (
       SELECT 1 FROM profiles
       WHERE workspace_id = OLD.workspace_id AND role = 'admin' AND is_active AND id <> OLD.id
     ) THEN
    RAISE EXCEPTION 'last_admin: o workspace precisa de pelo menos um admin ativo' USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_guard_last_admin ON profiles;
CREATE TRIGGER trg_guard_last_admin
  BEFORE UPDATE OF role, is_active ON profiles
  FOR EACH ROW EXECUTE FUNCTION guard_last_admin();

-- =====================================================================
-- 7. claim_profile(): vincula o usuário logado ao convite (mesmo e-mail CONFIRMADO)
-- =====================================================================
CREATE OR REPLACE FUNCTION claim_profile() RETURNS SETOF profiles
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text;
  v_confirmed timestamptz;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = '28000';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM profiles WHERE auth_user_id = v_uid) THEN
    SELECT email, email_confirmed_at INTO v_email, v_confirmed FROM auth.users WHERE id = v_uid;
    -- sem e-mail confirmado ninguém assume o convite de outra pessoa
    IF v_confirmed IS NOT NULL THEN
      UPDATE profiles
         SET auth_user_id = v_uid
       WHERE lower(email) = lower(v_email) AND auth_user_id IS NULL AND is_active;
    END IF;
  END IF;

  RETURN QUERY SELECT * FROM profiles WHERE auth_user_id = v_uid AND is_active;
END $$;

REVOKE ALL ON FUNCTION claim_profile() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION claim_profile() TO authenticated;

-- =====================================================================
-- 8. create_workspace(): onboarding de um usuário novo (cria workspace + funil + admin)
-- =====================================================================
CREATE OR REPLACE FUNCTION create_workspace(p_name text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text;
  v_confirmed timestamptz;
  v_meta jsonb;
  v_name text := btrim(coalesce(p_name, ''));
  v_ws uuid := gen_random_uuid();
  v_pipe uuid := gen_random_uuid();
  v_slug text;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = '28000';
  END IF;
  IF char_length(v_name) < 2 OR char_length(v_name) > 80 THEN
    RAISE EXCEPTION 'invalid_name: informe um nome entre 2 e 80 caracteres' USING ERRCODE = 'P0001';
  END IF;
  IF EXISTS (SELECT 1 FROM profiles WHERE auth_user_id = v_uid) THEN
    RAISE EXCEPTION 'already_member: este usuário já pertence a um workspace' USING ERRCODE = 'P0001';
  END IF;

  SELECT email, email_confirmed_at, raw_user_meta_data INTO v_email, v_confirmed, v_meta
    FROM auth.users WHERE id = v_uid;
  IF v_confirmed IS NULL THEN
    RAISE EXCEPTION 'email_not_confirmed: confirme seu e-mail antes de criar o workspace' USING ERRCODE = 'P0001';
  END IF;
  IF EXISTS (SELECT 1 FROM profiles WHERE lower(email) = lower(v_email)) THEN
    RAISE EXCEPTION 'invited: seu e-mail já foi convidado para um workspace; entre novamente para aceitar' USING ERRCODE = 'P0001';
  END IF;

  v_slug := trim(both '-' from regexp_replace(
              translate(lower(v_name), 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc'),
              '[^a-z0-9]+', '-', 'g'));
  v_slug := coalesce(nullif(v_slug, ''), 'workspace') || '-' || substr(md5(random()::text || clock_timestamp()::text), 1, 6);

  INSERT INTO workspaces (id, name, slug, plan, status, trial_ends_at)
  VALUES (v_ws, v_name, v_slug, 'trial', 'active', now() + interval '14 days');

  INSERT INTO profiles (workspace_id, name, email, role, auth_user_id)
  VALUES (v_ws, coalesce(nullif(btrim(v_meta->>'name'), ''), split_part(v_email, '@', 1)), v_email, 'admin', v_uid);

  INSERT INTO pipelines (id, workspace_id, name, is_default) VALUES (v_pipe, v_ws, 'Funil de vendas', true);
  INSERT INTO stages (workspace_id, pipeline_id, name, color, position, is_won, is_lost) VALUES
    (v_ws, v_pipe, 'Novo Lead',            '#64748B', 1, false, false),
    (v_ws, v_pipe, 'Qualificado',          '#0EA5E9', 2, false, false),
    (v_ws, v_pipe, 'Agendado',             '#8B5CF6', 3, false, false),
    (v_ws, v_pipe, 'Proposta Enviada',     '#F59E0B', 4, false, false),
    (v_ws, v_pipe, 'Aguardando Pagamento', '#F97316', 5, false, false),
    (v_ws, v_pipe, 'Ganho',                '#10B981', 6, true,  false),
    (v_ws, v_pipe, 'Perdido',              '#EF4444', 7, false, true);

  RETURN v_ws;
END $$;

REVOKE ALL ON FUNCTION create_workspace(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION create_workspace(text) TO authenticated;
