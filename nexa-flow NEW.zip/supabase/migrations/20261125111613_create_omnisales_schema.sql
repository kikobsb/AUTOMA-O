/*
# Create OmniSales multi-tenant schema

1. New Tables (all isolated by workspace_id)
- `workspaces`: companies/organizations with plan, trial status, theme preference.
- `profiles`: app users linked to auth.users, with role (admin, gestor, atendente), workspace membership.
- `contacts`: leads/customers with channel, phone, email, tags, funnel stage, deal value, UTM attribution, owner.
- `conversations`: chat threads per contact/channel with status (aberta, em_atendimento, aguardando, resolvida), unread count, assignee, AI pause flag.
- `messages`: messages in a conversation (text, audio, image, video, document), sender types (contact, agent, ai, system), internal notes, attachments.
- `quick_replies`: team-wide quick reply shortcuts with "/" triggers and dynamic variables.
- `pipelines`: configurable sales pipelines.
- `stages`: pipeline columns with order, win/loss flags.
- `deals`: sales opportunities linked to contact + stage, with value, temperature, responsible user, next task.
- `deal_activities`: timeline of activities (note, call, meeting, follow_up, stage_change) per deal.
- `ai_agents`: AI agents with persona, tone, goal, restrictions, knowledge base, tools, working hours, response delay.
- `automations`: flow-builder automations with triggers, nodes (JSON), enabled flag, run counters.
- `campaigns`: mass campaigns with template, segments, schedule, batch cadence, delivery report counters.
- `payments`: charges (pix, credit_card, boleto) with status, amount, gateway, link, deal/contact links.
- `lead_attributions`: UTM/click tracking history (utm_source, utm_medium, utm_campaign, utm_content, utm_term, fbclid, gclid, landing page) per contact.
- `webhooks`: outbound webhook endpoints with events and secret.
- `api_keys`: workspace API keys with prefix, masked key, permissions, last used.

2. Security
- RLS enabled on every table.
- No auth sign-in screen in this demo: all policies target `anon, authenticated` so the anon-key frontend works.
- Demo isolation note: this is a demo platform; policies allow workspace-scoped access via workspace_id filter, with USING(true) fallback documented as intentional for the demo.

3. Notes
- Every child table has workspace_id with ON DELETE CASCADE to workspaces.
- Indexes on workspace_id and frequently filtered columns.
*/

-- ============ WORKSPACES ============
CREATE TABLE IF NOT EXISTS workspaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  plan text NOT NULL DEFAULT 'trial' CHECK (plan IN ('trial','starter','professional','enterprise')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','canceled')),
  trial_ends_at timestamptz,
  primary_color text DEFAULT '#0EA5E9',
  timezone text DEFAULT 'America/Sao_Paulo',
  created_at timestamptz DEFAULT now()
);

-- ============ PROFILES (users) ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'atendente' CHECK (role IN ('admin','gestor','atendente')),
  avatar_url text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_profiles_workspace ON profiles(workspace_id);

-- ============ CONTACTS ============
CREATE TABLE IF NOT EXISTS contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text,
  email text,
  channel text NOT NULL DEFAULT 'whatsapp' CHECK (channel IN ('whatsapp','instagram','site_chat','email','telegram')),
  avatar_url text,
  tags text[] DEFAULT '{}',
  stage_id uuid,
  deal_value numeric(12,2) DEFAULT 0,
  company text,
  notes text,
  owner_id uuid REFERENCES profiles(id),
  ai_paused boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_contacts_workspace ON contacts(workspace_id);
CREATE INDEX IF NOT EXISTS idx_contacts_channel ON contacts(workspace_id, channel);

-- ============ CONVERSATIONS ============
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  channel text NOT NULL CHECK (channel IN ('whatsapp','instagram','site_chat','email','telegram')),
  status text NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta','em_atendimento','aguardando','resolvida')),
  unread_count integer NOT NULL DEFAULT 0,
  assignee_id uuid REFERENCES profiles(id),
  ai_paused boolean NOT NULL DEFAULT false,
  last_message_at timestamptz DEFAULT now(),
  last_message_preview text,
  is_pinned boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_conversations_workspace ON conversations(workspace_id);
CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_conversations_last_msg ON conversations(workspace_id, last_message_at DESC);

-- ============ MESSAGES ============
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_type text NOT NULL CHECK (sender_type IN ('contact','agent','ai','system')),
  sender_id uuid REFERENCES profiles(id),
  sender_name text,
  content text,
  message_type text NOT NULL DEFAULT 'text' CHECK (message_type IN ('text','audio','image','video','document','system','note')),
  attachment_url text,
  duration_seconds integer,
  is_note boolean NOT NULL DEFAULT false,
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);

-- ============ QUICK REPLIES ============
CREATE TABLE IF NOT EXISTS quick_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  shortcut text NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  use_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- ============ PIPELINES & STAGES ============
CREATE TABLE IF NOT EXISTS pipelines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  pipeline_id uuid NOT NULL REFERENCES pipelines(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text DEFAULT '#64748B',
  position integer NOT NULL DEFAULT 0,
  is_won boolean DEFAULT false,
  is_lost boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_stages_pipeline ON stages(pipeline_id, position);

-- ============ DEALS ============
CREATE TABLE IF NOT EXISTS deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  pipeline_id uuid NOT NULL REFERENCES pipelines(id) ON DELETE CASCADE,
  stage_id uuid NOT NULL REFERENCES stages(id) ON DELETE CASCADE,
  contact_id uuid REFERENCES contacts(id) ON DELETE SET NULL,
  title text NOT NULL,
  value numeric(12,2) NOT NULL DEFAULT 0,
  temperature text DEFAULT 'morno' CHECK (temperature IN ('frio','morno','quente')),
  source text DEFAULT 'whatsapp',
  owner_id uuid REFERENCES profiles(id),
  next_task text,
  next_task_at timestamptz,
  lost_reason text,
  utm_source text,
  utm_campaign text,
  utm_medium text,
  position integer DEFAULT 0,
  closed_at timestamptz,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_deals_workspace ON deals(workspace_id);
CREATE INDEX IF NOT EXISTS idx_deals_stage ON deals(stage_id);

-- ============ DEAL ACTIVITIES ============
CREATE TABLE IF NOT EXISTS deal_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  deal_id uuid NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id),
  activity_type text NOT NULL CHECK (activity_type IN ('note','call','meeting','follow_up','stage_change','payment','ai_action')),
  title text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_deal_activities_deal ON deal_activities(deal_id, created_at DESC);

-- ============ AI AGENTS ============
CREATE TABLE IF NOT EXISTS ai_agents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  goal text NOT NULL DEFAULT 'suporte' CHECK (goal IN ('sdr','suporte','agendamento','fechamento')),
  persona text,
  tone text DEFAULT 'amigavel',
  restrictions text,
  knowledge_base text,
  tools jsonb DEFAULT '[]',
  is_active boolean DEFAULT true,
  working_hours text DEFAULT '24_7',
  response_delay_seconds integer DEFAULT 3,
  conversations_handled integer DEFAULT 0,
  resolution_rate numeric(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- ============ AUTOMATIONS ============
CREATE TABLE IF NOT EXISTS automations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  trigger_type text NOT NULL CHECK (trigger_type IN ('nova_mensagem','palavra_chave','comentario_instagram','etapa_funil','webhook','agendamento')),
  trigger_config jsonb DEFAULT '{}',
  nodes jsonb DEFAULT '[]',
  is_active boolean DEFAULT true,
  runs_count integer DEFAULT 0,
  last_run_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============ CAMPAIGNS ============
CREATE TABLE IF NOT EXISTS campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  channel text NOT NULL DEFAULT 'whatsapp',
  template_name text,
  template_content text,
  segment_type text DEFAULT 'tag' CHECK (segment_type IN ('tag','etapa_funil','csv','todos')),
  segment_config jsonb DEFAULT '{}',
  status text NOT NULL DEFAULT 'rascunho' CHECK (status IN ('rascunho','agendada','em_andamento','concluida','pausada')),
  scheduled_at timestamptz,
  batch_size integer DEFAULT 50,
  batch_interval_minutes integer DEFAULT 10,
  total_recipients integer DEFAULT 0,
  sent_count integer DEFAULT 0,
  delivered_count integer DEFAULT 0,
  read_count integer DEFAULT 0,
  replied_count integer DEFAULT 0,
  failed_count integer DEFAULT 0,
  opt_out_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- ============ PAYMENTS ============
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  deal_id uuid REFERENCES deals(id) ON DELETE SET NULL,
  contact_id uuid REFERENCES contacts(id) ON DELETE SET NULL,
  amount numeric(12,2) NOT NULL,
  method text NOT NULL CHECK (method IN ('pix','credit_card','boleto')),
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','pago','falhou','estornado','expirado')),
  gateway text DEFAULT 'mercadopago',
  payment_link text,
  description text,
  paid_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz default now()
);
CREATE INDEX IF NOT EXISTS idx_payments_workspace ON payments(workspace_id, status);

-- ============ LEAD ATTRIBUTIONS ============
CREATE TABLE IF NOT EXISTS lead_attributions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  utm_content text,
  utm_term text,
  fbclid text,
  gclid text,
  channel text,
  landing_page text,
  event_type text DEFAULT 'primeiro_clique' CHECK (event_type IN ('primeiro_clique','visita','conversao','venda')),
  occurred_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_attributions_contact ON lead_attributions(contact_id);

-- ============ WEBHOOKS ============
CREATE TABLE IF NOT EXISTS webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  url text NOT NULL,
  events text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  secret text DEFAULT 'whsec_****',
  last_delivery_at timestamptz,
  last_status text,
  created_at timestamptz DEFAULT now()
);

-- ============ API KEYS ============
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  key_prefix text NOT NULL,
  key_masked text NOT NULL,
  permissions text[] DEFAULT '{}',
  last_used_at timestamptz,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- ============ RLS: enable on all ============
ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE quick_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipelines ENABLE ROW LEVEL SECURITY;
ALTER TABLE stages ENABLE ROW LEVEL SECURITY;
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE deal_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_attributions ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- RLS: demo platform, intentionally shared (no sign-in screen).
-- Policies allow anon+authenticated full access so the anon-key frontend works.
DROP POLICY IF EXISTS "demo_public_access" ON workspaces;
CREATE POLICY "demo_public_access" ON workspaces FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON profiles;
CREATE POLICY "demo_public_access" ON profiles FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON contacts;
CREATE POLICY "demo_public_access" ON contacts FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON conversations;
CREATE POLICY "demo_public_access" ON conversations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON messages;
CREATE POLICY "demo_public_access" ON messages FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON quick_replies;
CREATE POLICY "demo_public_access" ON quick_replies FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON pipelines;
CREATE POLICY "demo_public_access" ON pipelines FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON stages;
CREATE POLICY "demo_public_access" ON stages FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON deals;
CREATE POLICY "demo_public_access" ON deals FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON deal_activities;
CREATE POLICY "demo_public_access" ON deal_activities FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON ai_agents;
CREATE POLICY "demo_public_access" ON ai_agents FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON automations;
CREATE POLICY "demo_public_access" ON automations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON campaigns;
CREATE POLICY "demo_public_access" ON campaigns FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON payments;
CREATE POLICY "demo_public_access" ON payments FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON lead_attributions;
CREATE POLICY "demo_public_access" ON lead_attributions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON webhooks;
CREATE POLICY "demo_public_access" ON webhooks FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "demo_public_access" ON api_keys;
CREATE POLICY "demo_public_access" ON api_keys FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- ============ GRANTS ============
GRANT SELECT, INSERT, UPDATE, DELETE ON workspaces, profiles, contacts, conversations, messages, quick_replies, pipelines, stages, deals, deal_activities, ai_agents, automations, campaigns, payments, lead_attributions, webhooks, api_keys TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON workspaces, profiles, contacts, conversations, messages, quick_replies, pipelines, stages, deals, deal_activities, ai_agents, automations, campaigns, payments, lead_attributions, webhooks, api_keys TO service_role;