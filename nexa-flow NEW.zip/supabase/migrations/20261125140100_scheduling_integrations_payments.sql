/*
# Agenda, integrações (n8n / WhatsApp) e pagamentos reais

## Novidades
1. Agenda: services, professionals, availability_rules, appointments.
   - Trava no BANCO contra horário duplicado (EXCLUDE gist) — dois pacientes nunca ocupam o mesmo profissional.
   - get_available_slots() e book_appointment(): a IA só agenda horário que realmente existe.
2. Chaves de API de verdade: só o HASH é guardado; a chave aparece uma única vez ao ser criada.
3. Webhooks de saída: o segredo é gerado no servidor e mostrado uma única vez.
4. ingest_incoming_message() / ingest_ai_reply(): usados pelas Edge Functions.
   - deduplica por external_id (a Meta reenvia eventos);
   - IA NÃO responde quando um humano assumiu (regra aplicada no servidor, não só no n8n).
5. Quando um atendente humano envia mensagem: a IA é pausada naquela conversa e os
   webhooks de saída ativos recebem o evento `message.created` (requer a extensão pg_net).
6. Pagamentos: colunas de conciliação + confirm_payment() (somente service_role).
*/

CREATE EXTENSION IF NOT EXISTS pgcrypto  WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA extensions;

-- =====================================================================
-- 1. Identificadores externos (deduplicação) e unicidade de contatos
-- =====================================================================
ALTER TABLE messages ADD COLUMN IF NOT EXISTS external_id text;
CREATE UNIQUE INDEX IF NOT EXISTS messages_ws_external_uniq
  ON messages (workspace_id, external_id) WHERE external_id IS NOT NULL;

ALTER TABLE contacts ADD COLUMN IF NOT EXISTS external_id text;
CREATE UNIQUE INDEX IF NOT EXISTS contacts_ws_channel_external_uniq
  ON contacts (workspace_id, channel, external_id) WHERE external_id IS NOT NULL;

-- =====================================================================
-- 2. Agenda
-- =====================================================================
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  duration_minutes integer NOT NULL CHECK (duration_minutes BETWEEN 5 AND 600),
  price numeric(12,2) CHECK (price IS NULL OR price >= 0),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_services_workspace ON services(workspace_id);

CREATE TABLE IF NOT EXISTS professionals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_professionals_workspace ON professionals(workspace_id);

-- weekday: 0 = domingo ... 6 = sábado (mesmo padrão de extract(dow))
CREATE TABLE IF NOT EXISTS availability_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  professional_id uuid NOT NULL REFERENCES professionals(id) ON DELETE CASCADE,
  weekday smallint NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_time time NOT NULL,
  end_time time NOT NULL,
  CHECK (end_time > start_time)
);
CREATE INDEX IF NOT EXISTS idx_availability_professional ON availability_rules(professional_id, weekday);

CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  professional_id uuid NOT NULL REFERENCES professionals(id) ON DELETE RESTRICT,
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'agendado'
    CHECK (status IN ('agendado','confirmado','compareceu','faltou','cancelado')),
  source text NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','ia','site')),
  notes text,
  created_by uuid REFERENCES profiles(id),
  reminder_24h_sent_at timestamptz,
  reminder_2h_sent_at timestamptz,
  created_at timestamptz DEFAULT now(),
  CHECK (ends_at > starts_at),
  CONSTRAINT appointments_no_overlap EXCLUDE USING gist (
    professional_id WITH =,
    tstzrange(starts_at, ends_at) WITH &&
  ) WHERE (status IN ('agendado','confirmado'))
);
CREATE INDEX IF NOT EXISTS idx_appointments_ws_start ON appointments(workspace_id, starts_at);
CREATE INDEX IF NOT EXISTS idx_appointments_contact ON appointments(contact_id);

-- integridade entre workspaces: profissional/serviço/contato precisam ser do MESMO workspace
CREATE OR REPLACE FUNCTION appointments_integrity() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM professionals WHERE id = NEW.professional_id AND workspace_id = NEW.workspace_id)
     OR NOT EXISTS (SELECT 1 FROM services WHERE id = NEW.service_id AND workspace_id = NEW.workspace_id)
     OR NOT EXISTS (SELECT 1 FROM contacts WHERE id = NEW.contact_id AND workspace_id = NEW.workspace_id) THEN
    RAISE EXCEPTION 'cross_workspace_reference' USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_appointments_integrity ON appointments;
CREATE TRIGGER trg_appointments_integrity
  BEFORE INSERT OR UPDATE OF workspace_id, contact_id, professional_id, service_id ON appointments
  FOR EACH ROW EXECUTE FUNCTION appointments_integrity();

ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE availability_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON services, professionals, availability_rules, appointments FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON services, professionals, availability_rules TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON appointments TO authenticated;
GRANT ALL ON services, professionals, availability_rules, appointments TO service_role;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['services','professionals','availability_rules'] LOOP
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT TO authenticated USING (workspace_id = (SELECT app_workspace_id()))', t||'_sel', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT TO authenticated WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))', t||'_ins', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE TO authenticated USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager())) WITH CHECK (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))', t||'_upd', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE TO authenticated USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()))', t||'_del', t);
  END LOOP;
END $$;

CREATE POLICY appointments_sel ON appointments FOR SELECT TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()));
CREATE POLICY appointments_ins ON appointments FOR INSERT TO authenticated
  WITH CHECK (workspace_id = (SELECT app_workspace_id()));
CREATE POLICY appointments_upd ON appointments FOR UPDATE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()))
  WITH CHECK (workspace_id = (SELECT app_workspace_id()));
CREATE POLICY appointments_del ON appointments FOR DELETE TO authenticated
  USING (workspace_id = (SELECT app_workspace_id()) AND (SELECT app_is_manager()));

-- ---------------------------------------------------------------------
-- Horários livres (SECURITY INVOKER: para usuário logado o RLS filtra por workspace)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION get_available_slots(
  p_workspace uuid,
  p_service uuid,
  p_from date,
  p_to date,
  p_professional uuid DEFAULT NULL,
  p_step_minutes integer DEFAULT 30
) RETURNS TABLE (professional_id uuid, professional_name text, starts_at timestamptz, ends_at timestamptz)
LANGUAGE plpgsql STABLE SET search_path = public AS $$
DECLARE
  v_dur integer;
  v_tz text;
BEGIN
  IF p_to < p_from OR p_to - p_from > 31 THEN
    RAISE EXCEPTION 'invalid_range: use no máximo 31 dias' USING ERRCODE = 'P0001';
  END IF;
  IF p_step_minutes < 5 OR p_step_minutes > 240 THEN
    RAISE EXCEPTION 'invalid_step' USING ERRCODE = 'P0001';
  END IF;

  SELECT s.duration_minutes INTO v_dur
    FROM services s WHERE s.id = p_service AND s.workspace_id = p_workspace AND s.is_active;
  IF v_dur IS NULL THEN RETURN; END IF;

  SELECT coalesce(w.timezone, 'America/Sao_Paulo') INTO v_tz FROM workspaces w WHERE w.id = p_workspace;
  IF v_tz IS NULL THEN RETURN; END IF;

  RETURN QUERY
  WITH days AS (
    SELECT d::date AS day FROM generate_series(p_from::timestamp, p_to::timestamp, interval '1 day') d
  ),
  windows AS (
    SELECT pr.id AS pid, pr.name AS pname,
           ((days.day + r.start_time) AT TIME ZONE v_tz) AS w_start,
           ((days.day + r.end_time)   AT TIME ZONE v_tz) AS w_end
      FROM days
      JOIN availability_rules r
        ON r.workspace_id = p_workspace AND r.weekday = extract(dow FROM days.day)::int
      JOIN professionals pr
        ON pr.id = r.professional_id AND pr.workspace_id = p_workspace AND pr.is_active
     WHERE p_professional IS NULL OR pr.id = p_professional
  ),
  slots AS (
    SELECT DISTINCT w.pid, w.pname, g AS s_start, g + make_interval(mins => v_dur) AS s_end
      FROM windows w,
           LATERAL generate_series(w.w_start, w.w_end - make_interval(mins => v_dur),
                                   make_interval(mins => p_step_minutes)) g
  )
  SELECT sl.pid, sl.pname, sl.s_start, sl.s_end
    FROM slots sl
   WHERE sl.s_start >= now() + interval '1 hour'
     AND NOT EXISTS (
       SELECT 1 FROM appointments a
        WHERE a.professional_id = sl.pid
          AND a.status IN ('agendado','confirmado')
          AND tstzrange(a.starts_at, a.ends_at) && tstzrange(sl.s_start, sl.s_end)
     )
   ORDER BY sl.s_start, sl.pname;
END $$;

-- ---------------------------------------------------------------------
-- Agendar: valida contra a disponibilidade real e confia na trava do banco contra corrida
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION book_appointment(
  p_workspace uuid,
  p_contact uuid,
  p_service uuid,
  p_professional uuid,
  p_starts_at timestamptz,
  p_source text DEFAULT 'manual',
  p_notes text DEFAULT NULL,
  p_created_by uuid DEFAULT NULL
) RETURNS appointments
LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  v_dur integer;
  v_tz text;
  v_day date;
  v_row appointments;
BEGIN
  SELECT s.duration_minutes INTO v_dur
    FROM services s WHERE s.id = p_service AND s.workspace_id = p_workspace AND s.is_active;
  IF v_dur IS NULL THEN
    RAISE EXCEPTION 'service_not_found' USING ERRCODE = 'P0001';
  END IF;
  SELECT coalesce(w.timezone, 'America/Sao_Paulo') INTO v_tz FROM workspaces w WHERE w.id = p_workspace;
  v_day := (p_starts_at AT TIME ZONE v_tz)::date;

  -- grade de 5 em 5 minutos: aceita qualquer horário que caiba na jornada e não colida
  IF NOT EXISTS (
    SELECT 1 FROM get_available_slots(p_workspace, p_service, v_day, v_day, p_professional, 5) s
     WHERE s.starts_at = p_starts_at
  ) THEN
    RAISE EXCEPTION 'slot_unavailable: horário fora da agenda ou já ocupado' USING ERRCODE = 'P0001';
  END IF;

  BEGIN
    INSERT INTO appointments (workspace_id, contact_id, professional_id, service_id,
                              starts_at, ends_at, source, notes, created_by)
    VALUES (p_workspace, p_contact, p_professional, p_service,
            p_starts_at, p_starts_at + make_interval(mins => v_dur),
            CASE WHEN p_source IN ('manual','ia','site') THEN p_source ELSE 'manual' END,
            p_notes, p_created_by)
    RETURNING * INTO v_row;
  EXCEPTION WHEN exclusion_violation THEN
    RAISE EXCEPTION 'slot_unavailable: horário acabou de ser ocupado' USING ERRCODE = 'P0001';
  END;

  RETURN v_row;
END $$;

REVOKE ALL ON FUNCTION get_available_slots(uuid,uuid,date,date,uuid,integer) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION book_appointment(uuid,uuid,uuid,uuid,timestamptz,text,text,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION get_available_slots(uuid,uuid,date,date,uuid,integer) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION book_appointment(uuid,uuid,uuid,uuid,timestamptz,text,text,uuid) TO authenticated, service_role;

-- =====================================================================
-- 3. Chaves de API (somente hash) e webhooks (segredo gerado no servidor)
-- =====================================================================
ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS key_hash text UNIQUE;

CREATE OR REPLACE FUNCTION create_api_key(p_name text, p_permissions text[]) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE
  v_ws uuid := app_workspace_id();
  v_key text;
  v_id uuid;
  v_allowed text[] := ARRAY['messages:write','appointments:read','appointments:write','payments:write'];
BEGIN
  IF NOT app_is_admin() THEN
    RAISE EXCEPTION 'forbidden' USING ERRCODE = '42501';
  END IF;
  IF btrim(coalesce(p_name, '')) = '' THEN
    RAISE EXCEPTION 'invalid_name' USING ERRCODE = 'P0001';
  END IF;
  IF p_permissions IS NULL OR cardinality(p_permissions) = 0 OR NOT (p_permissions <@ v_allowed) THEN
    RAISE EXCEPTION 'invalid_permissions: use %', v_allowed USING ERRCODE = 'P0001';
  END IF;

  v_key := 'nxf_' || encode(gen_random_bytes(24), 'hex');
  INSERT INTO api_keys (workspace_id, name, key_prefix, key_masked, permissions, key_hash)
  VALUES (v_ws, btrim(p_name), left(v_key, 8), left(v_key, 8) || '…' || right(v_key, 4),
          p_permissions, encode(digest(v_key, 'sha256'), 'hex'))
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('id', v_id, 'api_key', v_key);
END $$;

-- usada SOMENTE pelas Edge Functions (service_role)
CREATE OR REPLACE FUNCTION verify_api_key(p_key text)
RETURNS TABLE (key_id uuid, workspace_id uuid, permissions text[])
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
BEGIN
  IF p_key IS NULL OR p_key !~ '^nxf_[0-9a-f]{48}$' THEN RETURN; END IF;
  RETURN QUERY
    WITH hit AS (
      SELECT k.id, k.workspace_id, k.permissions, k.last_used_at
        FROM api_keys k
        JOIN workspaces w ON w.id = k.workspace_id AND w.status = 'active'
       WHERE k.key_hash = encode(digest(p_key, 'sha256'), 'hex') AND k.is_active
    ), touch AS (
      UPDATE api_keys k SET last_used_at = now()
        FROM hit WHERE k.id = hit.id AND (hit.last_used_at IS NULL OR hit.last_used_at < now() - interval '1 minute')
    )
    SELECT hit.id, hit.workspace_id, hit.permissions FROM hit;
END $$;

CREATE OR REPLACE FUNCTION create_webhook(p_name text, p_url text, p_events text[]) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE
  v_ws uuid := app_workspace_id();
  v_secret text;
  v_id uuid;
  v_allowed text[] := ARRAY['message.created'];
BEGIN
  IF NOT app_is_admin() THEN
    RAISE EXCEPTION 'forbidden' USING ERRCODE = '42501';
  END IF;
  IF btrim(coalesce(p_name, '')) = '' THEN
    RAISE EXCEPTION 'invalid_name' USING ERRCODE = 'P0001';
  END IF;
  IF p_url IS NULL OR p_url !~* '^https://[^/\s]+' THEN
    RAISE EXCEPTION 'invalid_url: use uma URL https://' USING ERRCODE = 'P0001';
  END IF;
  IF p_events IS NULL OR cardinality(p_events) = 0 OR NOT (p_events <@ v_allowed) THEN
    RAISE EXCEPTION 'invalid_events: use %', v_allowed USING ERRCODE = 'P0001';
  END IF;

  v_secret := 'whsec_' || encode(gen_random_bytes(24), 'hex');
  INSERT INTO webhooks (workspace_id, name, url, events, secret)
  VALUES (v_ws, btrim(p_name), p_url, p_events, v_secret)
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('id', v_id, 'secret', v_secret);
END $$;

REVOKE ALL ON FUNCTION create_api_key(text, text[]), verify_api_key(text), create_webhook(text, text, text[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION create_api_key(text, text[]), create_webhook(text, text, text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION verify_api_key(text) TO service_role;

-- =====================================================================
-- 4. Ingestão de mensagens (Edge Functions → service_role)
-- =====================================================================
CREATE OR REPLACE FUNCTION ingest_incoming_message(
  p_workspace uuid,
  p_channel text,
  p_external_contact_id text,
  p_contact_name text,
  p_phone text,
  p_content text,
  p_external_id text,
  p_message_type text DEFAULT 'text',
  p_attachment_url text DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_contact_id uuid;
  v_contact_paused boolean;
  v_conv_id uuid;
  v_conv_paused boolean;
  v_conv_status text;
  v_msg_id uuid;
  v_dup boolean := false;
  v_phone text;
  v_name text;
  v_pipe uuid;
  v_stage uuid;
  v_history jsonb;
  v_agent jsonb;
  v_services jsonb;
  v_ws jsonb;
BEGIN
  IF p_channel NOT IN ('whatsapp','instagram','site_chat','email','telegram') THEN
    RAISE EXCEPTION 'invalid_channel' USING ERRCODE = 'P0001';
  END IF;
  IF btrim(coalesce(p_external_contact_id, '')) = '' OR btrim(coalesce(p_external_id, '')) = '' THEN
    RAISE EXCEPTION 'external ids are required' USING ERRCODE = 'P0001';
  END IF;
  IF p_message_type NOT IN ('text','audio','image','video','document') THEN
    RAISE EXCEPTION 'invalid_message_type' USING ERRCODE = 'P0001';
  END IF;
  IF char_length(coalesce(p_content, '')) > 4000 THEN
    RAISE EXCEPTION 'content_too_long' USING ERRCODE = 'P0001';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM workspaces WHERE id = p_workspace AND status = 'active') THEN
    RAISE EXCEPTION 'workspace_inactive' USING ERRCODE = 'P0001';
  END IF;

  -- serializa por contato: evita contato/conversa duplicados com mensagens simultâneas
  PERFORM pg_advisory_xact_lock(hashtextextended(p_workspace::text || '|' || p_channel || '|' || p_external_contact_id, 0));

  -- 4.1 deduplicação (a Meta reenvia webhooks)
  SELECT m.id, m.conversation_id INTO v_msg_id, v_conv_id
    FROM messages m WHERE m.workspace_id = p_workspace AND m.external_id = p_external_id;
  IF FOUND THEN
    v_dup := true;
    SELECT c.contact_id, c.ai_paused INTO v_contact_id, v_conv_paused FROM conversations c WHERE c.id = v_conv_id;
  ELSE
    -- 4.2 contato
    SELECT id, ai_paused INTO v_contact_id, v_contact_paused
      FROM contacts WHERE workspace_id = p_workspace AND channel = p_channel AND external_id = p_external_contact_id;

    IF v_contact_id IS NULL THEN
      v_phone := nullif(btrim(coalesce(p_phone, '')), '');
      IF v_phone IS NULL AND p_channel = 'whatsapp' AND p_external_contact_id ~ '^[0-9]{8,15}$' THEN
        v_phone := '+' || p_external_contact_id;
      END IF;
      v_name := coalesce(nullif(btrim(coalesce(p_contact_name, '')), ''), 'Contato ' || right(p_external_contact_id, 4));

      SELECT id INTO v_pipe FROM pipelines WHERE workspace_id = p_workspace ORDER BY is_default DESC, created_at LIMIT 1;
      IF v_pipe IS NOT NULL THEN
        SELECT id INTO v_stage FROM stages WHERE pipeline_id = v_pipe AND NOT is_won AND NOT is_lost ORDER BY position LIMIT 1;
      END IF;

      INSERT INTO contacts (workspace_id, name, phone, channel, external_id, stage_id)
      VALUES (p_workspace, left(v_name, 120), v_phone, p_channel, p_external_contact_id, v_stage)
      RETURNING id, ai_paused INTO v_contact_id, v_contact_paused;

      IF v_pipe IS NOT NULL AND v_stage IS NOT NULL THEN
        INSERT INTO deals (workspace_id, pipeline_id, stage_id, contact_id, title, source)
        VALUES (p_workspace, v_pipe, v_stage, v_contact_id, 'Novo lead — ' || left(v_name, 80), p_channel);
      END IF;
    END IF;

    -- 4.3 conversa (reaproveita a mais recente do contato/canal; reabre se estava resolvida)
    SELECT id, ai_paused, status INTO v_conv_id, v_conv_paused, v_conv_status
      FROM conversations WHERE workspace_id = p_workspace AND contact_id = v_contact_id AND channel = p_channel
      ORDER BY created_at DESC LIMIT 1;

    IF v_conv_id IS NULL THEN
      INSERT INTO conversations (workspace_id, contact_id, channel, status)
      VALUES (p_workspace, v_contact_id, p_channel, 'aberta')
      RETURNING id, ai_paused INTO v_conv_id, v_conv_paused;
    ELSIF v_conv_status = 'resolvida' THEN
      UPDATE conversations SET status = 'aberta' WHERE id = v_conv_id;
    END IF;

    -- 4.4 mensagem
    INSERT INTO messages (workspace_id, conversation_id, sender_type, sender_name, content,
                          message_type, attachment_url, external_id)
    VALUES (p_workspace, v_conv_id, 'contact',
            (SELECT name FROM contacts WHERE id = v_contact_id),
            p_content, p_message_type, p_attachment_url, p_external_id)
    RETURNING id INTO v_msg_id;

    UPDATE conversations
       SET unread_count = unread_count + 1,
           last_message_at = now(),
           last_message_preview = left(coalesce(nullif(p_content, ''), '[' || p_message_type || ']'), 80)
     WHERE id = v_conv_id;
  END IF;

  -- 4.5 contexto para o agente de IA (n8n): histórico, persona e serviços cadastrados
  SELECT coalesce(jsonb_agg(h ORDER BY h.created_at), '[]'::jsonb) INTO v_history
    FROM (SELECT sender_type, content, created_at FROM messages
           WHERE conversation_id = v_conv_id AND NOT is_note AND message_type <> 'system'
           ORDER BY created_at DESC LIMIT 12) h;

  SELECT jsonb_build_object('name', a.name, 'goal', a.goal, 'persona', a.persona, 'tone', a.tone,
                            'restrictions', a.restrictions, 'knowledge_base', a.knowledge_base)
    INTO v_agent FROM ai_agents a WHERE a.workspace_id = p_workspace AND a.is_active ORDER BY a.created_at LIMIT 1;

  SELECT coalesce(jsonb_agg(jsonb_build_object('id', s.id, 'name', s.name,
                            'duration_minutes', s.duration_minutes, 'price', s.price) ORDER BY s.name), '[]'::jsonb)
    INTO v_services FROM services s WHERE s.workspace_id = p_workspace AND s.is_active;

  SELECT jsonb_build_object('name', w.name, 'timezone', w.timezone) INTO v_ws FROM workspaces w WHERE w.id = p_workspace;

  SELECT ai_paused INTO v_contact_paused FROM contacts WHERE id = v_contact_id;
  SELECT ai_paused INTO v_conv_paused FROM conversations WHERE id = v_conv_id;

  RETURN jsonb_build_object(
    'duplicate', v_dup,
    'contact_id', v_contact_id,
    'conversation_id', v_conv_id,
    'message_id', v_msg_id,
    -- se um humano assumiu (ou a IA foi pausada no contato), o n8n NÃO deve responder
    'ai_paused', coalesce(v_conv_paused, false) OR coalesce(v_contact_paused, false),
    'history', v_history,
    'agent', v_agent,
    'services', v_services,
    'workspace', v_ws
  );
END $$;

CREATE OR REPLACE FUNCTION ingest_ai_reply(
  p_workspace uuid,
  p_conversation uuid,
  p_content text,
  p_needs_human boolean DEFAULT false,
  p_external_id text DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_paused boolean;
  v_contact_paused boolean;
  v_agent_name text;
  v_msg_id uuid;
BEGIN
  IF btrim(coalesce(p_content, '')) = '' OR char_length(p_content) > 4000 THEN
    RAISE EXCEPTION 'invalid_content' USING ERRCODE = 'P0001';
  END IF;

  SELECT c.ai_paused, ct.ai_paused INTO v_paused, v_contact_paused
    FROM conversations c JOIN contacts ct ON ct.id = c.contact_id
   WHERE c.id = p_conversation AND c.workspace_id = p_workspace
   FOR UPDATE OF c;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'conversation_not_found' USING ERRCODE = 'P0001';
  END IF;

  -- humano no comando: a resposta da IA é descartada no servidor
  IF v_paused OR v_contact_paused THEN
    RETURN jsonb_build_object('skipped', 'ai_paused');
  END IF;

  IF p_external_id IS NOT NULL THEN
    SELECT id INTO v_msg_id FROM messages WHERE workspace_id = p_workspace AND external_id = p_external_id;
    IF FOUND THEN
      RETURN jsonb_build_object('skipped', 'duplicate', 'message_id', v_msg_id);
    END IF;
  END IF;

  SELECT name INTO v_agent_name FROM ai_agents WHERE workspace_id = p_workspace AND is_active ORDER BY created_at LIMIT 1;

  INSERT INTO messages (workspace_id, conversation_id, sender_type, sender_name, content, external_id)
  VALUES (p_workspace, p_conversation, 'ai', coalesce(v_agent_name, 'Assistente IA'), p_content, p_external_id)
  RETURNING id INTO v_msg_id;

  UPDATE conversations
     SET last_message_at = now(),
         last_message_preview = left(p_content, 80),
         unread_count = 0
   WHERE id = p_conversation;

  IF p_needs_human THEN
    UPDATE conversations SET ai_paused = true, status = 'aguardando' WHERE id = p_conversation;
    INSERT INTO messages (workspace_id, conversation_id, sender_type, sender_name, content, message_type)
    VALUES (p_workspace, p_conversation, 'system', 'Sistema', 'A IA transferiu esta conversa para um atendente humano.', 'system');
  END IF;

  RETURN jsonb_build_object('skipped', false, 'message_id', v_msg_id, 'handoff', p_needs_human);
END $$;

REVOKE ALL ON FUNCTION ingest_incoming_message(uuid,text,text,text,text,text,text,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION ingest_ai_reply(uuid,uuid,text,boolean,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION ingest_incoming_message(uuid,text,text,text,text,text,text,text,text) TO service_role;
GRANT EXECUTE ON FUNCTION ingest_ai_reply(uuid,uuid,text,boolean,text) TO service_role;

-- =====================================================================
-- 5. Atendente humano respondeu: pausa a IA e notifica os webhooks de saída
-- =====================================================================
CREATE OR REPLACE FUNCTION on_agent_message_inserted() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE
  w record;
  v_payload jsonb;
BEGIN
  UPDATE conversations SET ai_paused = true WHERE id = NEW.conversation_id AND NOT ai_paused;

  SELECT jsonb_build_object(
           'event', 'message.created',
           'workspace_id', NEW.workspace_id,
           'conversation_id', NEW.conversation_id,
           'channel', c.channel,
           'contact', jsonb_build_object('id', ct.id, 'name', ct.name, 'phone', ct.phone, 'external_id', ct.external_id),
           'message', jsonb_build_object('id', NEW.id, 'content', NEW.content, 'sender_name', NEW.sender_name,
                                         'created_at', NEW.created_at))
    INTO v_payload
    FROM conversations c JOIN contacts ct ON ct.id = c.contact_id
   WHERE c.id = NEW.conversation_id;

  FOR w IN
    SELECT url, secret FROM webhooks
     WHERE workspace_id = NEW.workspace_id AND is_active AND 'message.created' = ANY(events)
  LOOP
    BEGIN
      -- pg_net (assíncrono). Se a extensão não estiver ativa, não bloqueia o envio da mensagem.
      EXECUTE 'SELECT net.http_post(url := $1, body := $2, headers := $3)'
        USING w.url, v_payload,
              jsonb_build_object('Content-Type', 'application/json', 'X-Webhook-Secret', w.secret);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END LOOP;

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_on_agent_message ON messages;
CREATE TRIGGER trg_on_agent_message
  AFTER INSERT ON messages
  FOR EACH ROW WHEN (NEW.sender_type = 'agent' AND NOT NEW.is_note)
  EXECUTE FUNCTION on_agent_message_inserted();

-- =====================================================================
-- 6. Pagamentos: conciliação com o gateway (InfinitePay)
-- =====================================================================
ALTER TABLE payments ADD COLUMN IF NOT EXISTS gateway_ref text;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS receipt_url text;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS paid_amount numeric(12,2);
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_method_check;
ALTER TABLE payments ADD CONSTRAINT payments_method_check CHECK (method IN ('pix','credit_card','boleto','checkout'));

-- Confirma o pagamento SOMENTE depois que a Edge Function validou no gateway (payment_check).
-- Idempotente: reentrega do webhook não duplica nada.
CREATE OR REPLACE FUNCTION confirm_payment(
  p_payment uuid,
  p_amount_cents integer,
  p_paid_amount_cents integer,
  p_gateway_ref text,
  p_receipt_url text,
  p_capture_method text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_pay payments;
BEGIN
  SELECT * INTO v_pay FROM payments WHERE id = p_payment FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'payment_not_found' USING ERRCODE = 'P0001';
  END IF;
  IF v_pay.status = 'pago' THEN
    RETURN jsonb_build_object('already_paid', true);
  END IF;
  IF round(v_pay.amount * 100)::integer <> p_amount_cents THEN
    RAISE EXCEPTION 'amount_mismatch' USING ERRCODE = 'P0001';
  END IF;
  IF p_paid_amount_cents < p_amount_cents THEN
    RAISE EXCEPTION 'underpaid' USING ERRCODE = 'P0001';
  END IF;

  UPDATE payments
     SET status = 'pago',
         paid_at = now(),
         paid_amount = p_paid_amount_cents / 100.0,
         gateway_ref = p_gateway_ref,
         receipt_url = p_receipt_url,
         method = CASE WHEN p_capture_method IN ('pix','credit_card','boleto') THEN p_capture_method ELSE method END
   WHERE id = p_payment;

  IF v_pay.deal_id IS NOT NULL THEN
    INSERT INTO deal_activities (workspace_id, deal_id, activity_type, title, description)
    VALUES (v_pay.workspace_id, v_pay.deal_id, 'payment', 'Pagamento confirmado',
            'Confirmado pelo gateway: R$ ' || to_char(p_paid_amount_cents / 100.0, 'FM999G999G990D00'));
  END IF;

  RETURN jsonb_build_object('already_paid', false, 'workspace_id', v_pay.workspace_id);
END $$;

REVOKE ALL ON FUNCTION confirm_payment(uuid,integer,integer,text,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION confirm_payment(uuid,integer,integer,text,text,text) TO service_role;

-- =====================================================================
-- 7. Integridade entre workspaces
-- Sem isto, um usuário poderia gravar uma linha do SEU workspace apontando para o UUID
-- de uma conversa/contato/negócio de OUTRO workspace (quebra o isolamento por referência).
-- =====================================================================
CREATE OR REPLACE FUNCTION enforce_same_workspace() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  i integer := 0;
  v_parent_id uuid;
  v_ws uuid;
BEGIN
  WHILE i < TG_NARGS LOOP
    v_parent_id := nullif(to_jsonb(NEW) ->> TG_ARGV[i + 1], '')::uuid;
    IF v_parent_id IS NOT NULL THEN
      EXECUTE format('SELECT workspace_id FROM public.%I WHERE id = $1', TG_ARGV[i]) INTO v_ws USING v_parent_id;
      IF v_ws IS DISTINCT FROM NEW.workspace_id THEN
        RAISE EXCEPTION 'cross_workspace_reference: %.%', TG_TABLE_NAME, TG_ARGV[i + 1] USING ERRCODE = 'P0001';
      END IF;
    END IF;
    i := i + 2;
  END LOOP;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_ws_messages ON messages;
CREATE TRIGGER trg_ws_messages BEFORE INSERT OR UPDATE OF workspace_id, conversation_id ON messages
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('conversations', 'conversation_id');

DROP TRIGGER IF EXISTS trg_ws_conversations ON conversations;
CREATE TRIGGER trg_ws_conversations BEFORE INSERT OR UPDATE OF workspace_id, contact_id, assignee_id ON conversations
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('contacts', 'contact_id', 'profiles', 'assignee_id');

DROP TRIGGER IF EXISTS trg_ws_contacts ON contacts;
CREATE TRIGGER trg_ws_contacts BEFORE INSERT OR UPDATE OF workspace_id, owner_id ON contacts
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('profiles', 'owner_id');

DROP TRIGGER IF EXISTS trg_ws_deals ON deals;
CREATE TRIGGER trg_ws_deals BEFORE INSERT OR UPDATE OF workspace_id, pipeline_id, stage_id, contact_id, owner_id ON deals
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('pipelines', 'pipeline_id', 'stages', 'stage_id', 'contacts', 'contact_id', 'profiles', 'owner_id');

DROP TRIGGER IF EXISTS trg_ws_deal_activities ON deal_activities;
CREATE TRIGGER trg_ws_deal_activities BEFORE INSERT OR UPDATE OF workspace_id, deal_id, user_id ON deal_activities
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('deals', 'deal_id', 'profiles', 'user_id');

DROP TRIGGER IF EXISTS trg_ws_payments ON payments;
CREATE TRIGGER trg_ws_payments BEFORE INSERT OR UPDATE OF workspace_id, deal_id, contact_id ON payments
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('deals', 'deal_id', 'contacts', 'contact_id');

DROP TRIGGER IF EXISTS trg_ws_lead_attr ON lead_attributions;
CREATE TRIGGER trg_ws_lead_attr BEFORE INSERT OR UPDATE OF workspace_id, contact_id ON lead_attributions
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('contacts', 'contact_id');

DROP TRIGGER IF EXISTS trg_ws_stages ON stages;
CREATE TRIGGER trg_ws_stages BEFORE INSERT OR UPDATE OF workspace_id, pipeline_id ON stages
  FOR EACH ROW EXECUTE FUNCTION enforce_same_workspace('pipelines', 'pipeline_id');
