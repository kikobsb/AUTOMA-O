# Nexa Flow — colocar no ar (ordem importa)

## 0. Antes de tudo
- **Gire as chaves do Supabase** (Project Settings → API). As do projeto antigo circularam em prints/ZIP.
- Authentication → Providers → Email: **"Confirm email" LIGADO**. (O vínculo de convite depende de e-mail confirmado.)
- Database → Extensions: ative **pg_net** (webhooks de saída) e confirme `pgcrypto`, `btree_gist`.
- Authentication → URL Configuration: coloque a URL do app em Site URL e Redirect URLs.

## 1. Banco
Rode, em ordem, no SQL Editor (ou `supabase db push`):
1. `20261125111613_create_omnisales_schema.sql`
2. `20261125140000_auth_and_rls_hardening.sql`
3. `20261125140100_scheduling_integrations_payments.sql`

NÃO rode `..._seed_omnisales_demo_data.sql` em produção. Se já rodou: `DELETE FROM workspaces WHERE slug = 'nexa-flow';`
(as chaves de API do seed não têm hash e não funcionam).

## 2. Edge Functions
```
supabase functions deploy incoming-message ai-reply availability book-appointment create-payment-link infinitepay-webhook
supabase secrets set \
  INFINITEPAY_WEBHOOK_SECRET=$(openssl rand -hex 32) \
  PUBLIC_FUNCTIONS_URL=https://SEU-PROJETO.supabase.co/functions/v1 \
  ALLOWED_ORIGINS=https://app.seudominio.com \
  APP_URL=https://app.seudominio.com
```
`SUPABASE_URL`, `SUPABASE_ANON_KEY` e `SUPABASE_SERVICE_ROLE_KEY` já existem nas funções. A service role NUNCA vai no front nem no n8n.

## 3. Front
`cp .env.example .env`, preencha, `npm install && npm run build`. Publique `dist/` (Bolt, Vercel, Netlify...).

## 4. Primeiro acesso
Crie conta → confirme o e-mail → "Criar workspace" (você vira admin). Em Configurações: InfiniteTag, fuso, equipe, **gerar chave de API** (aparece UMA vez).

## 5. n8n
- Defina na instância: `NODE_FUNCTION_ALLOW_BUILTIN=crypto`.
- Importe `n8n/nexa-whatsapp-ia-v2.json`.
- Credenciais: **Anthropic**; **Header Auth "Nexa API key"** (`Authorization: Bearer nxf_...`); **Header Auth "WhatsApp Cloud token"** (`Authorization: Bearer EAAG...`).
- Edite os 3 valores no topo do nó "Validar e extrair" (URL das funções, phone_number_id, App Secret), o token de verificação no nó "Token confere?" e o segredo `whsec_` no nó "Segredo confere?" (+ phone_number_id no último nó).
- Meta → WhatsApp → Configuração: callback `https://SEU-N8N/webhook/nexa-whatsapp`, mesmo token de verificação, assine `messages`.
- Configurações → Webhooks → novo, URL `https://SEU-N8N/webhook/nexa-human-out` (guarde o segredo mostrado).
- **1 workflow = 1 número/clínica.** Duplique por cliente.

## O que foi e o que NÃO foi testado
Testado: SQL em Postgres 16 real (isolamento entre workspaces, papéis, agenda sem choque, ingestão, pagamentos, webhook), lógica pura das funções (assinatura, valor pago), Code nodes do n8n simulados, tipos do front (com stubs).
**Não testado de ponta a ponta** (precisa de você): login real no Supabase, Edge Functions no ar, chamadas reais à InfinitePay (nome do campo do link e `webhook_url` podem divergir — a função aceita variações e falha de forma segura), Meta/WhatsApp, importação do JSON no seu n8n, `npm run build`.
