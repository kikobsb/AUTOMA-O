import { useMemo, useState } from 'react';
import { Download, Sparkles, Target, TrendingUp, Users } from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState, KpiCard } from '@/components/ui';
import { BarChart, revenueBySource, utmBreakdown, stageConversion } from '@/components/charts';
import { useDeals, useStages, useContacts, useLeadAttributions, useConversations, useProfiles } from '@/lib/queries';
import { formatCurrency, sourceLabels, channelLabels } from '@/lib/format';

type Period = '7d' | '30d' | '90d' | 'all';

const PERIODS: { id: Period; label: string }[] = [
  { id: '7d', label: '7 dias' },
  { id: '30d', label: '30 dias' },
  { id: '90d', label: '90 dias' },
  { id: 'all', label: 'Tudo' },
];

export default function ReportsPage() {
  const deals = useDeals();
  const stages = useStages();
  const contacts = useContacts();
  const attributions = useLeadAttributions();
  const conversations = useConversations();
  const profiles = useProfiles();
  const [period, setPeriod] = useState<Period>('30d');

  if (deals.loading || stages.loading) return <LoadingSpinner label="Carregando relatórios..." />;
  if (deals.error) return <ErrorState message={deals.error} />;

  const allDeals = deals.data ?? [];
  const stageList = stages.data ?? [];
  const wonIds = new Set(stageList.filter(s => s.is_won).map(s => s.id));
  const lostIds = new Set(stageList.filter(s => s.is_lost).map(s => s.id));

  const days = period === '7d' ? 7 : period === '30d' ? 30 : period === '90d' ? 90 : null;
  const cutoff = days ? Date.now() - days * 86_400_000 : 0;

  const periodDeals = allDeals.filter(d => new Date(d.created_at).getTime() >= cutoff);
  const won = periodDeals.filter(d => wonIds.has(d.stage_id));
  const lost = periodDeals.filter(d => lostIds.has(d.stage_id));
  const revenue = won.reduce((s, d) => s + Number(d.value), 0);
  const conversion = won.length + lost.length > 0 ? (won.length / (won.length + lost.length)) * 100 : 0;

  const leadsByChannel = useMemo(() => {
    const m = new Map<string, number>();
    for (const c of contacts.data ?? []) m.set(c.channel, (m.get(c.channel) ?? 0) + 1);
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [contacts.data]);

  const convs = conversations.data ?? [];
  const resolved = convs.filter(c => c.status === 'resolvida').length;
  const resolutionRate = convs.length > 0 ? (resolved / convs.length) * 100 : 0;

  const srcData = revenueBySource(periodDeals, attributions.data ?? [], stageList);
  const campaigns = utmBreakdown(attributions.data ?? []).slice(0, 8);
  const funnel = stageConversion(allDeals, stageList);

  const ownerRanking = useMemo(() => {
    const m = new Map<string, { revenue: number; won: number }>();
    for (const d of won) {
      const key = d.owner_id ?? '—';
      const cur = m.get(key) ?? { revenue: 0, won: 0 };
      m.set(key, { revenue: cur.revenue + Number(d.value), won: cur.won + 1 });
    }
    return [...m.entries()].sort((a, b) => b[1].revenue - a[1].revenue);
  }, [won]);
  const profileMap = new Map((profiles.data ?? []).map(p => [p.id, p.name]));

  return (
    <div className="pb-8">
      <PageHeader
        title="Relatórios"
        subtitle="Performance de vendas, canais e campanhas"
        actions={
          <>
            <div className="flex bg-white dark:bg-slate-800 rounded-lg border border-slate-300 dark:border-slate-600 p-0.5">
              {PERIODS.map(p => (
                <button
                  key={p.id}
                  onClick={() => setPeriod(p.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    period === p.id ? 'bg-brand-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
            <button className="btn-ghost !py-1.5 text-sm gap-1.5">
              <Download className="w-4 h-4" /> Exportar
            </button>
          </>
        }
      />

      <div className="px-4 sm:px-6 mt-5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Receita ganha" value={formatCurrency(revenue)} icon={<TrendingUp className="w-5 h-5" />} accent="emerald" />
        <KpiCard label="Negócios ganhos" value={String(won.length)} icon={<Target className="w-5 h-5" />} accent="brand" />
        <KpiCard label="Taxa de conversão" value={`${conversion.toFixed(1)}%`} icon={<Sparkles className="w-5 h-5" />} accent="violet" />
        <KpiCard label="Resolução de conversas" value={`${resolutionRate.toFixed(1)}%`} icon={<Users className="w-5 h-5" />} accent="amber" />
      </div>

      <div className="px-4 sm:px-6 mt-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <h2 className="font-semibold text-slate-900 dark:text-white">Receita por origem</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Atribuição de vendas por canal e UTM</p>
          {srcData.length > 0 ? (
            <BarChart
              data={srcData.map(s => ({
                label: sourceLabels[s.source] ?? s.source,
                value: s.revenue,
                display: formatCurrency(s.revenue),
              }))}
            />
          ) : (
            <p className="text-sm text-slate-400 py-6 text-center">Sem vendas no período.</p>
          )}
        </div>

        <div className="card p-5">
          <h2 className="font-semibold text-slate-900 dark:text-white">Leads por canal</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">De onde vêm seus contatos</p>
          {leadsByChannel.length > 0 ? (
            <BarChart
              data={leadsByChannel.map(([ch, count]) => ({
                label: channelLabels[ch as keyof typeof channelLabels] ?? ch,
                value: count,
                display: String(count),
              }))}
            />
          ) : (
            <p className="text-sm text-slate-400 py-6 text-center">Sem contatos.</p>
          )}
        </div>
      </div>

      <div className="px-4 sm:px-6 mt-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <h2 className="font-semibold text-slate-900 dark:text-white mb-4">Principais campanhas UTM</h2>
          {campaigns.length > 0 ? (
            <div className="space-y-2">
              {campaigns.map(({ campaign, leads }) => (
                <div key={campaign} className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                  <span className="text-sm text-slate-700 dark:text-slate-200 truncate capitalize">{campaign}</span>
                  <span className="badge bg-brand-100 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300 !text-[10px] shrink-0 ml-2">
                    {leads} leads
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-400 py-6 text-center">Sem dados de campanha.</p>
          )}
        </div>

        <div className="card p-5">
          <h2 className="font-semibold text-slate-900 dark:text-white mb-4">Ranking de vendedores</h2>
          {ownerRanking.length > 0 ? (
            <div className="space-y-2">
              {ownerRanking.map(([ownerId, { revenue, won: wonCount }], i) => (
                <div key={ownerId} className="flex items-center gap-3 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                  <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</span>
                  <span className="text-sm text-slate-700 dark:text-slate-200 truncate flex-1">
                    {profileMap.get(ownerId) ?? 'Sem responsável'}
                  </span>
                  <span className="text-xs text-slate-400 shrink-0">{wonCount} ganhos</span>
                  <span className="text-sm font-bold text-slate-900 dark:text-white shrink-0">{formatCurrency(revenue)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-400 py-6 text-center">Nenhuma venda ganha no período.</p>
          )}
        </div>
      </div>

      <div className="px-4 sm:px-6 mt-4">
        <div className="card p-5">
          <h2 className="font-semibold text-slate-900 dark:text-white mb-4">Conversão por etapa do funil</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {funnel.map(({ stage, count, pct }) => (
              <div key={stage.id} className="rounded-xl p-3 text-center border-t-4" style={{ borderTopColor: stage.color }}>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{count}</p>
                <p className="text-xs text-slate-500 mt-0.5 truncate">{stage.name}</p>
                <p className="text-[11px] text-slate-400">{pct}% do total</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
