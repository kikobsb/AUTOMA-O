import { useState, type FormEvent, type ReactNode } from 'react';
import { Check, Copy, Key, MailPlus, Plug, Plus, Save, Trash2, Webhook as WebhookIcon, X } from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState } from '@/components/ui';
import { errorMessage, supabase, useApiKeys, useProfiles, useWebhooks } from '@/lib/queries';
import { useAuth, useSession } from '@/lib/auth';
import { formatDateTime, formatRelativeTime } from '@/lib/format';
import { PlanBadge } from '@/components/bits';
import { cn } from '@/lib/cn';
import type { Profile } from '@/lib/types';

type Tab = 'workspace' | 'team' | 'integracoes';
const TABS: { id: Tab; label: string }[] = [
  { id: 'workspace', label: 'Workspace' },
  { id: 'team', label: 'Equipe' },
  { id: 'integracoes', label: 'Integrações & API' },
];
const TIMEZONES = ['America/Sao_Paulo', 'America/Manaus', 'America/Fortaleza', 'America/Cuiaba', 'America/Rio_Branco', 'America/Noronha'];
const ROLE_LABEL: Record<Profile['role'], string> = { admin: 'Administrador', gestor: 'Gestor', atendente: 'Atendente' };
const API_PERMISSIONS = [
  { id: 'messages:write', label: 'Enviar mensagens recebidas / respostas da IA' },
  { id: 'appointments:read', label: 'Consultar horários livres' },
  { id: 'appointments:write', label: 'Criar agendamentos' },
  { id: 'payments:write', label: 'Gerar cobranças' },
];

function friendlyDbError(msg: string): string {
  if (/last_admin/i.test(msg)) return 'O workspace precisa ter pelo menos um administrador ativo.';
  if (/duplicate key|already exists|profiles_.*key/i.test(msg)) return 'Já existe um membro com esse e-mail.';
  if (/invalid_url/i.test(msg)) return 'Use uma URL começando com https://';
  if (/forbidden|permission denied|row-level security/i.test(msg)) return 'Você não tem permissão para isso.';
  return msg;
}

function Overlay({ title, children, onClose }: { title: string; children: ReactNode; onClose?: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" role="dialog" aria-modal="true" aria-label={title}>
      <div className="card w-full max-w-md p-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-slate-900 dark:text-white">{title}</h2>
          {onClose && <button className="btn-ghost p-1" onClick={onClose} aria-label="Fechar"><X className="w-4 h-4" /></button>}
        </div>
        {children}
      </div>
    </div>
  );
}

function CopyButton({ value, label = 'Copiar' }: { value: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" className="btn-secondary text-sm gap-1.5" onClick={async () => {
      try { await navigator.clipboard.writeText(value); setDone(true); setTimeout(() => setDone(false), 1500); } catch { /* navegador bloqueou */ }
    }}>
      {done ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />} {done ? 'Copiado' : label}
    </button>
  );
}

/** Mostra um segredo UMA vez. Depois de fechar, ele não pode mais ser recuperado (só o hash fica no banco). */
function SecretReveal({ title, secret, hint, onClose }: { title: string; secret: string; hint: string; onClose: () => void }) {
  const [ack, setAck] = useState(false);
  return (
    <Overlay title={title}>
      <p className="text-sm text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 rounded-lg px-3 py-2 mb-3">
        Copie agora. Por segurança, esse valor <b>não será exibido novamente</b>. Se perder, gere outro.
      </p>
      <input className="input font-mono text-xs" readOnly value={secret} onFocus={e => e.currentTarget.select()} aria-label="Segredo" />
      <p className="text-xs text-slate-500 mt-2">{hint}</p>
      <div className="flex items-center justify-between mt-4 gap-2">
        <CopyButton value={secret} />
        <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
          <input type="checkbox" checked={ack} onChange={e => setAck(e.target.checked)} /> Já guardei
        </label>
        <button className="btn-primary" disabled={!ack} onClick={onClose}>Fechar</button>
      </div>
    </Overlay>
  );
}

export default function SettingsPage() {
  const { profile: me, workspace: ws, isAdmin } = useSession();
  const { reload: reloadWorkspace } = useAuth();
  const profiles = useProfiles();
  const webhooks = useWebhooks();
  const apiKeys = useApiKeys();
  const [tab, setTab] = useState<Tab>('workspace');
  const [error, setError] = useState<string | null>(null);

  // workspace
  const [name, setName] = useState(ws.name);
  const [handle, setHandle] = useState(ws.infinitepay_handle ?? '');
  const [tz, setTz] = useState(ws.timezone ?? 'America/Sao_Paulo');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // equipe
  const [invName, setInvName] = useState('');
  const [invEmail, setInvEmail] = useState('');
  const [invRole, setInvRole] = useState<Profile['role']>('atendente');

  // integrações
  const [secret, setSecret] = useState<{ title: string; value: string; hint: string } | null>(null);
  const [showKeyForm, setShowKeyForm] = useState(false);
  const [keyName, setKeyName] = useState('');
  const [keyPerms, setKeyPerms] = useState<string[]>(['messages:write', 'appointments:read', 'appointments:write']);
  const [showHookForm, setShowHookForm] = useState(false);
  const [hookName, setHookName] = useState('');
  const [hookUrl, setHookUrl] = useState('');

  if (!isAdmin) return <ErrorState message="Apenas administradores acessam as configurações." />;
  if (profiles.loading && !profiles.data) return <LoadingSpinner label="Carregando configurações..." />;
  if (profiles.error) return <ErrorState message={profiles.error} />;

  const run = async (op: PromiseLike<{ error: { message: string } | null }>, after?: () => void) => {
    setError(null);
    const { error: err } = await op;
    if (err) { setError(friendlyDbError(err.message)); return false; }
    after?.();
    return true;
  };

  const saveWorkspace = async () => {
    setSaving(true);
    const cleanHandle = handle.trim().replace(/^\$/, '');
    if (cleanHandle && !/^[A-Za-z0-9_.-]{2,40}$/.test(cleanHandle)) { setError('InfiniteTag inválida. Use só letras, números, ponto, hífen ou sublinhado (sem o $).'); setSaving(false); return; }
    const ok = await run(supabase.from('workspaces').update({
      name: name.trim(), timezone: tz, infinitepay_handle: cleanHandle || null,
    }).eq('id', ws.id), () => { setSaved(true); setTimeout(() => setSaved(false), 2000); reloadWorkspace(); });
    if (!ok) { /* erro já exibido */ }
    setSaving(false);
  };

  const invite = async (e: FormEvent) => {
    e.preventDefault();
    await run(supabase.from('profiles').insert({
      workspace_id: ws.id, name: invName.trim(), email: invEmail.trim().toLowerCase(), role: invRole, is_active: true,
    }), () => { setInvName(''); setInvEmail(''); profiles.refetch(); });
  };
  const changeRole = (p: Profile, role: Profile['role']) =>
    run(supabase.from('profiles').update({ role }).eq('id', p.id), () => profiles.refetch());
  const toggleProfile = (p: Profile) =>
    run(supabase.from('profiles').update({ is_active: !p.is_active }).eq('id', p.id), () => profiles.refetch());

  const createKey = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    const { data, error: err } = await supabase.rpc('create_api_key', { p_name: keyName.trim(), p_permissions: keyPerms });
    if (err) { setError(friendlyDbError(err.message)); return; }
    setShowKeyForm(false); setKeyName(''); apiKeys.refetch();
    setSecret({ title: 'Sua nova chave de API', value: (data as { api_key: string }).api_key,
      hint: 'Use no n8n/Edge Functions como header Authorization: Bearer <chave>. Nunca coloque em código do navegador.' });
  };
  const createHook = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    const { data, error: err } = await supabase.rpc('create_webhook', { p_name: hookName.trim(), p_url: hookUrl.trim(), p_events: ['message.created'] });
    if (err) { setError(friendlyDbError(err.message)); return; }
    setShowHookForm(false); setHookName(''); setHookUrl(''); webhooks.refetch();
    setSecret({ title: 'Segredo do webhook', value: (data as { secret: string }).secret,
      hint: 'Enviamos este valor no header X-Webhook-Secret a cada entrega. Valide-o no n8n antes de processar.' });
  };

  const fnBase = `${(import.meta.env.VITE_SUPABASE_URL as string | undefined) ?? 'https://SEU-PROJETO.supabase.co'}/functions/v1`;

  return (
    <div className="pb-8">
      <PageHeader title="Configurações" subtitle="Workspace, equipe e integrações" />

      <div className="px-4 sm:px-6 mt-5">
        <div className="flex gap-1 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
          {TABS.map(t => (
            <button key={t.id} onClick={() => { setTab(t.id); setError(null); }}
              className={cn('px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px whitespace-nowrap',
                tab === t.id ? 'text-brand-600 dark:text-brand-400 border-brand-500' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 border-transparent')}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 sm:px-6 mt-5 max-w-3xl space-y-4">
        {error && <p role="alert" className="text-sm text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 rounded-lg px-3 py-2">{error}</p>}

        {tab === 'workspace' && (
          <div className="card p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-slate-900 dark:text-white">Dados do workspace</h2>
              <PlanBadge plan={ws.plan} />
            </div>
            <label className="block"><span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Nome da empresa</span>
              <input value={name} onChange={e => setName(e.target.value)} className="input" minLength={2} maxLength={80} />
            </label>
            <label className="block"><span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Fuso horário (usado na agenda)</span>
              <select className="input" value={tz} onChange={e => setTz(e.target.value)}>
                {[...new Set([tz, ...TIMEZONES])].map(z => <option key={z} value={z}>{z}</option>)}
              </select>
            </label>
            <label className="block"><span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">InfiniteTag (InfinitePay)</span>
              <input value={handle} onChange={e => setHandle(e.target.value)} className="input" placeholder="sem o $, ex.: minhaclinica" />
              <span className="block text-xs text-slate-500 mt-1">Usada para gerar os links de pagamento. O dinheiro cai direto na sua conta InfinitePay.</span>
            </label>
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-400">Identificador: {ws.slug} · Status: {ws.status}{ws.trial_ends_at && ` · teste até ${formatDateTime(ws.trial_ends_at)}`}</p>
              <button onClick={saveWorkspace} disabled={saving || name.trim().length < 2} className="btn-primary !py-2 text-sm gap-1.5">
                <Save className="w-4 h-4" /> {saved ? 'Salvo!' : saving ? 'Salvando...' : 'Salvar'}
              </button>
            </div>
          </div>
        )}

        {tab === 'team' && (
          <div className="card p-5">
            <h2 className="font-semibold text-slate-900 dark:text-white mb-1">Membros da equipe</h2>
            <p className="text-xs text-slate-500 mb-4">Convide pelo e-mail. A pessoa cria a conta com esse mesmo e-mail, confirma e entra já neste workspace.</p>
            <form onSubmit={invite} className="grid sm:grid-cols-[1fr_1fr_auto_auto] gap-2 mb-4">
              <input className="input" placeholder="Nome" value={invName} onChange={e => setInvName(e.target.value)} required minLength={2} />
              <input className="input" type="email" placeholder="E-mail" value={invEmail} onChange={e => setInvEmail(e.target.value)} required />
              <select className="input" value={invRole} onChange={e => setInvRole(e.target.value as Profile['role'])} aria-label="Papel">
                {(Object.keys(ROLE_LABEL) as Profile['role'][]).map(r => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
              </select>
              <button className="btn-primary gap-1.5" type="submit"><MailPlus className="w-4 h-4" /> Convidar</button>
            </form>
            <div className="space-y-2">
              {(profiles.data ?? []).map(p => (
                <div key={p.id} className={cn('flex flex-wrap items-center gap-3 px-3 py-2.5 rounded-lg bg-slate-50 dark:bg-slate-700/40', !p.is_active && 'opacity-60')}>
                  <div className="min-w-0 flex-1 basis-40">
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-100 truncate">{p.name}{p.id === me.id && ' (você)'}</p>
                    <p className="text-xs text-slate-500 truncate">{p.email}</p>
                  </div>
                  {!p.auth_user_id && <span className="badge !text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">convite pendente</span>}
                  <select className="input !w-auto !py-1 text-xs" value={p.role} onChange={e => void changeRole(p, e.target.value as Profile['role'])} aria-label={`Papel de ${p.name}`}>
                    {(Object.keys(ROLE_LABEL) as Profile['role'][]).map(r => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                  </select>
                  <button onClick={() => void toggleProfile(p)} className="text-xs font-medium px-2.5 py-1.5 rounded-lg text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-500/10">
                    {p.is_active ? 'Desativar' : 'Ativar'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'integracoes' && (
          <>
            <div className="card p-5">
              <div className="flex items-center gap-2 mb-3">
                <Plug className="w-5 h-5 text-brand-500" />
                <h2 className="font-semibold text-slate-900 dark:text-white">Endereços para o n8n</h2>
              </div>
              <p className="text-xs text-slate-500 mb-3">Todos usam <code>Authorization: Bearer &lt;sua chave de API&gt;</code> e método POST.</p>
              <ul className="space-y-1.5 text-xs font-mono text-slate-700 dark:text-slate-200">
                {['incoming-message', 'ai-reply', 'availability', 'book-appointment', 'create-payment-link'].map(f => (
                  <li key={f} className="flex items-center gap-2 bg-slate-50 dark:bg-slate-700/40 rounded px-2 py-1.5">
                    <span className="truncate flex-1">{fnBase}/{f}</span>
                    <CopyButton value={`${fnBase}/${f}`} />
                  </li>
                ))}
              </ul>
            </div>

            <div className="card p-5">
              <div className="flex items-center gap-2 mb-4">
                <Key className="w-5 h-5 text-brand-500" />
                <h2 className="font-semibold text-slate-900 dark:text-white">Chaves de API</h2>
                <button className="btn-ghost !py-1.5 text-xs gap-1 ml-auto" onClick={() => setShowKeyForm(true)}><Plus className="w-3.5 h-3.5" /> Gerar chave</button>
              </div>
              <div className="space-y-2">
                {(apiKeys.data ?? []).length === 0 && <p className="text-sm text-slate-400 py-4 text-center">Nenhuma chave criada.</p>}
                {(apiKeys.data ?? []).map(k => (
                  <div key={k.id} className={cn('flex items-center gap-3 px-3 py-2.5 rounded-lg bg-slate-50 dark:bg-slate-700/40', !k.is_active && 'opacity-60')}>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-slate-800 dark:text-slate-100">{k.name}{!k.is_active && ' · revogada'}</p>
                      <p className="text-xs text-slate-400 font-mono truncate">{k.key_masked}</p>
                    </div>
                    <span className="text-[11px] text-slate-400 shrink-0 hidden sm:block">
                      {k.last_used_at ? `usada ${formatRelativeTime(k.last_used_at)}` : `criada ${formatDateTime(k.created_at)}`}
                    </span>
                    <button className="btn-ghost !px-2 !py-1.5 text-xs shrink-0" onClick={() => void run(supabase.from('api_keys').update({ is_active: !k.is_active }).eq('id', k.id), apiKeys.refetch)}>
                      {k.is_active ? 'Revogar' : 'Reativar'}
                    </button>
                    <button className="btn-ghost !px-2 !py-1.5 shrink-0 text-rose-500" aria-label="Excluir chave" onClick={() => {
                      if (window.confirm(`Excluir a chave "${k.name}"? Quem a usa perde acesso na hora.`)) void run(supabase.from('api_keys').delete().eq('id', k.id), apiKeys.refetch);
                    }}><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                ))}
              </div>
            </div>

            <div className="card p-5">
              <div className="flex items-center gap-2 mb-1">
                <WebhookIcon className="w-5 h-5 text-brand-500" />
                <h2 className="font-semibold text-slate-900 dark:text-white">Webhooks de saída</h2>
                <button className="btn-ghost !py-1.5 text-xs gap-1 ml-auto" onClick={() => setShowHookForm(true)}><Plus className="w-3.5 h-3.5" /> Adicionar</button>
              </div>
              <p className="text-xs text-slate-500 mb-3">Quando um atendente humano responde, enviamos a mensagem para a URL (o n8n a entrega no WhatsApp). Requer a extensão <code>pg_net</code> ativa no Supabase.</p>
              <div className="space-y-2">
                {(webhooks.data ?? []).length === 0 && <p className="text-sm text-slate-400 py-4 text-center">Nenhum webhook configurado.</p>}
                {(webhooks.data ?? []).map(w => (
                  <div key={w.id} className="px-3 py-2.5 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                    <div className="flex items-center gap-2">
                      <span className={cn('w-2 h-2 rounded-full shrink-0', w.is_active ? 'bg-emerald-500' : 'bg-slate-400')} />
                      <p className="text-sm font-medium text-slate-800 dark:text-slate-100 truncate">{w.name}</p>
                      <button className="ml-auto text-xs text-brand-600 dark:text-brand-400 shrink-0" onClick={() => void run(supabase.from('webhooks').update({ is_active: !w.is_active }).eq('id', w.id), webhooks.refetch)}>
                        {w.is_active ? 'Pausar' : 'Ativar'}
                      </button>
                      <button className="text-rose-500 shrink-0" aria-label="Excluir webhook" onClick={() => {
                        if (window.confirm(`Excluir o webhook "${w.name}"?`)) void run(supabase.from('webhooks').delete().eq('id', w.id), webhooks.refetch);
                      }}><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5 font-mono">{w.url}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{(w.events ?? []).join(', ')}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {showKeyForm && (
        <Overlay title="Gerar chave de API" onClose={() => setShowKeyForm(false)}>
          <form onSubmit={createKey} className="space-y-3">
            <input className="input" placeholder="Nome (ex.: n8n produção)" value={keyName} onChange={e => setKeyName(e.target.value)} required minLength={2} />
            <fieldset className="space-y-1.5">
              <legend className="text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Permissões</legend>
              {API_PERMISSIONS.map(p => (
                <label key={p.id} className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-200">
                  <input type="checkbox" className="mt-1" checked={keyPerms.includes(p.id)}
                    onChange={e => setKeyPerms(k => e.target.checked ? [...k, p.id] : k.filter(x => x !== p.id))} /> {p.label}
                </label>
              ))}
            </fieldset>
            <div className="flex justify-end gap-2">
              <button type="button" className="btn-secondary" onClick={() => setShowKeyForm(false)}>Cancelar</button>
              <button className="btn-primary" type="submit" disabled={keyPerms.length === 0}>Gerar</button>
            </div>
          </form>
        </Overlay>
      )}
      {showHookForm && (
        <Overlay title="Novo webhook" onClose={() => setShowHookForm(false)}>
          <form onSubmit={createHook} className="space-y-3">
            <input className="input" placeholder="Nome (ex.: n8n → WhatsApp)" value={hookName} onChange={e => setHookName(e.target.value)} required minLength={2} />
            <input className="input" type="url" placeholder="https://seu-n8n.com/webhook/..." value={hookUrl} onChange={e => setHookUrl(e.target.value)} required pattern="https://.*" />
            <div className="flex justify-end gap-2">
              <button type="button" className="btn-secondary" onClick={() => setShowHookForm(false)}>Cancelar</button>
              <button className="btn-primary" type="submit">Criar</button>
            </div>
          </form>
        </Overlay>
      )}
      {secret && <SecretReveal title={secret.title} secret={secret.value} hint={secret.hint} onClose={() => setSecret(null)} />}
    </div>
  );
}
