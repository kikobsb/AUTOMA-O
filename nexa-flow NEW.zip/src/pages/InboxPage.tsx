import { useMemo, useState } from 'react';
import { Bot, BotOff, Mic, Paperclip, Play, Search, Send, StickyNote } from 'lucide-react';
import { LoadingSpinner, ErrorState } from '@/components/ui';
import { useConversations, useContacts, useMessages, useProfiles, useQuickReplies, useLeadAttributions, usePayments, useStages, useDeals, useAiAgents, supabase } from '@/lib/queries';
import type { Conversation, Contact, Message } from '@/lib/types';
import { channelLabels, formatRelativeTime, statusLabels, statusStyles } from '@/lib/format';
import { Avatar, ChannelIcon } from '@/components/bits';
import { cn } from '@/lib/cn';
import { useSession } from '@/lib/auth';
import { formatCurrency, formatDateTime } from '@/lib/format';

const STATUS_FILTERS: { id: string; label: string }[] = [
  { id: 'todas', label: 'Todas' },
  { id: 'abertas', label: 'Abertas' },
  { id: 'em_atendimento', label: 'Em atendimento' },
  { id: 'aguardando', label: 'Aguardando' },
  { id: 'resolvidas', label: 'Resolvidas' },
  { id: 'nao_lidas', label: 'Não lidas' },
];

export default function InboxPage() {
  const conversations = useConversations();
  const contacts = useContacts();
  const profiles = useProfiles();
  const stages = useStages();
  const deals = useDeals();
  const attributions = useLeadAttributions();
  const payments = usePayments();
  const agents = useAiAgents();

  const [statusFilter, setStatusFilter] = useState('todas');
  const [channelFilter, setChannelFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [mobileView, setMobileView] = useState<'list' | 'chat'>('list');

  if (conversations.loading || contacts.loading) return <LoadingSpinner label="Carregando conversas..." />;
  if (conversations.error) return <ErrorState message={conversations.error} />;

  const contactMap = new Map((contacts.data ?? []).map(c => [c.id, c]));
  const profileMap = new Map((profiles.data ?? []).map(p => [p.id, p]));

  const filtered = (conversations.data ?? []).filter(c => {
    const contact = contactMap.get(c.contact_id);
    const okStatus =
      statusFilter === 'todas' ? true :
      statusFilter === 'nao_lidas' ? (c.unread_count ?? 0) > 0 :
      statusFilter === 'resolvidas' ? c.status === 'resolvida' :
      statusFilter === 'abertas' ? c.status === 'aberta' :
      c.status === statusFilter;
    const okChannel = channelFilter === 'all' || c.channel === channelFilter;
    const okSearch = !search || contact?.name.toLowerCase().includes(search.toLowerCase()) ||
      (contact?.phone ?? '').includes(search);
    return okStatus && okChannel && okSearch;
  });

  const selected = (conversations.data ?? []).find(c => c.id === selectedId) ?? filtered[0] ?? null;
  const selectedContact = selected ? contactMap.get(selected.contact_id) ?? null : null;

  return (
    <div className="h-full flex flex-col">
      <div className="px-4 sm:px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-surface-darker shrink-0">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="text-lg font-bold text-slate-900 dark:text-white mr-2">Central de Atendimento</h1>
          <div className="flex flex-wrap gap-1">
            {STATUS_FILTERS.map(f => (
              <button
                key={f.id}
                onClick={() => setStatusFilter(f.id)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-medium transition-colors',
                  statusFilter === f.id
                    ? 'bg-brand-500 text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-brand-400'
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <select value={channelFilter} onChange={e => setChannelFilter(e.target.value)} className="input !w-auto !py-1.5 text-xs ml-auto">
            <option value="all">Todos os canais</option>
            {Object.entries(channelLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Conversation list */}
        <div className={cn(
          'w-full lg:w-[340px] xl:w-[380px] shrink-0 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-white dark:bg-surface-card',
          mobileView === 'chat' && 'hidden lg:flex'
        )}>
          <div className="p-3 border-b border-slate-200 dark:border-slate-800">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Buscar por nome ou telefone..."
                className="input !pl-9"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filtered.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-10">Nenhuma conversa encontrada.</p>
            )}
            {filtered.map(conv => {
              const contact = contactMap.get(conv.contact_id);
              if (!contact) return null;
              return (
                <button
                  key={conv.id}
                  onClick={() => { setSelectedId(conv.id); setMobileView('chat'); }}
                  className={cn(
                    'w-full text-left px-4 py-3 flex gap-3 border-b border-slate-100 dark:border-slate-800/60 transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/30',
                    selected?.id === conv.id && 'bg-brand-50 dark:bg-brand-500/10'
                  )}
                >
                  <Avatar name={contact.name} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-semibold text-sm text-slate-900 dark:text-white truncate">{contact.name}</p>
                      <span className="text-[11px] text-slate-400 shrink-0">{formatRelativeTime(conv.last_message_at)}</span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <ChannelIcon channel={conv.channel} className="w-3.5 h-3.5 shrink-0" />
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate flex-1">{conv.last_message_preview}</p>
                      {(conv.unread_count ?? 0) > 0 && (
                        <span className="bg-brand-500 text-white text-[10px] font-bold min-w-[18px] h-[18px] rounded-full flex items-center justify-center px-1 shrink-0">
                          {conv.unread_count}
                        </span>
                      )}
                    </div>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <span className={cn('badge !text-[10px] !px-1.5', statusStyles[conv.status])}>{statusLabels[conv.status]}</span>
                      {conv.ai_paused && <span className="badge !text-[10px] !px-1.5 bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400">IA pausada</span>}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Chat area */}
        <div className={cn(
          'flex-1 flex min-w-0',
          mobileView === 'list' && 'hidden lg:flex'
        )}>
          {selected && selectedContact ? (
            <ChatPanel
              key={selected.id}
              conversation={selected}
              contact={selectedContact}
              profiles={profiles.data ?? []}
              onChanged={conversations.refetch}
              onBack={() => setMobileView('list')}
            />
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              Selecione uma conversa
            </div>
          )}

          {/* Contact side panel (desktop) */}
          {selectedContact && (
            <ContactPanel
              contact={selectedContact}
              conversation={selected!}
              stages={stages.data ?? []}
              deals={deals.data ?? []}
              attributions={attributions.data ?? []}
              payments={payments.data ?? []}
              agents={agents.data ?? []}
              onChanged={conversations.refetch}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function ChatPanel({
  conversation, contact, profiles, onBack, onChanged,
}: {
  conversation: Conversation;
  contact: Contact;
  profiles: { id: string; name: string }[];
  onBack: () => void;
  onChanged: () => void;
}) {
  const { profile } = useSession();
  const messages = useMessages(conversation.id);
  const quickReplies = useQuickReplies();
  const [text, setText] = useState('');
  const [sendError, setSendError] = useState<string | null>(null);
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [showQuick, setShowQuick] = useState(false);
  const [slashQuery, setSlashQuery] = useState<string | null>(null);
  const bottomRef = useMemo(() => ({ current: null as HTMLDivElement | null }), []);

  const profileMap = new Map(profiles.map(p => [p.id, p.name]));

  const sendMessage = async (content: string, type: 'text' | 'note' = 'text') => {
    if (!content.trim()) return;
    const isNote = type === 'note';
    const ins = await supabase.from('messages').insert({
      workspace_id: conversation.workspace_id,
      conversation_id: conversation.id,
      sender_type: 'agent',
      sender_id: profile.id,
      sender_name: profile.name,
      content,
      message_type: isNote ? 'note' : 'text',
      is_note: isNote,
    });
    if (ins.error) { setSendError('Não foi possível enviar: ' + ins.error.message); return; }
    setSendError(null);
    await supabase
      .from('conversations')
      .update({ last_message_at: new Date().toISOString(), last_message_preview: isNote ? 'Nota interna' : content.slice(0, 80) })
      .eq('id', conversation.id);
    setText('');
    setNoteText('');
    setShowNoteInput(false);
    messages.refetch();
    onChanged(); // a mensagem humana pausa a IA no banco; recarrega a conversa
  };

  const renderContent = (m: Message) => {
    const preview = m.content ?? '';
    if (m.message_type === 'audio') {
      return (
        <div className="flex items-center gap-2 min-w-[180px]">
          <Play className="w-4 h-4 shrink-0" />
          <div className="flex items-end gap-[2px] h-6 flex-1">
            {[10, 18, 8, 22, 14, 6, 20, 12, 24, 9, 16, 7, 21, 13, 18, 10].map((h, i) => (
              <div key={i} className="w-[3px] rounded-full bg-current opacity-60" style={{ height: `${h}px` }} />
            ))}
          </div>
          <span className="text-xs opacity-70 shrink-0">0:32</span>
        </div>
      );
    }
    return preview.replace('{{nome}}', contact.name.split(' ')[0]);
  };

  return (
    <div className="flex-1 flex flex-col min-w-0">
      {/* Chat header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-card shrink-0">
        <button onClick={onBack} className="lg:hidden btn-ghost !px-2">
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5m7-7-7 7 7 7"/></svg>
        </button>
        <Avatar name={contact.name} size="sm" />
        <div className="min-w-0 flex-1">
          <p className="font-semibold text-sm text-slate-900 dark:text-white truncate">{contact.name}</p>
          <p className="text-xs text-slate-500 flex items-center gap-1">
            <ChannelIcon channel={conversation.channel} className="w-3 h-3" />
            {channelLabels[conversation.channel]} · {contact.phone}
          </p>
        </div>
        <select
          value={conversation.status}
          onChange={async e => {
            await supabase.from('conversations').update({ status: e.target.value }).eq('id', conversation.id);
            onChanged();
          }}
          className="input !w-auto !py-1.5 text-xs"
        >
          {Object.entries(statusLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50 dark:bg-surface-darker">
        {messages.loading && <p className="text-sm text-slate-400 text-center">Carregando mensagens...</p>}
        {(messages.data ?? []).map(m => {
          if (m.message_type === 'system') {
            return (
              <div key={m.id} className="flex justify-center">
                <span className="badge bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300 text-[11px]">
                  {m.content}
                </span>
              </div>
            );
          }
          if (m.is_note) {
            return (
              <div key={m.id} className="flex justify-end">
                <div className="max-w-[80%] bg-amber-100 dark:bg-amber-500/20 border border-amber-300 dark:border-amber-500/40 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-300 text-[11px] font-semibold mb-1">
                    <StickyNote className="w-3 h-3" /> Nota interna · {m.sender_name}
                  </div>
                  <p className="text-sm text-amber-900 dark:text-amber-200">{m.content}</p>
                </div>
              </div>
            );
          }
          const mine = m.sender_type !== 'contact';
          return (
            <div key={m.id} className={cn('flex', mine ? 'justify-end' : 'justify-start')}>
              <div
                className={cn(
                  'max-w-[75%] rounded-2xl px-3.5 py-2.5 text-sm animate-slide-up',
                  mine
                    ? m.sender_type === 'ai'
                      ? 'bg-violet-100 dark:bg-violet-500/20 text-slate-800 dark:text-violet-100 rounded-br-md'
                      : 'bg-brand-500 text-white rounded-br-md'
                    : 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-bl-md shadow-sm'
                )}
              >
                {m.sender_type === 'ai' && !mine && (
                  <p className="text-[10px] font-bold text-violet-600 dark:text-violet-300 mb-0.5 flex items-center gap-1">
                    <Bot className="w-3 h-3" /> Agente IA
                  </p>
                )}
                {renderContent(m)}
                <p className={cn('text-[10px] mt-1 text-right', mine ? 'text-white/70' : 'text-slate-400')}>
                  {formatRelativeTime(m.created_at)}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={el => { bottomRef.current = el; }} />
      </div>

      {/* Quick replies popup */}
      {showQuick && (
        <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-card p-2 max-h-48 overflow-y-auto">
          <p className="text-xs font-semibold text-slate-500 px-2 py-1">Mensagens rápidas</p>
          {(quickReplies.data ?? []).map(qr => (
            <button
              key={qr.id}
              onClick={() => { setText(qr.content.replace('{{nome}}', contact.name.split(' ')[0])); setShowQuick(false); }}
              className="w-full text-left px-2 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <span className="text-xs font-bold text-brand-600 dark:text-brand-400">{qr.shortcut}</span>
              <span className="text-xs text-slate-500 ml-2">{qr.title}</span>
            </button>
          ))}
        </div>
      )}

      {/* Slash command results */}
      {slashQuery !== null && (
        <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-card p-2 max-h-48 overflow-y-auto">
          {(quickReplies.data ?? [])
            .filter(qr => qr.shortcut.includes(slashQuery.toLowerCase()))
            .map(qr => (
              <button
                key={qr.id}
                onClick={() => { setText(qr.content.replace('{{nome}}', contact.name.split(' ')[0])); setSlashQuery(null); }}
                className="w-full text-left px-2 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <span className="text-xs font-bold text-brand-600 dark:text-brand-400">{qr.shortcut}</span>
                <span className="text-xs text-slate-500 ml-2">{qr.title}</span>
              </button>
            ))}
        </div>
      )}

      {/* Note input */}
      {showNoteInput && (
        <div className="border-t border-amber-300 dark:border-amber-500/40 bg-amber-50 dark:bg-amber-500/10 p-3 flex gap-2">
          <input
            value={noteText}
            onChange={e => setNoteText(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage(noteText, 'note')}
            placeholder="Nota interna (visível só para a equipe)..."
            className="input flex-1"
            autoFocus
          />
          <button onClick={() => sendMessage(noteText, 'note')} className="btn-primary !bg-amber-500 hover:!bg-amber-600">
            <StickyNote className="w-4 h-4" />
          </button>
        </div>
      )}

      {sendError && <p role="alert" className="px-3 py-1.5 text-xs text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10">{sendError}</p>}
      {/* Composer */}
      <div className="flex items-center gap-2 px-3 py-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-card shrink-0">
        <button onClick={() => setShowQuick(s => !s)} className="btn-ghost !px-2 !py-2" title="Mensagens rápidas">
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>
        </button>
        <button className="btn-ghost !px-2 !py-2" title="Anexar arquivo"><Paperclip className="w-5 h-5" /></button>
        <button className="btn-ghost !px-2 !py-2" title="Gravar áudio"><Mic className="w-5 h-5" /></button>
        <button
          onClick={() => setShowNoteInput(s => !s)}
          className={cn('btn-ghost !px-2 !py-2', showNoteInput && 'text-amber-500')}
          title="Nota interna"
        >
          <StickyNote className="w-5 h-5" />
        </button>
        <input
          value={text}
          onChange={e => {
            setText(e.target.value);
            if (e.target.value.startsWith('/')) {
              setSlashQuery(e.target.value.slice(1));
              setShowQuick(false);
            } else {
              setSlashQuery(null);
            }
          }}
          onKeyDown={e => e.key === 'Enter' && sendMessage(text)}
          placeholder="Digite uma mensagem ou / para atalhos..."
          className="input flex-1"
        />
        <button onClick={() => sendMessage(text)} disabled={!text.trim()} className="btn-primary !px-3 !py-2">
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function ContactPanel({
  contact, conversation, stages, deals, attributions, payments, agents, onChanged,
}: {
  onChanged: () => void;
  contact: Contact;
  conversation: Conversation;
  stages: { id: string; name: string }[];
  deals: { id: string; contact_id: string | null; title: string; value: number }[];
  attributions: { contact_id: string; utm_source: string | null; utm_medium: string | null; utm_campaign: string | null; landing_page: string | null; occurred_at: string; event_type: string }[];
  payments: { id: string; contact_id: string | null; amount: number; status: string; method: string }[];
  agents: { id: string; name: string; is_active: boolean | null }[];
}) {
  const [tab, setTab] = useState<'dados' | 'jornada' | 'pedidos'>('dados');
  const contactDeals = deals.filter(d => d.contact_id === contact.id);
  const contactPayments = payments.filter(p => p.contact_id === contact.id);
  const journey = attributions.filter(a => a.contact_id === contact.id).sort((a, b) => a.occurred_at.localeCompare(b.occurred_at));
  const activeAgents = agents.filter(a => a.is_active);

  return (
    <aside className="hidden xl:flex w-[300px] shrink-0 border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-card flex-col overflow-y-auto">
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 text-center">
        <Avatar name={contact.name} size="lg" className="mx-auto" />
        <p className="font-semibold text-slate-900 dark:text-white mt-2">{contact.name}</p>
        <p className="text-xs text-slate-500">{contact.company}</p>
        <div className="flex justify-center gap-1.5 mt-2">
          {(contact.tags ?? []).map(t => (
            <span key={t} className="badge bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300 !text-[10px]">{t}</span>
          ))}
        </div>
      </div>

      {/* AI toggle */}
      <div className="p-3 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={async () => {
            await supabase.from('conversations').update({ ai_paused: !conversation.ai_paused }).eq('id', conversation.id);
            onChanged();
          }}
          className={cn(
            'w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
            conversation.ai_paused
              ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300'
              : 'bg-amber-100 text-amber-700 hover:bg-amber-200 dark:bg-amber-500/15 dark:text-amber-300'
          )}
        >
          {conversation.ai_paused ? <><Bot className="w-4 h-4" /> Ativar Agente de IA</> : <><BotOff className="w-4 h-4" /> Pausar Agente de IA</>}
        </button>
        {!conversation.ai_paused && activeAgents.length > 0 && (
          <p className="text-[11px] text-slate-400 mt-1.5 text-center">
            Respondendo: {activeAgents[0].name.split(' ')[0]}
          </p>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 text-xs font-medium shrink-0">
        {([['dados', 'Dados'], ['jornada', 'Jornada'], ['pedidos', 'Pedidos']] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cn(
              'flex-1 py-2.5 transition-colors',
              tab === id
                ? 'text-brand-600 dark:text-brand-400 border-b-2 border-brand-500'
                : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="p-4 space-y-4 text-sm">
        {tab === 'dados' && (
          <>
            <div>
              <p className="text-xs text-slate-400">E-mail</p>
              <p className="text-slate-700 dark:text-slate-200 break-all">{contact.email ?? '—'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Telefone</p>
              <p className="text-slate-700 dark:text-slate-200">{contact.phone ?? '—'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Etapa no funil</p>
              <p className="text-slate-700 dark:text-slate-200">
                {stages.find(s => s.id === contact.stage_id)?.name ?? '—'}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-400">Canal de origem</p>
              <p className="text-slate-700 dark:text-slate-200">{channelLabels[contact.channel]}</p>
            </div>
            {contact.notes && (
              <div>
                <p className="text-xs text-slate-400">Anotações</p>
                <p className="text-slate-700 dark:text-slate-200 text-xs mt-0.5">{contact.notes}</p>
              </div>
            )}
          </>
        )}
        {tab === 'jornada' && (
          <div className="space-y-3">
            {journey.length === 0 && <p className="text-slate-400 text-xs">Sem eventos de rastreamento.</p>}
            {journey.map((j, i) => (
              <div key={i} className="flex gap-2.5">
                <div className="flex flex-col items-center">
                  <div className="w-2 h-2 rounded-full bg-brand-500 mt-1.5" />
                  {i < journey.length - 1 && <div className="w-px flex-1 bg-slate-200 dark:bg-slate-700 my-1" />}
                </div>
                <div className="pb-2 min-w-0">
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 capitalize">{j.event_type.replace('_', ' ')}</p>
                  {j.utm_source && (
                    <p className="text-[11px] text-slate-500">
                      {j.utm_source}{j.utm_medium ? ` / ${j.utm_medium}` : ''}{j.utm_campaign ? ` · ${j.utm_campaign}` : ''}
                    </p>
                  )}
                  {j.landing_page && <p className="text-[10px] text-slate-400 truncate">{j.landing_page}</p>}
                  <p className="text-[10px] text-slate-400">{formatDateTime(j.occurred_at)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
        {tab === 'pedidos' && (
          <div className="space-y-3">
            {contactDeals.map(d => (
              <div key={d.id} className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                <p className="text-xs font-medium text-slate-700 dark:text-slate-200 truncate">{d.title}</p>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{formatCurrency(d.value)}</p>
              </div>
            ))}
            {contactPayments.map(p => (
              <div key={p.id} className="flex items-center justify-between text-xs">
                <span className="text-slate-500 capitalize">{p.method.replace('_', ' ')} · {p.status}</span>
                <span className="font-semibold text-slate-700 dark:text-slate-200">{formatCurrency(p.amount)}</span>
              </div>
            ))}
            {contactDeals.length === 0 && contactPayments.length === 0 && (
              <p className="text-slate-400 text-xs">Nenhum pedido ou pagamento.</p>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}
