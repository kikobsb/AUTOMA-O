import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight, Bot, DollarSign, Filter, MessageSquare, Percent, Timer, Users,
} from 'lucide-react';
import { PageHeader, KpiCard, LoadingSpinner, ErrorState } from '@/components/ui';
import { BarChart, revenueBySource, stageConversion } from '@/components/charts';
import { useDeals, useStages, useConversations, useContacts, useAiAgents, usePayments, useLeadAttributions, useProfiles } from '@/lib/queries';
import { formatCurrency, sourceLabels } from '@/lib/format';
import type { PageId } from '@/App';

type Period = '7d' | '30d' | '90d';

const PERIODS: { id: Period; label: string }[] = [
  { id: '7d', label: '7 dias' },
  { id: '30d', label: '30 dias' },
  { id: '90d', label: '90 dias' },
];

export default function DashboardPage({ onNavigate }: { onNavigate: (p: PageId) => void }) {
  const [period, setPeriod] = useState<Period>('30d');
  const [channelFilter, setChannelFilter] = useState('all');
  const [attendantFilter, setAttendantFilter] = useState('all');

  const deals = useDeals();
  const stages = useStages();
  const conversations = useConversations();
  const contacts = useContacts();
  const agents = useAiAgents();
  const payments = usePayments();
  const attributions = useLeadAttributions();
  const profiles = useProfiles();

  useEffect(() => {
    document.title = 'Dashboard · Nexa Flow';
  }, []);

  const loading = deals.loading || stages.loading;
  const error = deals.error ?? stages.error;
  if (loading) return <LoadingSpinner label="Carregando dashboard..." />;
  if (error) return <ErrorState message={error} />;

  const allDeals = deals.data ?? [];
  const wonStageIds = new Set((stages.data ?? []).filter(s => s.is_won).map(s => s.id));
  const lostStageIds = new Set((stages.data ?? []).filter(s => s.is_lost).map(s => s.id));

  const periodDays = period === '7d' ? 7 : period === '30d' ? 30 : 90;
  const cutoff = Date.now() - periodDays * 86_400_000;

  const filteredDeals = allDeals.filter(d => {
    const okChannel = channelFilter === 'all' || d.source === channelFilter;
    const okAttendant = attendantFilter === 'all' || d.owner_id === attendantFilter;
    return okChannel && okAttendant;
  });

  const won = filteredDeals.filter(d => wonStageIds.has(d.stage_id) && new Date(d.closed_at ?? d.created_at).getTime() >= cutoff);
  const lost = filteredDeals.filter(d => lostStageIds.has(d.stage_id));
  const revenue = won.reduce((s, d) => s + Number(d.value), 0);
  const avgTicket = won.length > 0 ? revenue / won.length : 0;
  const conversion = won.length + lost.length > 0 ? (won.length / (won.length + lost.length)) * 100 : 0;

  const convs = conversations.data ?? [];
  const openConvs = convs.filter(c => c.status !== 'resolvida').length;
  const unread = convs.reduce((s, c) => s + (c.unread_count ?? 0), 0);

  const aiHandled = (agents.data ?? []).reduce((s, a) => s + (a.conversations_handled ?? 0), 0);
  const aiRate = (agents.data ?? []).length > 0
    ? (agents.data ?? []).reduce((s, a) => s + (a.resolution_rate ?? 0), 0) / (agents.data ?? []).length
    : 0;

  const paidPayments = (payments.data ?? []).filter(p => p.status === 'pago');
  const paidRevenue = paidPayments.reduce((s, p) => s + Number(p.amount), 0);

  const srcData = revenueBySource(filteredDeals, attributions.data ?? [], stages.data ?? []).slice(0, 6);
  const funnel = stageConversion(filteredDeals, stages.data ?? []).filter(s => !s.stage.is_won && !s.stage.is_lost);

  return (
    <div className="pb-8">
      <PageHeader
        title="Dashboard Executivo"
        subtitle="Visão geral do desempenho comercial e atendimento"
        actions={
          <>
            <select value={channelFilter} onChange={e => setChannelFilter(e.target.value)} className="input !w-auto !py-1.5">
              <option value="all">Todos os canais</option>
              {Object.entries(sourceLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <select value={attendantFilter} onChange={e => setAttendantFilter(e.target.value)} className="input !w-auto !py-1.5">
              <option value="all">Todos os atendentes</option>
              {(profiles.data ?? []).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <div className="flex bg-white dark:bg-slate-800 rounded-lg border border-slate-300 dark:border-slate-600 p-0.5">
              {PERIODS.map(p => (
                <button
                  key={p.id}
                  onClick={() => setPeriod(p.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    period === p.id ? 'bg-brand-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </>
        }
      />

      <div className="px-4 sm:px-6 mt-5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        <KpiCard label="Receita gerada" value={formatCurrency(revenue)} delta="12,4%" deltaUp icon={<DollarSign className="w-5 h-5" />} accent="emerald" />
        <KpiCard label="Total de leads" value={String((contacts.data ?? []).length)} delta="8,1%" deltaUp icon={<Users className="w-5 h-5" />} accent="brand" />
        <KpiCard label="Taxa de conversão" value={`${conversion.toFixed(1)}%`} delta="3,2%" deltaUp icon={<Percent className="w-5 h-5" />} accent="violet" />
        <KpiCard label="Ticket médio" value={formatCurrency(avgTicket)} delta="1,8%" deltaUp icon={<DollarSign className="w-5 h-5" />} accent="brand" />
        <KpiCard label="TMR (1ª resposta)" value="2m 34s" delta="0,4%" deltaUp={false} icon={<Timer className="w-5 h-5" />} accent="amber" />
        <KpiCard label="Resolução da IA" value={`${aiRate.toFixed(1)}%`} delta="5,6%" deltaUp icon={<Bot className="w-5 h-5" />} accent="emerald" />
      </div>

      <div className="px-4 sm:px-6 mt-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-slate-900 dark:text-white">Origem de cada venda</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">Receita por canal e campanha (UTM)</p>
            </div>
            <button onClick={() => onNavigate('reports')} className="btn-ghost !px-2 text-brand-600 dark:text-brand-400">
              Relatórios <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          {srcData.length > 0 ? (
            <BarChart data={srcData.map(s => ({ label: sourceLabels[s.source] ?? s.source, value: s.revenue, display: formatCurrency(s.revenue) }))} />
          ) : (
            <p className="text-sm text-slate-500 py-6 text-center">Nenhuma venda no período.</p>
          )}
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-slate-900 dark:text-white">Funil de vendas</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">Distribuição de negócios por etapa</p>
            </div>
            <button onClick={() => onNavigate('crm')} className="btn-ghost !px-2 text-brand-600 dark:text-brand-400">
              CRM <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-2.5">
            {funnel.map(({ stage, count, pct }) => (
              <div key={stage.id} className="flex items-center gap-3">
                <span className="w-44 shrink-0 text-sm text-slate-600 dark:text-slate-300 truncate" style={{}}>{stage.name}</span>
                <div className="flex-1 h-6 bg-slate-200 dark:bg-slate-700 rounded-md overflow-hidden">
                  <div
                    className="h-full rounded-md flex items-center justify-end pr-2 transition-all duration-500"
                    style={{ width: `${Math.max(pct, 8)}%`, backgroundColor: stage.color }}
                  >
                    <span className="text-[11px] font-bold text-white">{count}</span>
                  </div>
                </div>
                <span className="text-xs text-slate-500 w-9 text-right">{pct}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 sm:px-6 mt-4 grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-4">
          <MessageSquare className="w-5 h-5 text-brand-500 mb-2" />
          <p className="text-xl font-bold text-slate-900 dark:text-white">{openConvs}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Conversas abertas agora</p>
        </div>
        <div className="card p-4">
          <Filter className="w-5 h-5 text-amber-500 mb-2" />
          <p className="text-xl font-bold text-slate-900 dark:text-white">{unread}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Mensagens não lidas</p>
        </div>
        <div className="card p-4">
          <Bot className="w-5 h-5 text-emerald-500 mb-2" />
          <p className="text-xl font-bold text-slate-900 dark:text-white">{aiHandled.toLocaleString('pt-BR')}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Atendimentos pela IA</p>
        </div>
        <div className="card p-4">
          <DollarSign className="w-5 h-5 text-violet-500 mb-2" />
          <p className="text-xl font-bold text-slate-900 dark:text-white">{formatCurrency(paidRevenue)}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Pagamentos compensados</p>
        </div>
      </div>
    </div>
  );
}
