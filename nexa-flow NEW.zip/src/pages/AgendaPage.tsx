import { useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { CalendarDays, ChevronLeft, ChevronRight, Clock, Plus, Trash2, X } from 'lucide-react';
import { PageHeader, EmptyState, ErrorState, LoadingSpinner } from '@/components/ui';
import { useSession } from '@/lib/auth';
import {
  errorMessage, supabase, useAppointments, useAvailabilityRules, useContacts, useProfessionals, useServices,
} from '@/lib/queries';
import type { Appointment, AppointmentStatus, Slot } from '@/lib/types';
import { cn } from '@/lib/cn';

const STATUS_LABEL: Record<AppointmentStatus, string> = {
  agendado: 'Agendado', confirmado: 'Confirmado', compareceu: 'Compareceu', faltou: 'Faltou', cancelado: 'Cancelado',
};
const STATUS_STYLE: Record<AppointmentStatus, string> = {
  agendado: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  confirmado: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  compareceu: 'bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300',
  faltou: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  cancelado: 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
};
const WEEKDAYS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

// ---------- datas no fuso do workspace (nunca no fuso do navegador) ----------

function tzOffsetMs(utcMs: number, tz: string): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  }).formatToParts(new Date(utcMs));
  const g = (t: string) => Number(parts.find(p => p.type === t)?.value);
  return Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'), g('second')) - utcMs;
}

/** Instante UTC (ISO) em que começa o dia `ymd` (YYYY-MM-DD) no fuso `tz`. */
export function zonedDayStartIso(ymd: string, tz: string): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const guess = Date.UTC(y, m - 1, d);
  let utc = guess - tzOffsetMs(guess, tz);
  utc = guess - tzOffsetMs(utc, tz); // 2ª passada cobre mudança de horário de verão
  return new Date(utc).toISOString();
}

export function addDays(ymd: string, n: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

export function todayIn(tz: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
}

const hhmm = (iso: string, tz: string) =>
  new Intl.DateTimeFormat('pt-BR', { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(iso));

const longDate = (ymd: string) =>
  new Intl.DateTimeFormat('pt-BR', { timeZone: 'UTC', weekday: 'long', day: '2-digit', month: 'long' })
    .format(new Date(`${ymd}T12:00:00Z`));

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" role="dialog" aria-modal="true" aria-label={title}
      onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="card w-full max-w-md p-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-slate-900 dark:text-white">{title}</h2>
          <button className="btn-ghost p-1" onClick={onClose} aria-label="Fechar"><X className="w-4 h-4" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

const Label = ({ children }: { children: ReactNode }) => (
  <span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">{children}</span>
);

// ---------- novo agendamento ----------

function NewAppointmentModal({ day, tz, onClose, onDone }: { day: string; tz: string; onClose: () => void; onDone: () => void }) {
  const { workspace, profile } = useSession();
  const contacts = useContacts();
  const services = useServices();
  const professionals = useProfessionals();

  const [contactId, setContactId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [professionalId, setProfessionalId] = useState('');
  const [date, setDate] = useState(day);
  const [slots, setSlots] = useState<Slot[] | null>(null);
  const [slotKey, setSlotKey] = useState('');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadSlots = async (svc: string, prof: string, d: string) => {
    setSlots(null); setSlotKey(''); setError(null);
    if (!svc || !d) return;
    const { data, error: err } = await supabase.rpc('get_available_slots', {
      p_workspace: workspace.id, p_service: svc, p_from: d, p_to: d, p_professional: prof || null, p_step_minutes: 30,
    });
    if (err) { setError(errorMessage(err)); return; }
    setSlots((data as Slot[]) ?? []);
  };

  const key = (s: Slot) => `${s.professional_id}|${s.starts_at}`;
  const chosen = slots?.find(s => key(s) === slotKey);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!chosen || !contactId || !serviceId) return;
    setBusy(true); setError(null);
    const { error: err } = await supabase.rpc('book_appointment', {
      p_workspace: workspace.id, p_contact: contactId, p_service: serviceId,
      p_professional: chosen.professional_id, p_starts_at: chosen.starts_at,
      p_source: 'manual', p_notes: notes.trim() || null, p_created_by: profile.id,
    });
    setBusy(false);
    if (err) {
      setError(/slot_unavailable|no_availability|overlap|appointments_no_overlap/i.test(err.message)
        ? 'Esse horário acabou de ser ocupado. Escolha outro.' : errorMessage(err));
      void loadSlots(serviceId, professionalId, date);
      return;
    }
    onDone();
  };

  const activeServices = (services.data ?? []).filter(s => s.is_active);
  const activePros = (professionals.data ?? []).filter(p => p.is_active);

  return (
    <Modal title="Novo agendamento" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <label className="block"><Label>Contato</Label>
          <select className="input" value={contactId} onChange={e => setContactId(e.target.value)} required>
            <option value="">Selecione…</option>
            {(contacts.data ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>
        <label className="block"><Label>Serviço</Label>
          <select className="input" value={serviceId} required
            onChange={e => { setServiceId(e.target.value); void loadSlots(e.target.value, professionalId, date); }}>
            <option value="">Selecione…</option>
            {activeServices.map(s => <option key={s.id} value={s.id}>{s.name} · {s.duration_minutes} min</option>)}
          </select>
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="block"><Label>Profissional</Label>
            <select className="input" value={professionalId}
              onChange={e => { setProfessionalId(e.target.value); void loadSlots(serviceId, e.target.value, date); }}>
              <option value="">Qualquer um</option>
              {activePros.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </label>
          <label className="block"><Label>Data</Label>
            <input className="input" type="date" value={date} min={todayIn(tz)} required
              onChange={e => { setDate(e.target.value); void loadSlots(serviceId, professionalId, e.target.value); }} />
          </label>
        </div>

        <div>
          <Label>Horário</Label>
          {!serviceId ? <p className="text-sm text-slate-500">Escolha o serviço para ver os horários.</p>
            : slots === null ? <p className="text-sm text-slate-500">Buscando horários…</p>
            : slots.length === 0 ? <p className="text-sm text-slate-500">Nenhum horário livre nesse dia. Confira a disponibilidade em "Configurar".</p>
            : (
              <div className="flex flex-wrap gap-2">
                {slots.map(s => (
                  <button type="button" key={key(s)} onClick={() => setSlotKey(key(s))}
                    className={cn('px-2.5 py-1.5 rounded-lg text-sm border transition-colors',
                      key(s) === slotKey ? 'bg-brand-600 border-brand-600 text-white'
                        : 'border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:border-brand-500')}
                    title={s.professional_name}>
                    {hhmm(s.starts_at, tz)}{!professionalId && <span className="opacity-70"> · {s.professional_name.split(' ')[0]}</span>}
                  </button>
                ))}
              </div>
            )}
        </div>

        <label className="block"><Label>Observações</Label>
          <textarea className="input" rows={2} value={notes} onChange={e => setNotes(e.target.value)} maxLength={500} />
        </label>

        {error && <p role="alert" className="text-sm text-rose-600 dark:text-rose-400">{error}</p>}
        <div className="flex justify-end gap-2 pt-1">
          <button type="button" className="btn-secondary" onClick={onClose}>Cancelar</button>
          <button type="submit" className="btn-primary" disabled={busy || !chosen || !contactId}>Agendar</button>
        </div>
      </form>
    </Modal>
  );
}

// ---------- configuração (gestor+) ----------

function ConfigTab({ tz }: { tz: string }) {
  const { workspace } = useSession();
  const services = useServices();
  const pros = useProfessionals();
  const rules = useAvailabilityRules();
  const [error, setError] = useState<string | null>(null);

  const [svcName, setSvcName] = useState('');
  const [svcDur, setSvcDur] = useState(30);
  const [svcPrice, setSvcPrice] = useState('');
  const [proName, setProName] = useState('');
  const [rulePro, setRulePro] = useState('');
  const [ruleDays, setRuleDays] = useState<number[]>([1, 2, 3, 4, 5]);
  const [ruleStart, setRuleStart] = useState('09:00');
  const [ruleEnd, setRuleEnd] = useState('18:00');

  const run = async (op: PromiseLike<{ error: unknown }>, after: () => void) => {
    setError(null);
    const { error: err } = await op;
    if (err) setError(errorMessage(err)); else after();
  };

  const addService = (e: FormEvent) => {
    e.preventDefault();
    const price = svcPrice.trim() === '' ? null : Number(svcPrice.replace(',', '.'));
    if (price !== null && !Number.isFinite(price)) { setError('Preço inválido.'); return; }
    void run(supabase.from('services').insert({ workspace_id: workspace.id, name: svcName.trim(), duration_minutes: svcDur, price }),
      () => { setSvcName(''); setSvcPrice(''); services.refetch(); });
  };
  const addPro = (e: FormEvent) => {
    e.preventDefault();
    void run(supabase.from('professionals').insert({ workspace_id: workspace.id, name: proName.trim() }),
      () => { setProName(''); pros.refetch(); });
  };
  const addRules = (e: FormEvent) => {
    e.preventDefault();
    if (!rulePro || ruleDays.length === 0) { setError('Escolha o profissional e ao menos um dia.'); return; }
    if (ruleEnd <= ruleStart) { setError('O fim precisa ser depois do início.'); return; }
    void run(
      supabase.from('availability_rules').insert(ruleDays.map(w => ({
        workspace_id: workspace.id, professional_id: rulePro, weekday: w, start_time: ruleStart, end_time: ruleEnd,
      }))),
      () => rules.refetch());
  };
  const toggleActive = (table: 'services' | 'professionals', id: string, is_active: boolean) =>
    void run(supabase.from(table).update({ is_active: !is_active }).eq('id', id), () => (table === 'services' ? services.refetch() : pros.refetch()));
  const delRule = (id: string) => void run(supabase.from('availability_rules').delete().eq('id', id), () => rules.refetch());

  const proName_ = (id: string) => pros.data?.find(p => p.id === id)?.name ?? '—';

  return (
    <div className="p-4 sm:p-6 grid gap-4 lg:grid-cols-2">
      <p className="lg:col-span-2 text-sm text-slate-500 dark:text-slate-400">Horários calculados no fuso <b>{tz}</b>. A IA e a agenda só oferecem horários que existirem aqui.</p>
      {error && <p role="alert" className="lg:col-span-2 text-sm text-rose-600 dark:text-rose-400">{error}</p>}

      <section className="card p-4">
        <h3 className="font-semibold text-slate-900 dark:text-white mb-3">Serviços</h3>
        <form onSubmit={addService} className="flex flex-wrap gap-2 mb-3">
          <input className="input flex-1 min-w-[8rem]" placeholder="Nome (ex.: Limpeza de pele)" value={svcName} onChange={e => setSvcName(e.target.value)} required minLength={2} />
          <input className="input w-24" type="number" min={5} max={480} step={5} value={svcDur} onChange={e => setSvcDur(Number(e.target.value))} aria-label="Duração em minutos" />
          <input className="input w-24" placeholder="R$" value={svcPrice} onChange={e => setSvcPrice(e.target.value)} aria-label="Preço" />
          <button className="btn-primary" type="submit"><Plus className="w-4 h-4" /></button>
        </form>
        <ul className="divide-y divide-slate-200 dark:divide-slate-700">
          {(services.data ?? []).map(s => (
            <li key={s.id} className="py-2 flex items-center justify-between gap-2 text-sm">
              <span className={cn(!s.is_active && 'opacity-50')}>{s.name} · {s.duration_minutes} min{s.price != null && ` · R$ ${Number(s.price).toFixed(2).replace('.', ',')}`}</span>
              <button className="btn-ghost text-xs" onClick={() => toggleActive('services', s.id, s.is_active)}>{s.is_active ? 'Desativar' : 'Ativar'}</button>
            </li>
          ))}
          {services.data?.length === 0 && <li className="py-2 text-sm text-slate-500">Nenhum serviço ainda.</li>}
        </ul>
      </section>

      <section className="card p-4">
        <h3 className="font-semibold text-slate-900 dark:text-white mb-3">Profissionais</h3>
        <form onSubmit={addPro} className="flex gap-2 mb-3">
          <input className="input flex-1" placeholder="Nome" value={proName} onChange={e => setProName(e.target.value)} required minLength={2} />
          <button className="btn-primary" type="submit"><Plus className="w-4 h-4" /></button>
        </form>
        <ul className="divide-y divide-slate-200 dark:divide-slate-700">
          {(pros.data ?? []).map(p => (
            <li key={p.id} className="py-2 flex items-center justify-between text-sm">
              <span className={cn(!p.is_active && 'opacity-50')}>{p.name}</span>
              <button className="btn-ghost text-xs" onClick={() => toggleActive('professionals', p.id, p.is_active)}>{p.is_active ? 'Desativar' : 'Ativar'}</button>
            </li>
          ))}
          {pros.data?.length === 0 && <li className="py-2 text-sm text-slate-500">Nenhum profissional ainda.</li>}
        </ul>
      </section>

      <section className="card p-4 lg:col-span-2">
        <h3 className="font-semibold text-slate-900 dark:text-white mb-3">Disponibilidade semanal</h3>
        <form onSubmit={addRules} className="space-y-3 mb-4">
          <div className="flex flex-wrap gap-2">
            <select className="input w-auto" value={rulePro} onChange={e => setRulePro(e.target.value)} aria-label="Profissional">
              <option value="">Profissional…</option>
              {(pros.data ?? []).filter(p => p.is_active).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <input className="input w-auto" type="time" value={ruleStart} onChange={e => setRuleStart(e.target.value)} aria-label="Início" />
            <input className="input w-auto" type="time" value={ruleEnd} onChange={e => setRuleEnd(e.target.value)} aria-label="Fim" />
            <button className="btn-primary" type="submit">Adicionar faixa</button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {WEEKDAYS.map((w, i) => (
              <button type="button" key={w} aria-pressed={ruleDays.includes(i)}
                onClick={() => setRuleDays(d => d.includes(i) ? d.filter(x => x !== i) : [...d, i])}
                className={cn('px-2.5 py-1 rounded-lg text-xs border',
                  ruleDays.includes(i) ? 'bg-brand-600 border-brand-600 text-white' : 'border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300')}>
                {w.slice(0, 3)}
              </button>
            ))}
          </div>
        </form>
        <ul className="grid sm:grid-cols-2 gap-x-6 divide-y sm:divide-y-0 divide-slate-200 dark:divide-slate-700">
          {(rules.data ?? []).map(r => (
            <li key={r.id} className="py-1.5 flex items-center justify-between text-sm">
              <span>{proName_(r.professional_id)} · {WEEKDAYS[r.weekday]} · {r.start_time.slice(0, 5)}–{r.end_time.slice(0, 5)}</span>
              <button className="btn-ghost p-1" onClick={() => delRule(r.id)} aria-label="Remover faixa"><Trash2 className="w-3.5 h-3.5" /></button>
            </li>
          ))}
          {rules.data?.length === 0 && <li className="py-2 text-sm text-slate-500">Sem faixas: ninguém aparece como disponível.</li>}
        </ul>
      </section>
    </div>
  );
}

// ---------- página ----------

export default function AgendaPage() {
  const { workspace, isManager } = useSession();
  const tz = workspace.timezone || 'America/Sao_Paulo';
  const [tab, setTab] = useState<'dia' | 'config'>('dia');
  const [day, setDay] = useState(() => todayIn(tz));
  const [showNew, setShowNew] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const fromIso = useMemo(() => zonedDayStartIso(day, tz), [day, tz]);
  const toIso = useMemo(() => zonedDayStartIso(addDays(day, 1), tz), [day, tz]);
  const appts = useAppointments(fromIso, toIso);

  const setStatus = async (a: Appointment, status: AppointmentStatus) => {
    setActionError(null);
    const { error } = await supabase.from('appointments').update({ status }).eq('id', a.id);
    if (error) {
      setActionError(/overlap/i.test(error.message) ? 'Não foi possível reativar: o horário já foi ocupado.' : errorMessage(error));
    }
    appts.refetch();
  };

  return (
    <div>
      <PageHeader
        title="Agenda"
        subtitle={tab === 'dia' ? longDate(day) : 'Serviços, profissionais e horários'}
        actions={(
          <>
            {isManager && (
              <button className="btn-secondary" onClick={() => setTab(tab === 'dia' ? 'config' : 'dia')}>
                {tab === 'dia' ? 'Configurar' : 'Voltar à agenda'}
              </button>
            )}
            {tab === 'dia' && <button className="btn-primary" onClick={() => setShowNew(true)}><Plus className="w-4 h-4" /> Agendar</button>}
          </>
        )}
      />

      {tab === 'config' && isManager ? <ConfigTab tz={tz} /> : (
        <div className="p-4 sm:p-6 space-y-4">
          <div className="flex items-center gap-2">
            <button className="btn-secondary p-2" onClick={() => setDay(addDays(day, -1))} aria-label="Dia anterior"><ChevronLeft className="w-4 h-4" /></button>
            <input className="input w-auto" type="date" value={day} onChange={e => e.target.value && setDay(e.target.value)} aria-label="Data" />
            <button className="btn-secondary p-2" onClick={() => setDay(addDays(day, 1))} aria-label="Próximo dia"><ChevronRight className="w-4 h-4" /></button>
            <button className="btn-ghost text-sm" onClick={() => setDay(todayIn(tz))}>Hoje</button>
          </div>

          {actionError && <p role="alert" className="text-sm text-rose-600 dark:text-rose-400">{actionError}</p>}

          {appts.loading && !appts.data ? <LoadingSpinner label="Carregando agenda…" />
            : appts.error ? <ErrorState message={appts.error} />
            : appts.data && appts.data.length === 0 ? (
              <EmptyState icon={<CalendarDays className="w-8 h-8" />} title="Nada agendado neste dia" description='Use "Agendar" para marcar um horário.' />
            ) : (
              <ul className="space-y-2">
                {(appts.data ?? []).map(a => (
                  <li key={a.id} className={cn('card p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center gap-3', a.status === 'cancelado' && 'opacity-60')}>
                    <div className="flex items-center gap-2 sm:w-36 shrink-0 text-slate-900 dark:text-white font-semibold">
                      <Clock className="w-4 h-4 text-slate-400" /> {hhmm(a.starts_at, tz)}–{hhmm(a.ends_at, tz)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-slate-900 dark:text-white truncate">{a.contacts?.name ?? 'Contato removido'}</p>
                      <p className="text-sm text-slate-500 dark:text-slate-400 truncate">
                        {a.services?.name} · {a.professionals?.name}{a.source === 'ia' && ' · agendado pela IA'}{a.notes && ` · ${a.notes}`}
                      </p>
                    </div>
                    <select className={cn('input w-auto text-sm font-medium', STATUS_STYLE[a.status])} value={a.status}
                      onChange={e => void setStatus(a, e.target.value as AppointmentStatus)} aria-label="Status do agendamento">
                      {(Object.keys(STATUS_LABEL) as AppointmentStatus[]).map(s => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
                    </select>
                  </li>
                ))}
              </ul>
            )}
        </div>
      )}

      {showNew && <NewAppointmentModal day={day} tz={tz} onClose={() => setShowNew(false)} onDone={() => { setShowNew(false); appts.refetch(); }} />}
    </div>
  );
}
