import { useMemo, useState } from 'react';
import { Clock, Plus, Search, TrendingUp } from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState } from '@/components/ui';
import { Avatar, ChannelIcon } from '@/components/bits';
import { useContacts, useDeals, useStages, useProfiles, supabase } from '@/lib/queries';
import { formatCurrency, formatRelativeTime, temperatureLabels, temperatureStyles } from '@/lib/format';
import { cn } from '@/lib/cn';
import type { Deal } from '@/lib/types';

export default function CrmPage() {
  const deals = useDeals();
  const stages = useStages();
  const contacts = useContacts();
  const profiles = useProfiles();

  const [search, setSearch] = useState('');
  const [ownerFilter, setOwnerFilter] = useState('all');
  const [tempFilter, setTempFilter] = useState('all');
  const [dragId, setDragId] = useState<string | null>(null);

  if (deals.loading || stages.loading) return <LoadingSpinner label="Carregando funil..." />;
  if (deals.error) return <ErrorState message={deals.error} />;

  const contactMap = new Map((contacts.data ?? []).map(c => [c.id, c]));
  const orderedStages = [...(stages.data ?? [])].sort((a, b) => a.position - b.position);

  const filtered = (deals.data ?? []).filter(d => {
    const contact = d.contact_id ? contactMap.get(d.contact_id) : null;
    const okOwner = ownerFilter === 'all' || d.owner_id === ownerFilter;
    const okTemp = tempFilter === 'all' || d.temperature === tempFilter;
    const okSearch = !search ||
      d.title.toLowerCase().includes(search.toLowerCase()) ||
      contact?.name.toLowerCase().includes(search.toLowerCase());
    return okOwner && okTemp && okSearch;
  });

  const totalValue = filtered.reduce((s, d) => s + Number(d.value), 0);
  const wonIds = new Set(orderedStages.filter(s => s.is_won).map(s => s.id));

  const moveDeal = async (dealId: string, stageId: string) => {
    await supabase.from('deals').update({ stage_id: stageId }).eq('id', dealId);
    deals.refetch();
  };

  return (
    <div className="h-full flex flex-col">
      <PageHeader
        title="CRM / Funil de Vendas"
        subtitle={`${filtered.length} negócios · ${formatCurrency(totalValue)} em jogo`}
        actions={
          <>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Buscar negócio..."
                className="input !pl-9 !w-48"
              />
            </div>
            <select value={ownerFilter} onChange={e => setOwnerFilter(e.target.value)} className="input !w-auto !py-1.5 text-xs">
              <option value="all">Todos os responsáveis</option>
              {(profiles.data ?? []).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <select value={tempFilter} onChange={e => setTempFilter(e.target.value)} className="input !w-auto !py-1.5 text-xs">
              <option value="all">Toda temperatura</option>
              <option value="quente">Quente</option>
              <option value="morno">Morno</option>
              <option value="frio">Frio</option>
            </select>
            <button className="btn-primary !py-1.5 text-sm gap-1.5">
              <Plus className="w-4 h-4" /> Novo negócio
            </button>
            <button className="btn-ghost !py-1.5 text-sm gap-1.5" onClick={() => deals.refetch()}>
              <TrendingUp className="w-4 h-4" />
            </button>
          </>
        }
      />

      <div className="flex-1 overflow-x-auto overflow-y-hidden">
        <div className="flex gap-4 h-full min-w-max px-4 sm:px-6 py-4">
          {orderedStages.map(stage => {
            const stageDeals = filtered.filter(d => d.stage_id === stage.id);
            const stageValue = stageDeals.reduce((s, d) => s + Number(d.value), 0);
            return (
              <div
                key={stage.id}
                onDragOver={e => e.preventDefault()}
                onDrop={() => dragId && moveDeal(dragId, stage.id)}
                className="w-[280px] shrink-0 flex flex-col bg-slate-200/50 dark:bg-slate-800/40 rounded-xl"
              >
                <div className="p-3 border-b border-slate-300/50 dark:border-slate-700/50">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: stage.color }} />
                    <h3 className="font-semibold text-sm text-slate-800 dark:text-slate-100 truncate">{stage.name}</h3>
                    <span className="ml-auto text-xs font-bold text-slate-500">{stageDeals.length}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{formatCurrency(stageValue)}</p>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-2">
                  {stageDeals.map(deal => {
                    const contact = deal.contact_id ? contactMap.get(deal.contact_id) : null;
                    return (
                      <div
                        key={deal.id}
                        draggable
                        onDragStart={() => setDragId(deal.id)}
                        onDragEnd={() => setDragId(null)}
                        className="card p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-semibold text-slate-900 dark:text-white leading-snug">{deal.title}</p>
                          <span className={cn('badge !text-[10px] !px-1.5 shrink-0', temperatureStyles[deal.temperature])}>
                            {temperatureLabels[deal.temperature]}
                          </span>
                        </div>
                        <p className="text-base font-bold text-slate-900 dark:text-white mt-1.5">{formatCurrency(deal.value)}</p>
                        {contact && (
                          <div className="flex items-center gap-1.5 mt-2">
                            <Avatar name={contact.name} size="sm" className="!w-5 !h-5 !text-[9px]" />
                            <span className="text-xs text-slate-500 dark:text-slate-400 truncate">{contact.name}</span>
                            <ChannelIcon channel={contact.channel} className="w-3 h-3 ml-auto shrink-0" />
                          </div>
                        )}
                        {deal.next_task && (
                          <div className="flex items-center gap-1 mt-2 text-[11px] text-amber-600 dark:text-amber-400">
                            <Clock className="w-3 h-3" />
                            {deal.next_task}
                            {deal.next_task_at && <span className="text-slate-400">· {formatRelativeTime(deal.next_task_at)}</span>}
                          </div>
                        )}
                        {wonIds.has(deal.stage_id) && (
                          <span className="badge bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300 !text-[10px] mt-2">Ganho</span>
                        )}
                      </div>
                    );
                  })}
                  {stageDeals.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-6">Arraste negócios para cá</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
