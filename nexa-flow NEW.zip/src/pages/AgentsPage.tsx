import { useState } from 'react';
import {
  Bot, Calendar, Clock, MessageSquare, Pause, Play, Plus, Target, Wrench, Zap,
} from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState, KpiCard } from '@/components/ui';
import { useAiAgents, useConversations, supabase } from '@/lib/queries';
import { cn } from '@/lib/cn';
import type { AiAgent } from '@/lib/types';

const goalLabels: Record<AiAgent['goal'], string> = {
  sdr: 'SDR · Prospecção',
  suporte: 'Suporte',
  agendamento: 'Agendamento',
  fechamento: 'Fechamento',
};

const goalStyles: Record<AiAgent['goal'], string> = {
  sdr: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  suporte: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  agendamento: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  fechamento: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
};

export default function AgentsPage() {
  const agents = useAiAgents();
  const conversations = useConversations();
  const [selected, setSelected] = useState<string | null>(null);

  if (agents.loading) return <LoadingSpinner label="Carregando agentes..." />;
  if (agents.error) return <ErrorState message={agents.error} />;

  const list = agents.data ?? [];
  const activeAgents = list.filter(a => a.is_active);
  const totalHandled = list.reduce((s, a) => s + (a.conversations_handled ?? 0), 0);
  const avgResolution = list.length > 0
    ? list.reduce((s, a) => s + (a.resolution_rate ?? 0), 0) / list.length
    : 0;
  const openConvs = (conversations.data ?? []).filter(c => c.status !== 'resolvida').length;

  const selectedAgent = list.find(a => a.id === selected) ?? null;

  const toggleActive = async (agent: AiAgent) => {
    await supabase.from('ai_agents').update({ is_active: !agent.is_active }).eq('id', agent.id);
    agents.refetch();
  };

  return (
    <div className="pb-8">
      <PageHeader
        title="Agentes de IA"
        subtitle="Configure seus atendentes virtuais e suas personalidades"
        actions={
          <button className="btn-primary !py-1.5 text-sm gap-1.5">
            <Plus className="w-4 h-4" /> Novo agente
          </button>
        }
      />

      <div className="px-4 sm:px-6 mt-5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Agentes ativos" value={`${activeAgents.length} / ${list.length}`} icon={<Bot className="w-5 h-5" />} accent="brand" />
        <KpiCard label="Atendimentos pela IA" value={totalHandled.toLocaleString('pt-BR')} icon={<MessageSquare className="w-5 h-5" />} accent="violet" />
        <KpiCard label="Resolução média" value={`${avgResolution.toFixed(1)}%`} icon={<Target className="w-5 h-5" />} accent="emerald" />
        <KpiCard label="Conversas abertas" value={String(openConvs)} icon={<Zap className="w-5 h-5" />} accent="amber" />
      </div>

      <div className="px-4 sm:px-6 mt-6 grid grid-cols-1 lg:grid-cols-2 gap-4">
        {list.map(agent => (
          <div key={agent.id} className="card p-5 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <div className={cn(
                'w-11 h-11 rounded-xl flex items-center justify-center shrink-0',
                agent.is_active
                  ? 'bg-gradient-to-br from-brand-400 to-brand-600 text-white shadow-lg shadow-brand-500/30'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-400'
              )}>
                <Bot className="w-6 h-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold text-slate-900 dark:text-white">{agent.name}</h3>
                  <span className={cn('badge !text-[10px]', goalStyles[agent.goal])}>{goalLabels[agent.goal]}</span>
                  {agent.is_active ? (
                    <span className="badge bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300 !text-[10px]">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Ativo
                    </span>
                  ) : (
                    <span className="badge bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400 !text-[10px]">Pausado</span>
                  )}
                </div>
                {agent.persona && <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">{agent.persona}</p>}
              </div>
              <button
                onClick={() => toggleActive(agent)}
                className={cn('btn-ghost !px-2 !py-2 shrink-0', agent.is_active ? 'text-amber-500' : 'text-emerald-500')}
                title={agent.is_active ? 'Pausar agente' : 'Ativar agente'}
              >
                {agent.is_active ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
              <div>
                <p className="text-xs text-slate-400">Atendimentos</p>
                <p className="text-sm font-bold text-slate-900 dark:text-white">{(agent.conversations_handled ?? 0).toLocaleString('pt-BR')}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400">Resolução</p>
                <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{(agent.resolution_rate ?? 0).toFixed(0)}%</p>
              </div>
              <div>
                <p className="text-xs text-slate-400">Atraso resp.</p>
                <p className="text-sm font-bold text-slate-900 dark:text-white">{agent.response_delay_seconds ?? 0}s</p>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-3 text-xs text-slate-500 dark:text-slate-400">
              {agent.working_hours && (
                <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {agent.working_hours}</span>
              )}
              {(agent.tools ?? []).length > 0 && (
                <span className="flex items-center gap-1"><Wrench className="w-3.5 h-3.5" /> {agent.tools!.length} ferramentas</span>
              )}
              {agent.knowledge_base && (
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> Base de conhecimento</span>
              )}
            </div>

            <div className="flex gap-2 mt-4">
              <button onClick={() => setSelected(agent.id)} className="btn-ghost flex-1 !py-2 text-sm">Ver detalhes</button>
              <button className="btn-ghost flex-1 !py-2 text-sm">Editar</button>
            </div>
          </div>
        ))}
      </div>

      {selectedAgent && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-6" onClick={() => setSelected(null)}>
          <div
            className="bg-white dark:bg-surface-card w-full sm:max-w-lg rounded-t-2xl sm:rounded-2xl shadow-2xl p-6 max-h-[85vh] overflow-y-auto animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">{selectedAgent.name}</h3>
            <p className="text-sm text-slate-500 mb-4">{goalLabels[selectedAgent.goal]}</p>
            {selectedAgent.persona && (
              <section className="mb-4">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Personalidade</h4>
                <p className="text-sm text-slate-700 dark:text-slate-200">{selectedAgent.persona}</p>
              </section>
            )}
            {selectedAgent.tone && (
              <section className="mb-4">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Tom de voz</h4>
                <p className="text-sm text-slate-700 dark:text-slate-200">{selectedAgent.tone}</p>
              </section>
            )}
            {selectedAgent.restrictions && (
              <section className="mb-4">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Restrições</h4>
                <p className="text-sm text-slate-700 dark:text-slate-200">{selectedAgent.restrictions}</p>
              </section>
            )}
            {selectedAgent.knowledge_base && (
              <section className="mb-4">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Base de conhecimento</h4>
                <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-line">{selectedAgent.knowledge_base}</p>
              </section>
            )}
            {(selectedAgent.tools ?? []).length > 0 && (
              <section>
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Ferramentas</h4>
                <div className="space-y-1.5">
                  {selectedAgent.tools!.map(t => (
                    <div key={t.name} className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                      <p className="text-sm font-medium text-slate-800 dark:text-slate-100">{t.name}</p>
                      <p className="text-xs text-slate-500">{t.description}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}
            <button onClick={() => setSelected(null)} className="btn-primary w-full mt-5">Fechar</button>
          </div>
        </div>
      )}
    </div>
  );
}
