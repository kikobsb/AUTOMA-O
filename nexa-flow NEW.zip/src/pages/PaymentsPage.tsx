import { useMemo, useState, type FormEvent } from 'react';
import { Banknote, Barcode, CheckCircle2, CreditCard, ExternalLink, Link2, QrCode, TrendingUp, X, XCircle } from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState, KpiCard } from '@/components/ui';
import { usePayments, useContacts, useDeals, supabase, errorMessage } from '@/lib/queries';
import { useSession } from '@/lib/auth';
import { formatCurrency, formatDateTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import type { Payment } from '@/lib/types';

const statusLabels: Record<Payment['status'], string> = {
  pendente: 'Pendente',
  pago: 'Pago',
  falhou: 'Falhou',
  estornado: 'Estornado',
  expirado: 'Expirado',
};

const statusStyles: Record<Payment['status'], string> = {
  pendente: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  pago: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  falhou: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  estornado: 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
  expirado: 'bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400',
};

const methodLabels: Record<Payment['method'], string> = {
  pix: 'Pix',
  credit_card: 'Cartão de crédito',
  boleto: 'Boleto',
  checkout: 'Link InfinitePay',
};

const methodIcons: Record<Payment['method'], typeof QrCode> = {
  pix: QrCode,
  credit_card: CreditCard,
  boleto: Barcode,
  checkout: Link2,
};

function NewChargeModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const { workspace } = useSession();
  const contacts = useContacts();
  const [contactId, setContactId] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [link, setLink] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const value = Number(amount.replace(/\./g, '').replace(',', '.'));
    if (!Number.isFinite(value) || value < 1) { setError('Informe um valor de pelo menos R$ 1,00.'); return; }
    setBusy(true); setError(null);
    // a Edge Function valida o papel do usuário e cria o link na InfinitePay do workspace
    const { data, error: err } = await supabase.functions.invoke('create-payment-link', {
      body: { workspace_id: workspace.id, contact_id: contactId, amount_cents: Math.round(value * 100), description: description.trim() },
    });
    setBusy(false);
    if (err) { setError(errorMessage(err)); return; }
    if (!data?.payment_link) { setError(data?.error ?? 'A InfinitePay não devolveu o link.'); return; }
    setLink(data.payment_link);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" role="dialog" aria-modal="true" aria-label="Nova cobrança"
      onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="card w-full max-w-md p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-slate-900 dark:text-white">Nova cobrança</h2>
          <button className="btn-ghost p-1" onClick={onClose} aria-label="Fechar"><X className="w-4 h-4" /></button>
        </div>
        {!workspace.infinitepay_handle ? (
          <p className="text-sm text-amber-600 dark:text-amber-400">Cadastre o seu usuário InfinitePay (InfiniteTag) em Configurações antes de gerar cobranças.</p>
        ) : link ? (
          <div className="space-y-3">
            <p className="text-sm text-slate-600 dark:text-slate-300">Link gerado. Envie ao cliente:</p>
            <input className="input" readOnly value={link} onFocus={e => e.currentTarget.select()} />
            <div className="flex justify-end gap-2">
              <button className="btn-secondary" onClick={() => { void navigator.clipboard?.writeText(link); }}>Copiar</button>
              <button className="btn-primary" onClick={onClose}>Fechar</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <label className="block"><span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Contato</span>
              <select className="input" value={contactId} onChange={e => setContactId(e.target.value)} required>
                <option value="">Selecione…</option>
                {(contacts.data ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
            <label className="block"><span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Valor (R$)</span>
              <input className="input" inputMode="decimal" placeholder="150,00" value={amount} onChange={e => setAmount(e.target.value)} required />
            </label>
            <label className="block"><span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Descrição</span>
              <input className="input" value={description} onChange={e => setDescription(e.target.value)} required maxLength={120} placeholder="Ex.: Limpeza de pele + peeling" />
            </label>
            {error && <p role="alert" className="text-sm text-rose-600 dark:text-rose-400">{error}</p>}
            <div className="flex justify-end gap-2">
              <button type="button" className="btn-secondary" onClick={onClose}>Cancelar</button>
              <button type="submit" className="btn-primary" disabled={busy || !contactId}>{busy ? 'Gerando…' : 'Gerar link'}</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default function PaymentsPage() {
  const payments = usePayments();
  const contacts = useContacts();
  const deals = useDeals();
  const [statusFilter, setStatusFilter] = useState('all');
  const [methodFilter, setMethodFilter] = useState('all');
  const [showNew, setShowNew] = useState(false);
  const { isAdmin } = useSession();

  // useMemo ANTES dos returns antecipados (regra dos hooks: a ordem não pode mudar entre renders)
  const paid = useMemo(() => (payments.data ?? []).filter(p => p.status === 'pago'), [payments.data]);
  const byMethod = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of paid) m.set(p.method, (m.get(p.method) ?? 0) + Number(p.amount));
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [paid]);

  if (payments.loading && !payments.data) return <LoadingSpinner label="Carregando pagamentos..." />;
  if (payments.error) return <ErrorState message={payments.error} />;

  const contactMap = new Map((contacts.data ?? []).map(c => [c.id, c.name]));
  const dealMap = new Map((deals.data ?? []).map(d => [d.id, d.title]));

  const filtered = (payments.data ?? []).filter(p =>
    (statusFilter === 'all' || p.status === statusFilter) &&
    (methodFilter === 'all' || p.method === methodFilter)
  );

  const pending = (payments.data ?? []).filter(p => p.status === 'pendente');
  const paidRevenue = paid.reduce((s, p) => s + Number(p.amount), 0);
  const pendingRevenue = pending.reduce((s, p) => s + Number(p.amount), 0);
  const failed = (payments.data ?? []).filter(p => p.status === 'falhou' || p.status === 'expirado').length;

  const maxMethod = Math.max(...byMethod.map(([, v]) => v), 1);

  const markPaid = async (p: Payment) => {
    if (!window.confirm(`Marcar ${formatCurrency(Number(p.amount))} como recebido manualmente? Use só se o dinheiro já entrou na sua conta.`)) return;
    await supabase.from('payments').update({ status: 'pago', paid_at: new Date().toISOString() }).eq('id', p.id);
    payments.refetch();
  };

  return (
    <div className="pb-8">
      <PageHeader
        title="Pagamentos"
        subtitle="Links, cobranças e conciliação financeira"
        actions={
          <>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="input !w-auto !py-1.5 text-xs">
              <option value="all">Todos os status</option>
              {Object.entries(statusLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <select value={methodFilter} onChange={e => setMethodFilter(e.target.value)} className="input !w-auto !py-1.5 text-xs">
              <option value="all">Todas as formas</option>
              {Object.entries(methodLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <button className="btn-primary !py-1.5 text-sm gap-1.5" onClick={() => setShowNew(true)}>
              <Banknote className="w-4 h-4" /> Nova cobrança
            </button>
          </>
        }
      />

      <div className="px-4 sm:px-6 mt-5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Recebido" value={formatCurrency(paidRevenue)} icon={<CheckCircle2 className="w-5 h-5" />} accent="emerald" />
        <KpiCard label="A receber" value={formatCurrency(pendingRevenue)} icon={<TrendingUp className="w-5 h-5" />} accent="amber" />
        <KpiCard label="Pagamentos pagos" value={String(paid.length)} icon={<CreditCard className="w-5 h-5" />} accent="brand" />
        <KpiCard label="Falhas / expirados" value={String(failed)} icon={<XCircle className="w-5 h-5" />} accent="rose" />
      </div>

      <div className="px-4 sm:px-6 mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card p-5 lg:col-span-2">
          <h2 className="font-semibold text-slate-900 dark:text-white mb-3">Cobranças</h2>
          <div className="overflow-x-auto -mx-5">
            <table className="w-full text-sm min-w-[560px]">
              <thead>
                <tr className="text-left text-xs text-slate-400 uppercase tracking-wide border-b border-slate-200 dark:border-slate-700">
                  <th className="px-5 py-2 font-medium">Cliente</th>
                  <th className="px-3 py-2 font-medium">Forma</th>
                  <th className="px-3 py-2 font-medium">Valor</th>
                  <th className="px-3 py-2 font-medium">Status</th>
                  <th className="px-3 py-2 font-medium">Data</th>
                  <th className="px-5 py-2" />
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => {
                  const Icon = methodIcons[p.method];
                  return (
                    <tr key={p.id} className="border-b border-slate-100 dark:border-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                      <td className="px-5 py-3">
                        <p className="font-medium text-slate-800 dark:text-slate-100">
                          {p.contact_id ? contactMap.get(p.contact_id) ?? '—' : '—'}
                        </p>
                        {p.description && <p className="text-xs text-slate-400 truncate max-w-[200px]">{p.description}</p>}
                      </td>
                      <td className="px-3 py-3">
                        <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 text-xs">
                          <Icon className="w-3.5 h-3.5" /> {methodLabels[p.method]}
                        </span>
                      </td>
                      <td className="px-3 py-3 font-bold text-slate-900 dark:text-white">{formatCurrency(p.amount)}</td>
                      <td className="px-3 py-3">
                        <span className={cn('badge !text-[10px]', statusStyles[p.status])}>{statusLabels[p.status]}</span>
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-500">{formatDateTime(p.paid_at ?? p.created_at)}</td>
                      <td className="px-5 py-3 text-right">
                        {p.status === 'pendente' && isAdmin && (
                          <button onClick={() => markPaid(p)} className="btn-ghost !px-2 !py-1 text-xs text-emerald-600 dark:text-emerald-400">
                            Dar baixa manual
                          </button>
                        )}
                        {p.payment_link && p.status === 'pendente' && (
                          <a href={p.payment_link} target="_blank" rel="noreferrer" className="btn-ghost !px-2 !py-1 text-xs text-brand-600 dark:text-brand-400 ml-1">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && <p className="text-sm text-slate-400 text-center py-8">Nenhuma cobrança com esses filtros.</p>}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="font-semibold text-slate-900 dark:text-white mb-4">Recebido por forma de pagamento</h2>
          <div className="space-y-3">
            {byMethod.map(([method, value]) => (
              <div key={method}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-600 dark:text-slate-300">{methodLabels[method as Payment['method']] ?? method}</span>
                  <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(value)}</span>
                </div>
                <div className="h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-brand-500 rounded-full" style={{ width: `${Math.max((value / maxMethod) * 100, 3)}%` }} />
                </div>
              </div>
            ))}
            {byMethod.length === 0 && <p className="text-sm text-slate-400">Nenhum pagamento recebido ainda.</p>}
          </div>
          <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-700 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Ticket médio</span>
              <span className="font-semibold text-slate-900 dark:text-white">
                {formatCurrency(paid.length > 0 ? paidRevenue / paid.length : 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Cobranças pendentes</span>
              <span className="font-semibold text-amber-600 dark:text-amber-400">{pending.length}</span>
            </div>
          </div>
        </div>
      </div>
      {showNew && <NewChargeModal onClose={() => setShowNew(false)} onDone={() => payments.refetch()} />}
    </div>
  );
}
