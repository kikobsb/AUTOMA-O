import { useState, type FormEvent, type ReactNode } from 'react';
import { Building2, KeyRound, Loader2, LogOut, MailCheck } from 'lucide-react';
import { useAuth } from '@/lib/auth';

function Shell({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100 dark:bg-surface-darker">
      <div className="w-full max-w-sm">
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center shadow-lg shadow-brand-500/30">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold text-slate-900 dark:text-white">Nexa Flow</span>
        </div>
        <div className="card p-6">
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">{title}</h1>
          {subtitle && <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{subtitle}</p>}
          <div className="mt-5">{children}</div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">{label}</span>
      {children}
    </label>
  );
}

function ErrorLine({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="text-sm text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 rounded-lg px-3 py-2">
      {message}
    </p>
  );
}

export function FullScreenMessage({ title, message, action }: { title: string; message?: string; action?: ReactNode }) {
  return (
    <Shell title={title} subtitle={message}>
      {action}
    </Shell>
  );
}

export function FullScreenLoading() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 dark:bg-surface-darker">
      <div className="w-8 h-8 border-[3px] border-brand-500/25 border-t-brand-500 rounded-full animate-spin" role="status" aria-label="Carregando" />
    </div>
  );
}

type Mode = 'signin' | 'signup' | 'forgot';

export default function LoginPage() {
  const { signIn, signUp, requestPasswordReset } = useAuth();
  const [mode, setMode] = useState<Mode>('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const switchMode = (m: Mode) => { setMode(m); setError(null); setNotice(null); };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    if (mode === 'signup' && password.length < 8) { setError('A senha precisa ter pelo menos 8 caracteres.'); return; }
    setBusy(true);
    try {
      if (mode === 'signin') {
        const err = await signIn(email, password);
        if (err) setError(err);
      } else if (mode === 'signup') {
        const res = await signUp(name, email, password);
        if (res.error) setError(res.error);
        else if (res.needsConfirmation) {
          setNotice('Enviamos um link de confirmação para o seu e-mail. Abra-o e depois volte aqui para entrar.');
          setMode('signin');
          setPassword('');
        }
      } else {
        const err = await requestPasswordReset(email);
        if (err) setError(err);
        else setNotice('Se este e-mail tiver cadastro, enviamos o link para redefinir a senha.');
      }
    } finally {
      setBusy(false);
    }
  };

  const titles: Record<Mode, string> = {
    signin: 'Entrar na plataforma',
    signup: 'Criar sua conta',
    forgot: 'Redefinir senha',
  };

  return (
    <Shell
      title={titles[mode]}
      subtitle={mode === 'signup' ? 'Depois de confirmar o e-mail você cria o seu workspace ou aceita um convite.' : undefined}
    >
      <form onSubmit={submit} className="space-y-4" noValidate={false}>
        {mode === 'signup' && (
          <Field label="Seu nome">
            <input className="input" value={name} onChange={e => setName(e.target.value)} required minLength={2} autoComplete="name" />
          </Field>
        )}
        <Field label="E-mail">
          <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" />
        </Field>
        {mode !== 'forgot' && (
          <Field label="Senha">
            <input
              className="input"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              minLength={mode === 'signup' ? 8 : undefined}
              autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
            />
          </Field>
        )}

        <ErrorLine message={error} />
        {notice && (
          <p role="status" className="flex gap-2 text-sm text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 rounded-lg px-3 py-2">
            <MailCheck className="w-4 h-4 mt-0.5 shrink-0" /> {notice}
          </p>
        )}

        <button type="submit" disabled={busy} className="btn-primary w-full justify-center">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />}
          {mode === 'signin' ? 'Entrar' : mode === 'signup' ? 'Criar conta' : 'Enviar link'}
        </button>
      </form>

      <div className="mt-4 flex flex-col gap-1.5 text-sm text-center">
        {mode === 'signin' && (
          <>
            <button className="text-brand-600 dark:text-brand-400 hover:underline" onClick={() => switchMode('forgot')}>Esqueci minha senha</button>
            <button className="text-slate-500 dark:text-slate-400 hover:underline" onClick={() => switchMode('signup')}>Ainda não tenho conta</button>
          </>
        )}
        {mode !== 'signin' && (
          <button className="text-brand-600 dark:text-brand-400 hover:underline" onClick={() => switchMode('signin')}>Voltar para o login</button>
        )}
      </div>
    </Shell>
  );
}

export function NoWorkspaceScreen({ email }: { email: string }) {
  const { createWorkspace, signOut } = useAuth();
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const err = await createWorkspace(name);
    if (err) { setError(err); setBusy(false); }
  };

  return (
    <Shell
      title="Crie o seu workspace"
      subtitle={`Você entrou como ${email}. Não encontramos um convite para este e-mail. Crie o workspace da sua empresa (14 dias de teste) ou peça ao administrador para convidar você.`}
    >
      <form onSubmit={submit} className="space-y-4">
        <Field label="Nome da empresa ou clínica">
          <input className="input" value={name} onChange={e => setName(e.target.value)} required minLength={2} maxLength={80} />
        </Field>
        <ErrorLine message={error} />
        <button type="submit" disabled={busy || name.trim().length < 2} className="btn-primary w-full justify-center">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Criar workspace
        </button>
      </form>
      <button onClick={signOut} className="mt-4 w-full flex items-center justify-center gap-2 text-sm text-slate-500 hover:underline">
        <LogOut className="w-4 h-4" /> Sair e usar outro e-mail
      </button>
    </Shell>
  );
}

export function SetPasswordScreen() {
  const { setNewPassword } = useAuth();
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 8) { setError('A senha precisa ter pelo menos 8 caracteres.'); return; }
    setBusy(true);
    setError(null);
    const err = await setNewPassword(password);
    if (err) { setError(err); setBusy(false); }
  };

  return (
    <Shell title="Defina uma nova senha" subtitle="Escolha uma senha com pelo menos 8 caracteres.">
      <form onSubmit={submit} className="space-y-4">
        <Field label="Nova senha">
          <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} autoComplete="new-password" />
        </Field>
        <ErrorLine message={error} />
        <button type="submit" disabled={busy} className="btn-primary w-full justify-center">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />} Salvar senha
        </button>
      </form>
    </Shell>
  );
}
