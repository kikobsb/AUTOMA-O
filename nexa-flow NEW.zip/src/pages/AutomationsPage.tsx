import { useState } from 'react';
import {
  ArrowDown, CheckCircle2, Clock, GitBranch, Pause, Play, Plus, Workflow, Zap, AlertTriangle,
} from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState, EmptyState } from '@/components/ui';
import { useAutomations, supabase } from '@/lib/queries';
import { formatDateTime, formatRelativeTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import type { Automation, AutomationNode } from '@/lib/types';

const triggerLabels: Record<Automation['trigger_type'], string> = {
  nova_mensagem: 'Nova mensagem',
  palavra_chave: 'Palavra-chave',
  comentario_instagram: 'Comentário no Instagram',
  etapa_funil: 'Etapa do funil',
  webhook: 'Webhook',
  agendamento: 'Agendamento',
};

const nodeStyles: Record<AutomationNode['type'], string> = {
  trigger: 'bg-brand-50 border-brand-300 text-brand-700 dark:bg-brand-500/10 dark:border-brand-500/40 dark:text-brand-300',
  action: 'bg-sky-50 border-sky-300 text-sky-700 dark:bg-sky-500/10 dark:border-sky-500/40 dark:text-sky-300',
  condition: 'bg-amber-50 border-amber-300 text-amber-700 dark:bg-amber-500/10 dark:border-amber-500/40 dark:text-amber-300',
  delay: 'bg-violet-50 border-violet-300 text-violet-700 dark:bg-violet-500/10 dark:border-violet-500/40 dark:text-violet-300',
};

const nodeIcons: Record<AutomationNode['type'], typeof Zap> = {
  trigger: Zap,
  action: Workflow,
  condition: GitBranch,
  delay: Clock,
};

const nodeTypeLabels: Record<AutomationNode['type'], string> = {
  trigger: 'Gatilho',
  action: 'Ação',
  condition: 'Condição',
  delay: 'Atraso',
};

export default function AutomationsPage() {
  const automations = useAutomations();
  const [expanded, setExpanded] = useState<string | null>(null);

  if (automations.loading) return <LoadingSpinner label="Carregando automações..." />;
  if (automations.error) return <ErrorState message={automations.error} />;

  const list = automations.data ?? [];
  const active = list.filter(a => a.is_active);
  const totalRuns = list.reduce((s, a) => s + (a.runs_count ?? 0), 0);

  const toggle = async (a: Automation) => {
    await supabase.from('automations').update({ is_active: !a.is_active }).eq('id', a.id);
    automations.refetch();
  };

  return (
    <div className="pb-8">
      <PageHeader
        title="Automações"
        subtitle={`${active.length} ativas de ${list.length} · ${totalRuns.toLocaleString('pt-BR')} execuções no total`}
        actions={
          <button className="btn-primary !py-1.5 text-sm gap-1.5">
            <Plus className="w-4 h-4" /> Nova automação
          </button>
        }
      />

      <div className="px-4 sm:px-6 mt-5 space-y-4">
        {list.length === 0 && (
          <EmptyState icon={<Workflow className="w-6 h-6" />} title="Nenhuma automação criada" description="Crie fluxos automáticos para atender, qualificar e acompanhar leads sem esforço manual." />
        )}
        {list.map(a => {
          const nodes = a.nodes ?? [];
          const isOpen = expanded === a.id;
          return (
            <div key={a.id} className="card p-5">
              <div className="flex items-start gap-3">
                <button
                  onClick={() => toggle(a)}
                  className={cn(
                    'w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors',
                    a.is_active
                      ? 'bg-brand-500/10 text-brand-600 dark:text-brand-400'
                      : 'bg-slate-100 text-slate-400 dark:bg-slate-700'
                  )}
                  title={a.is_active ? 'Pausar automação' : 'Ativar automação'}
                >
                  {a.is_active ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
                </button>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-slate-900 dark:text-white">{a.name}</h3>
                    <span className={cn(
                      'badge !text-[10px]',
                      a.is_active
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'
                        : 'bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400'
                    )}>
                      {a.is_active ? 'Ativa' : 'Pausada'}
                    </span>
                  </div>
                  {a.description && <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{a.description}</p>}
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-500">
                    <span>Gatilho: <strong className="text-slate-700 dark:text-slate-200">{triggerLabels[a.trigger_type]}</strong></span>
                    <span>{(a.runs_count ?? 0).toLocaleString('pt-BR')} execuções</span>
                    {a.last_run_at && <span>Última: {formatRelativeTime(a.last_run_at)}</span>}
                  </div>
                </div>
                <button onClick={() => setExpanded(isOpen ? null : a.id)} className="btn-ghost !px-3 text-sm shrink-0">
                  {isOpen ? 'Ocultar fluxo' : 'Ver fluxo'}
                </button>
              </div>

              {isOpen && (
                <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                  <div className="max-w-md space-y-1">
                    {nodes.length === 0 && <p className="text-sm text-slate-400">Sem etapas configuradas.</p>}
                    {nodes.map((node, i) => {
                      const Icon = nodeIcons[node.type] ?? Workflow;
                      return (
                        <div key={i}>
                          {i > 0 && <div className="flex justify-center py-0.5"><ArrowDown className="w-4 h-4 text-slate-300 dark:text-slate-600" /></div>}
                          <div className={cn('rounded-lg border px-3 py-2.5', nodeStyles[node.type])}>
                            <div className="flex items-center gap-2">
                              <Icon className="w-4 h-4 shrink-0" />
                              <span className="text-[10px] font-bold uppercase tracking-wide opacity-70">{nodeTypeLabels[node.type]}</span>
                              <span className="text-sm font-semibold truncate">{node.label}</span>
                            </div>
                            {node.config && <p className="text-xs opacity-70 mt-1 ml-6">{node.config}</p>}
                            {node.type === 'condition' && (node.yes || node.no) && (
                              <div className="flex gap-4 mt-1.5 ml-6 text-[11px]">
                                {node.yes && <span className="text-emerald-600 dark:text-emerald-400">Sim → {node.yes}</span>}
                                {node.no && <span className="text-rose-600 dark:text-rose-400">Não → {node.no}</span>}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="px-4 sm:px-6 mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
          <div>
            <p className="text-sm font-bold text-slate-900 dark:text-white">{active.length} automações rodando</p>
            <p className="text-xs text-slate-500">Economizando horas de trabalho manual</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
          <div>
            <p className="text-sm font-bold text-slate-900 dark:text-white">{list.length - active.length} pausadas</p>
            <p className="text-xs text-slate-500">Revise e reative quando quiser</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <Clock className="w-5 h-5 text-brand-500 shrink-0" />
          <div>
            <p className="text-sm font-bold text-slate-900 dark:text-white">
              {list.length > 0 ? formatDateTime(list.reduce((latest, a) => (a.last_run_at ?? '') > latest ? a.last_run_at ?? '' : latest, '').replace('T', ' ').replace('Z', '')) : '—'}
            </p>
            <p className="text-xs text-slate-500">Execução mais recente</p>
          </div>
        </div>
      </div>
    </div>
  );
}
