import { useState } from 'react';
import { CalendarClock, Check, MailCheck, MessageCircle, Pause, Play, Plus, Reply, Send, XCircle } from 'lucide-react';
import { PageHeader, LoadingSpinner, ErrorState, EmptyState, KpiCard } from '@/components/ui';
import { useCampaigns, supabase } from '@/lib/queries';
import { formatDateTime } from '@/lib/format';
import { cn } from '@/lib/cn';
import type { Campaign } from '@/lib/types';

const statusLabels: Record<Campaign['status'], string> = {
  rascunho: 'Rascunho',
  agendada: 'Agendada',
  em_andamento: 'Em andamento',
  concluida: 'Concluída',
  pausada: 'Pausada',
};

const statusStyles: Record<Campaign['status'], string> = {
  rascunho: 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
  agendada: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  em_andamento: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  concluida: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  pausada: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
};

const segmentLabels: Record<Campaign['segment_type'], string> = {
  tag: 'Por etiqueta',
  etapa_funil: 'Por etapa do funil',
  csv: 'Lista importada',
  todos: 'Todos os contatos',
};

export default function CampaignsPage() {
  const campaigns = useCampaigns();
  const [selected, setSelected] = useState<string | null>(null);

  if (campaigns.loading) return <LoadingSpinner label="Carregando disparos..." />;
  if (campaigns.error) return <ErrorState message={campaigns.error} />;

  const list = campaigns.data ?? [];
  const totals = list.reduce(
    (acc, c) => ({
      sent: acc.sent + c.sent_count,
      delivered: acc.delivered + c.delivered_count,
      read: acc.read + c.read_count,
      replied: acc.replied + c.replied_count,
      failed: acc.failed + c.failed_count,
    }),
    { sent: 0, delivered: 0, read: 0, replied: 0, failed: 0 }
  );
  const deliveryRate = totals.sent > 0 ? (totals.delivered / totals.sent) * 100 : 0;
  const replyRate = totals.delivered > 0 ? (totals.replied / totals.delivered) * 100 : 0;

  const selectedCampaign = list.find(c => c.id === selected) ?? null;

  const toggleStatus = async (c: Campaign) => {
    const next = c.status === 'em_andamento' ? 'pausada' : 'em_andamento';
    await supabase.from('campaigns').update({ status: next }).eq('id', c.id);
    campaigns.refetch();
  };

  return (
    <div className="pb-8">
      <PageHeader
        title="Disparos em massa"
        subtitle="Campanhas segmentadas por WhatsApp, e-mail e mais"
        actions={
          <button className="btn-primary !py-1.5 text-sm gap-1.5">
            <Plus className="w-4 h-4" /> Novo disparo
          </button>
        }
      />

      <div className="px-4 sm:px-6 mt-5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Mensagens enviadas" value={totals.sent.toLocaleString('pt-BR')} icon={<Send className="w-5 h-5" />} accent="brand" />
        <KpiCard label="Taxa de entrega" value={`${deliveryRate.toFixed(1)}%`} icon={<MailCheck className="w-5 h-5" />} accent="emerald" />
        <KpiCard label="Taxa de resposta" value={`${replyRate.toFixed(1)}%`} icon={<Reply className="w-5 h-5" />} accent="violet" />
        <KpiCard label="Falhas" value={totals.failed.toLocaleString('pt-BR')} icon={<XCircle className="w-5 h-5" />} accent="rose" />
      </div>

      <div className="px-4 sm:px-6 mt-6 space-y-4">
        {list.length === 0 && (
          <EmptyState icon={<Send className="w-6 h-6" />} title="Nenhum disparo ainda" description="Crie campanhas segmentadas e acompanhe entrega, leitura e respostas em tempo real." />
        )}
        {list.map(c => {
          const progress = c.total_recipients > 0 ? (c.sent_count / c.total_recipients) * 100 : 0;
          return (
            <div key={c.id} className="card p-5">
              <div className="flex items-start gap-3 flex-wrap">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-slate-900 dark:text-white">{c.name}</h3>
                    <span className={cn('badge !text-[10px]', statusStyles[c.status])}>{statusLabels[c.status]}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {c.channel === 'whatsapp' ? <MessageCircle className="w-3.5 h-3.5 inline mr-1 -mt-0.5 text-[#25D366]" /> : <Send className="w-3.5 h-3.5 inline mr-1 -mt-0.5" />}
                    {c.channel} · {segmentLabels[c.segment_type]} · {c.total_recipients.toLocaleString('pt-BR')} destinatários
                  </p>
                </div>
                {(c.status === 'em_andamento' || c.status === 'pausada' || c.status === 'agendada') && (
                  <button onClick={() => toggleStatus(c)} className="btn-ghost !px-2 !py-2 shrink-0" title={c.status === 'em_andamento' ? 'Pausar' : 'Iniciar'}>
                    {c.status === 'em_andamento' ? <Pause className="w-4 h-4 text-amber-500" /> : <Play className="w-4 h-4 text-emerald-500" />}
                  </button>
                )}
                <button onClick={() => setSelected(c.id)} className="btn-ghost !px-3 text-sm shrink-0">Métricas</button>
              </div>

              <div className="mt-3">
                <div className="flex justify-between text-xs text-slate-500 mb-1">
                  <span>{c.sent_count.toLocaleString('pt-BR')} enviadas</span>
                  <span>{progress.toFixed(0)}% da lista</span>
                </div>
                <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-brand-500 rounded-full transition-all duration-500" style={{ width: `${Math.max(progress, 2)}%` }} />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-4">
                {[
                  { icon: <Send className="w-3.5 h-3.5" />, label: 'Enviadas', value: c.sent_count },
                  { icon: <MailCheck className="w-3.5 h-3.5" />, label: 'Entregues', value: c.delivered_count },
                  { icon: <Check className="w-3.5 h-3.5" />, label: 'Lidas', value: c.read_count },
                  { icon: <Reply className="w-3.5 h-3.5" />, label: 'Respostas', value: c.replied_count },
                  { icon: <XCircle className="w-3.5 h-3.5" />, label: 'Falhas', value: c.failed_count },
                ].map(({ icon, label, value }) => (
                  <div key={label} className="rounded-lg bg-slate-50 dark:bg-slate-700/40 px-2.5 py-2">
                    <p className="flex items-center gap-1 text-[10px] text-slate-400 font-medium uppercase tracking-wide">{icon} {label}</p>
                    <p className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-0.5">{value.toLocaleString('pt-BR')}</p>
                  </div>
                ))}
              </div>

              {c.scheduled_at && c.status === 'agendada' && (
                <p className="flex items-center gap-1.5 text-xs text-sky-600 dark:text-sky-400 mt-3">
                  <CalendarClock className="w-3.5 h-3.5" /> Agendado para {formatDateTime(c.scheduled_at)}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {selectedCampaign && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/50 animate-fade-in" onClick={() => setSelected(null)}>
          <div
            className="bg-white dark:bg-surface-card w-full sm:max-w-lg rounded-t-2xl sm:rounded-2xl shadow-2xl p-6 max-h-[85vh] overflow-y-auto animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">{selectedCampaign.name}</h3>
            <p className="text-sm text-slate-500 mb-4">{statusLabels[selectedCampaign.status]} · {segmentLabels[selectedCampaign.segment_type]}</p>

            {selectedCampaign.template_content && (
              <section className="mb-4">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Mensagem</h4>
                <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-line bg-slate-50 dark:bg-slate-700/40 rounded-lg p-3">{selectedCampaign.template_content}</p>
              </section>
            )}

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                <p className="text-xs text-slate-400">Taxa de leitura</p>
                <p className="font-bold text-slate-900 dark:text-white">
                  {selectedCampaign.sent_count > 0 ? `${((selectedCampaign.read_count / selectedCampaign.sent_count) * 100).toFixed(1)}%` : '—'}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                <p className="text-xs text-slate-400">Taxa de resposta</p>
                <p className="font-bold text-slate-900 dark:text-white">
                  {selectedCampaign.delivered_count > 0 ? `${((selectedCampaign.replied_count / selectedCampaign.delivered_count) * 100).toFixed(1)}%` : '—'}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                <p className="text-xs text-slate-400">Opt-outs</p>
                <p className="font-bold text-slate-900 dark:text-white">{selectedCampaign.opt_out_count}</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                <p className="text-xs text-slate-400">Lote / intervalo</p>
                <p className="font-bold text-slate-900 dark:text-white">{selectedCampaign.batch_size ?? '—'} / {selectedCampaign.batch_interval_minutes ?? '—'} min</p>
              </div>
            </div>

            <button onClick={() => setSelected(null)} className="btn-primary w-full mt-5">Fechar</button>
          </div>
        </div>
      )}
    </div>
  );
}
