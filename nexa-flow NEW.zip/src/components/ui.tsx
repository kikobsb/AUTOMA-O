import { cn } from '@/lib/cn';
import type { ReactNode } from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}

export function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between px-4 sm:px-6 py-4 sticky top-0 z-20 bg-slate-100/90 dark:bg-surface-darker/90 backdrop-blur border-b border-slate-200 dark:border-slate-800">
      <div className="min-w-0">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white truncate">{title}</h1>
        {subtitle && <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}

export function KpiCard({
  label, value, delta, deltaUp, icon, accent = 'brand',
}: {
  label: string;
  value: string;
  delta?: string;
  deltaUp?: boolean;
  icon: ReactNode;
  accent?: 'brand' | 'emerald' | 'amber' | 'violet' | 'rose';
}) {
  const accents: Record<string, string> = {
    brand: 'bg-brand-500/10 text-brand-600 dark:text-brand-400',
    emerald: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
    amber: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
    violet: 'bg-violet-500/10 text-violet-600 dark:text-violet-400',
    rose: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
  };
  return (
    <div className="card p-4 sm:p-5 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between gap-2">
        <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center shrink-0', accents[accent])}>
          {icon}
        </div>
        {delta && (
          <span
            className={cn(
              'badge',
              deltaUp
                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'
                : 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'
            )}
          >
            {deltaUp ? '↑' : '↓'} {delta}
          </span>
        )}
      </div>
      <p className="mt-3 text-2xl font-bold text-slate-900 dark:text-white tracking-tight">{value}</p>
      <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{label}</p>
    </div>
  );
}

export function EmptyState({ icon, title, description }: { icon: ReactNode; title: string; description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-400">
        {icon}
      </div>
      <p className="mt-4 font-medium text-slate-700 dark:text-slate-300">{title}</p>
      {description && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-sm">{description}</p>}
    </div>
  );
}

export function LoadingSpinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3">
      <div className="w-8 h-8 border-[3px] border-brand-500/25 border-t-brand-500 rounded-full animate-spin" />
      {label && <p className="text-sm text-slate-500">{label}</p>}
    </div>
  );
}

export function ErrorState({ message }: { message: string }) {
  return (
    <div className="card p-4 m-4 border-rose-300 dark:border-rose-500/40 bg-rose-50 dark:bg-rose-500/10">
      <p className="text-sm font-medium text-rose-700 dark:text-rose-300">Não foi possível carregar os dados</p>
      <p className="text-sm text-rose-600/80 dark:text-rose-400/80 mt-1">{message}</p>
    </div>
  );
}
