import type { LeadAttribution, Deal, Stage } from '@/lib/types';
import { formatCompactCurrency } from '@/lib/format';

export function revenueBySource(deals: Deal[], attributions: LeadAttribution[], stages: Stage[]) {
  const wonStageIds = new Set(stages.filter(s => s.is_won).map(s => s.id));
  const won = deals.filter(d => wonStageIds.has(d.stage_id));
  const bySource = new Map<string, { revenue: number; count: number }>();
  for (const d of won) {
    const key = d.utm_source ?? d.source ?? 'direto';
    const cur = bySource.get(key) ?? { revenue: 0, count: 0 };
    bySource.set(key, { revenue: cur.revenue + Number(d.value), count: cur.count + 1 });
  }
  return [...bySource.entries()]
    .map(([source, v]) => ({ source, ...v }))
    .sort((a, b) => b.revenue - a.revenue);
}

export function utmBreakdown(attributions: LeadAttribution[]) {
  const byCampaign = new Map<string, number>();
  for (const a of attributions) {
    if (!a.utm_campaign) continue;
    byCampaign.set(a.utm_campaign, (byCampaign.get(a.utm_campaign) ?? 0) + 1);
  }
  return [...byCampaign.entries()]
    .map(([campaign, leads]) => ({ campaign, leads }))
    .sort((a, b) => b.leads - a.leads);
}

export function stageConversion(deals: Deal[], stages: Stage[]) {
  const ordered = [...stages].sort((a, b) => a.position - b.position);
  const total = deals.length || 1;
  return ordered.map(s => ({
    stage: s,
    count: deals.filter(d => d.stage_id === s.id).length,
    pct: Math.round((deals.filter(d => d.stage_id === s.id).length / total) * 100),
  }));
}

export function BarChart({ data }: { data: { label: string; value: number; display: string; color?: string }[] }) {
  const max = Math.max(...data.map(d => d.value), 1);
  return (
    <div className="space-y-3">
      {data.map(d => (
        <div key={d.label}>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-slate-600 dark:text-slate-300 font-medium capitalize">{d.label}</span>
            <span className="text-slate-900 dark:text-white font-semibold">{d.display}</span>
          </div>
          <div className="h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div
              className={d.color ?? 'bg-brand-500'}
              style={{ width: `${Math.max((d.value / max) * 100, 3)}%` }}
              role="presentation"
            />
          </div>
        </div>
      ))}
    </div>
  );
}
