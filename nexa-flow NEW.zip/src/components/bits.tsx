import { Bot, Building2, Instagram, MessageCircle, Globe, Mail, Send } from 'lucide-react';
import type { Channel } from '@/lib/types';
import { channelLabels } from '@/lib/format';
import { cn } from '@/lib/cn';

export function ChannelIcon({ channel, className }: { channel: Channel | string; className?: string }) {
  const cls = cn('w-4 h-4', className);
  switch (channel) {
    case 'whatsapp': return <MessageCircle className={cn(cls, 'text-[#25D366]')} />;
    case 'instagram': return <Instagram className={cn(cls, 'text-[#E1306C]')} />;
    case 'site_chat': return <Globe className={cn(cls, 'text-sky-500')} />;
    case 'email': return <Mail className={cn(cls, 'text-amber-500')} />;
    case 'telegram': return <Send className={cn(cls, 'text-[#2AABEE]')} />;
    default: return <Globe className={cls} />;
  }
}

export function SourceBadge({ source }: { source: string | null }) {
  if (!source) return <span className="text-slate-400 text-xs">—</span>;
  return (
    <span className="badge bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300 gap-1.5">
      <ChannelIcon channel={source} className="w-3 h-3" />
      {channelLabels[source as Channel] ?? source}
    </span>
  );
}

export function Avatar({
  name, size = 'md', className,
}: { name: string; size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const sizes = { sm: 'w-8 h-8 text-[11px]', md: 'w-10 h-10 text-xs', lg: 'w-12 h-12 text-sm' };
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(n => n[0]).join('').toUpperCase();
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  const palette = ['bg-rose-500', 'bg-amber-500', 'bg-emerald-500', 'bg-sky-500', 'bg-violet-500', 'bg-pink-500', 'bg-teal-500', 'bg-orange-500'];
  return (
    <div className={cn('rounded-full flex items-center justify-center font-bold text-white shrink-0', sizes[size], palette[hash % palette.length], className)}>
      {initials}
    </div>
  );
}

export function PlanBadge({ plan }: { plan: string }) {
  const styles: Record<string, string> = {
    trial: 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
    starter: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
    professional: 'bg-brand-100 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300',
    enterprise: 'bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300',
  };
  const icons: Record<string, typeof Building2> = { enterprise: Building2, professional: Bot };
  const Icon = icons[plan] ?? Building2;
  return (
    <span className={cn('badge gap-1 capitalize', styles[plan])}>
      <Icon className="w-3 h-3" />
      {plan}
    </span>
  );
}
