import {
  BarChart3, Bot, Building2, CalendarDays, CreditCard, LayoutDashboard, LogOut, MessagesSquare,
  Send, Settings, Sparkles, Workflow,
} from 'lucide-react';
import { ThemeProvider, useTheme } from '@/lib/theme';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { useState } from 'react';
import DashboardPage from '@/pages/DashboardPage';
import InboxPage from '@/pages/InboxPage';
import CrmPage from '@/pages/CrmPage';
import AgendaPage from '@/pages/AgendaPage';
import AgentsPage from '@/pages/AgentsPage';
import AutomationsPage from '@/pages/AutomationsPage';
import CampaignsPage from '@/pages/CampaignsPage';
import PaymentsPage from '@/pages/PaymentsPage';
import ReportsPage from '@/pages/ReportsPage';
import SettingsPage from '@/pages/SettingsPage';
import { cn } from '@/lib/cn';
import { useConversations } from '@/lib/queries';
import { AuthProvider, useAuth, useSession, type Role } from '@/lib/auth';
import LoginPage, { FullScreenLoading, FullScreenMessage, NoWorkspaceScreen, SetPasswordScreen } from '@/pages/LoginPage';

export type PageId =
  | 'dashboard' | 'inbox' | 'crm' | 'agenda' | 'agents' | 'automations'
  | 'campaigns' | 'payments' | 'reports' | 'settings';

type MinRole = 'any' | 'manager' | 'admin';

// A navegação só esconde o que o papel não pode usar. Quem de fato BLOQUEIA é o banco (RLS).
const NAV: { id: PageId; label: string; icon: typeof LayoutDashboard; min: MinRole }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, min: 'manager' },
  { id: 'inbox', label: 'Atendimento', icon: MessagesSquare, min: 'any' },
  { id: 'crm', label: 'CRM / Funil', icon: BarChart3, min: 'any' },
  { id: 'agenda', label: 'Agenda', icon: CalendarDays, min: 'any' },
  { id: 'agents', label: 'Agentes de IA', icon: Bot, min: 'manager' },
  { id: 'automations', label: 'Automações', icon: Workflow, min: 'manager' },
  { id: 'campaigns', label: 'Disparos', icon: Send, min: 'manager' },
  { id: 'payments', label: 'Pagamentos', icon: CreditCard, min: 'manager' },
  { id: 'reports', label: 'Relatórios', icon: Sparkles, min: 'manager' },
  { id: 'settings', label: 'Configurações', icon: Settings, min: 'admin' },
];

function canSee(min: MinRole, role: Role): boolean {
  if (min === 'any') return true;
  if (min === 'manager') return role === 'admin' || role === 'gestor';
  return role === 'admin';
}

const ROLE_LABEL: Record<Role, string> = { admin: 'Administrador', gestor: 'Gestor', atendente: 'Atendente' };

function planLabel(plan: string): string {
  const map: Record<string, string> = { trial: 'Teste grátis', starter: 'Plano Starter', professional: 'Plano Professional', enterprise: 'Plano Enterprise' };
  return map[plan] ?? plan;
}

function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).map(w => w[0]).slice(0, 2).join('').toUpperCase() || '?';
}

function AppShell() {
  const { profile, workspace, role } = useSession();
  const { signOut } = useAuth();
  const visibleNav = NAV.filter(n => canSee(n.min, role));
  const [requested, setPage] = useState<PageId>(visibleNav[0].id);
  // se o papel não enxerga a página pedida, cai na primeira permitida
  const page: PageId = visibleNav.some(n => n.id === requested) ? requested : visibleNav[0].id;
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { data: conversations } = useConversations();
  const unread = (conversations ?? []).reduce((sum, c) => sum + (c.unread_count ?? 0), 0);

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden animate-fade-in"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed lg:static inset-y-0 left-0 z-50 w-64 flex flex-col bg-surface-dark dark:bg-surface-darker border-r border-slate-800 transition-transform duration-200',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        <div className="flex items-center gap-3 px-5 h-16 border-b border-slate-800">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center shadow-lg shadow-brand-500/30">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <p className="text-white font-semibold text-sm leading-tight truncate" title={workspace.name}>{workspace.name}</p>
            <p className="text-slate-400 text-xs">{planLabel(workspace.plan)}</p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {visibleNav.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => { setPage(id); setSidebarOpen(false); }}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors duration-150 relative group',
                page === id
                  ? 'bg-brand-500/15 text-brand-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              )}
            >
              {page === id && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-brand-500 rounded-r-full" />
              )}
              <Icon className="w-[18px] h-[18px] shrink-0" />
              <span className="truncate">{label}</span>
              {id === 'inbox' && unread > 0 && (
                <span className="ml-auto bg-rose-500 text-white text-[11px] font-semibold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                  {unread}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-slate-800">
          <button
            onClick={toggleTheme}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-colors"
          >
            {theme === 'dark' ? (
              <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/></svg>
            ) : (
              <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            )}
            {theme === 'dark' ? 'Tema claro' : 'Tema escuro'}
          </button>
          <div className="flex items-center gap-3 px-3 py-2.5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-400 to-violet-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
              {initials(profile.name)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-slate-200 text-sm font-medium truncate" title={profile.email}>{profile.name}</p>
              <p className="text-slate-500 text-xs">{ROLE_LABEL[role]}</p>
            </div>
            <button
              onClick={() => { void signOut(); }}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-colors"
              title="Sair"
              aria-label="Sair"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile topbar */}
        <div className="lg:hidden flex items-center gap-3 h-14 px-4 bg-surface-dark border-b border-slate-800 shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 -ml-2 rounded-lg text-slate-300 hover:bg-slate-800"
            aria-label="Abrir menu"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
          </button>
          <span className="text-white font-semibold">
            {visibleNav.find(n => n.id === page)?.label}
          </span>
          {unread > 0 && page !== 'inbox' && (
            <span className="ml-auto bg-rose-500 text-white text-[11px] font-semibold px-2 py-0.5 rounded-full">
              {unread} novas
            </span>
          )}
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="animate-fade-in h-full">
            {page === 'dashboard' && <DashboardPage onNavigate={setPage} />}
            {page === 'inbox' && <InboxPage />}
            {page === 'crm' && <CrmPage />}
            {page === 'agenda' && <AgendaPage />}
            {page === 'agents' && <AgentsPage />}
            {page === 'automations' && <AutomationsPage />}
            {page === 'campaigns' && <CampaignsPage />}
            {page === 'payments' && <PaymentsPage />}
            {page === 'reports' && <ReportsPage />}
            {page === 'settings' && <SettingsPage />}
          </div>
        </div>
      </main>
    </div>
  );
}

function Gate() {
  const { state, recovery, signOut, reload } = useAuth();

  if (recovery) return <SetPasswordScreen />;

  switch (state.status) {
    case 'loading':
      return <FullScreenLoading />;
    case 'signed_out':
      return <LoginPage />;
    case 'no_workspace':
      return <NoWorkspaceScreen email={state.email} />;
    case 'error':
      return (
        <FullScreenMessage
          title="Não foi possível entrar"
          message={state.message}
          action={
            <div className="flex gap-2">
              <button className="btn-primary" onClick={reload}>Tentar de novo</button>
              <button className="btn-secondary" onClick={() => { void signOut(); }}>Sair</button>
            </div>
          }
        />
      );
    case 'ready':
      // key: ao trocar de usuário, todo o estado das telas é descartado
      return <AppShell key={state.profile.id} />;
  }
}

export default function App() {
  return (
    <ThemeProvider>
      <ErrorBoundary>
        <AuthProvider>
          <Gate />
        </AuthProvider>
      </ErrorBoundary>
    </ThemeProvider>
  );
}
