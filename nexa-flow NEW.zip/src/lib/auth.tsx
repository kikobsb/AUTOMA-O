import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import type { Profile, Workspace } from './types';

export type Role = Profile['role'];

type AuthState =
  | { status: 'loading' }
  | { status: 'signed_out' }
  /** logado, mas ainda sem workspace (sem convite): precisa criar o próprio */
  | { status: 'no_workspace'; email: string }
  | { status: 'ready'; email: string; profile: Profile; workspace: Workspace }
  | { status: 'error'; message: string };

interface AuthContextValue {
  state: AuthState;
  /** true enquanto o usuário veio do link "esqueci minha senha" e precisa definir a nova */
  recovery: boolean;
  signIn: (email: string, password: string) => Promise<string | null>;
  signUp: (name: string, email: string, password: string) => Promise<{ error: string | null; needsConfirmation: boolean }>;
  requestPasswordReset: (email: string) => Promise<string | null>;
  setNewPassword: (password: string) => Promise<string | null>;
  createWorkspace: (name: string) => Promise<string | null>;
  signOut: () => Promise<void>;
  reload: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function friendly(message: string): string {
  const m = message.toLowerCase();
  if (m.includes('invalid login credentials')) return 'E-mail ou senha incorretos.';
  if (m.includes('email not confirmed')) return 'Confirme seu e-mail pelo link que enviamos antes de entrar.';
  if (m.includes('user already registered')) return 'Este e-mail já tem cadastro. Use "Entrar".';
  if (m.includes('password should be at least')) return 'A senha precisa ter pelo menos 8 caracteres.';
  if (m.includes('rate limit')) return 'Muitas tentativas. Aguarde alguns minutos e tente de novo.';
  if (m.includes('already_member')) return 'Esta conta já pertence a um workspace.';
  if (m.includes('email_not_confirmed')) return 'Confirme seu e-mail antes de criar o workspace.';
  if (m.includes('invited')) return 'Seu e-mail foi convidado para um workspace. Saia e entre novamente para aceitar o convite.';
  if (m.includes('invalid_name')) return 'Informe um nome entre 2 e 80 caracteres.';
  return message;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [state, setState] = useState<AuthState>({ status: 'loading' });
  const [recovery, setRecovery] = useState(false);
  const [tick, setTick] = useState(0);

  // Sessão: o callback só guarda o estado (chamar o Supabase aqui dentro pode travar o cliente).
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setInitialized(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      if (event === 'PASSWORD_RECOVERY') setRecovery(true);
      setSession(s);
      setInitialized(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const userId = session?.user.id ?? null;
  const email = session?.user.email ?? '';

  // Com sessão: vincula ao convite (claim_profile) e carrega perfil + workspace.
  useEffect(() => {
    if (!initialized) return;
    if (!userId) { setState({ status: 'signed_out' }); return; }

    let cancelled = false;
    (async () => {
      const claim = await supabase.rpc('claim_profile');
      if (cancelled) return;
      if (claim.error) { setState({ status: 'error', message: friendly(claim.error.message) }); return; }

      const profile = (claim.data as Profile[] | null)?.[0];
      if (!profile) { setState({ status: 'no_workspace', email }); return; }

      const ws = await supabase.from('workspaces').select('*').eq('id', profile.workspace_id).maybeSingle();
      if (cancelled) return;
      if (ws.error || !ws.data) {
        setState({ status: 'error', message: ws.error ? friendly(ws.error.message) : 'Workspace não encontrado.' });
        return;
      }
      setState({ status: 'ready', email, profile, workspace: ws.data as Workspace });
    })();
    return () => { cancelled = true; };
  }, [initialized, userId, email, tick]);

  const signIn = useCallback(async (e: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email: e.trim(), password });
    return error ? friendly(error.message) : null;
  }, []);

  const signUp = useCallback(async (name: string, e: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({
      email: e.trim(),
      password,
      options: { data: { name: name.trim() }, emailRedirectTo: window.location.origin },
    });
    if (error) return { error: friendly(error.message), needsConfirmation: false };
    // sem sessão = o projeto exige confirmação de e-mail (o correto)
    return { error: null, needsConfirmation: !data.session };
  }, []);

  const requestPasswordReset = useCallback(async (e: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(e.trim(), { redirectTo: window.location.origin });
    return error ? friendly(error.message) : null;
  }, []);

  const setNewPassword = useCallback(async (password: string) => {
    const { error } = await supabase.auth.updateUser({ password });
    if (!error) setRecovery(false);
    return error ? friendly(error.message) : null;
  }, []);

  const createWorkspace = useCallback(async (name: string) => {
    const { error } = await supabase.rpc('create_workspace', { p_name: name });
    if (error) return friendly(error.message);
    setTick(t => t + 1);
    return null;
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setRecovery(false);
  }, []);

  const reload = useCallback(() => setTick(t => t + 1), []);

  const value = useMemo<AuthContextValue>(
    () => ({ state, recovery, signIn, signUp, requestPasswordReset, setNewPassword, createWorkspace, signOut, reload }),
    [state, recovery, signIn, signUp, requestPasswordReset, setNewPassword, createWorkspace, signOut, reload]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth precisa estar dentro de <AuthProvider>');
  return ctx;
}

/** Só pode ser usado DENTRO do app autenticado (depois do gate em App.tsx). */
export function useSession() {
  const { state } = useAuth();
  if (state.status !== 'ready') throw new Error('useSession usado fora de uma sessão autenticada');
  const { profile, workspace } = state;
  return {
    profile,
    workspace,
    role: profile.role,
    isAdmin: profile.role === 'admin',
    isManager: profile.role === 'admin' || profile.role === 'gestor',
  };
}
