export type Channel = 'whatsapp' | 'instagram' | 'site_chat' | 'email' | 'telegram';
export type ConversationStatus = 'aberta' | 'em_atendimento' | 'aguardando' | 'resolvida';
export type Temperature = 'frio' | 'morno' | 'quente';

export interface Workspace {
  id: string;
  name: string;
  slug: string;
  plan: string;
  status: string;
  trial_ends_at: string | null;
  primary_color: string | null;
  timezone: string | null;
  infinitepay_handle: string | null;
}

export interface Profile {
  id: string;
  workspace_id: string;
  name: string;
  email: string;
  role: 'admin' | 'gestor' | 'atendente';
  avatar_url: string | null;
  is_active: boolean | null;
  /** null = convite ainda não aceito (a pessoa nunca entrou) */
  auth_user_id: string | null;
}

export interface Contact {
  id: string;
  workspace_id: string;
  name: string;
  phone: string | null;
  email: string | null;
  channel: Channel;
  avatar_url: string | null;
  tags: string[] | null;
  stage_id: string | null;
  deal_value: number | null;
  company: string | null;
  notes: string | null;
  owner_id: string | null;
  ai_paused: boolean;
  created_at: string;
}

export interface Conversation {
  id: string;
  workspace_id: string;
  contact_id: string;
  channel: Channel;
  status: ConversationStatus;
  unread_count: number;
  assignee_id: string | null;
  ai_paused: boolean;
  last_message_at: string;
  last_message_preview: string | null;
  is_pinned: boolean | null;
  created_at: string;
}

export interface Message {
  id: string;
  workspace_id: string;
  conversation_id: string;
  sender_type: 'contact' | 'agent' | 'ai' | 'system';
  sender_id: string | null;
  sender_name: string | null;
  content: string | null;
  message_type: 'text' | 'audio' | 'image' | 'video' | 'document' | 'system' | 'note';
  attachment_url: string | null;
  duration_seconds: number | null;
  is_note: boolean;
  read_at: string | null;
  created_at: string;
}

export interface QuickReply {
  id: string;
  workspace_id: string;
  shortcut: string;
  title: string;
  content: string;
  use_count: number | null;
}

export interface Pipeline {
  id: string;
  workspace_id: string;
  name: string;
  is_default: boolean | null;
}

export interface Stage {
  id: string;
  workspace_id: string;
  pipeline_id: string;
  name: string;
  color: string;
  position: number;
  is_won: boolean | null;
  is_lost: boolean | null;
}

export interface Deal {
  id: string;
  workspace_id: string;
  pipeline_id: string;
  stage_id: string;
  contact_id: string | null;
  title: string;
  value: number;
  temperature: Temperature;
  source: string | null;
  owner_id: string | null;
  next_task: string | null;
  next_task_at: string | null;
  lost_reason: string | null;
  utm_source: string | null;
  utm_campaign: string | null;
  utm_medium: string | null;
  position: number | null;
  closed_at: string | null;
  created_at: string;
}

export interface DealActivity {
  id: string;
  workspace_id: string;
  deal_id: string;
  user_id: string | null;
  activity_type: 'note' | 'call' | 'meeting' | 'follow_up' | 'stage_change' | 'payment' | 'ai_action';
  title: string;
  description: string | null;
  created_at: string;
}

export interface AiAgent {
  id: string;
  workspace_id: string;
  name: string;
  goal: 'sdr' | 'suporte' | 'agendamento' | 'fechamento';
  persona: string | null;
  tone: string | null;
  restrictions: string | null;
  knowledge_base: string | null;
  tools: { name: string; description: string }[] | null;
  is_active: boolean | null;
  working_hours: string | null;
  response_delay_seconds: number | null;
  conversations_handled: number | null;
  resolution_rate: number | null;
  created_at: string;
}

export interface AutomationNode {
  type: 'trigger' | 'action' | 'condition' | 'delay';
  label: string;
  config?: string;
  yes?: string;
  no?: string;
}

export interface Automation {
  id: string;
  workspace_id: string;
  name: string;
  description: string | null;
  trigger_type: 'nova_mensagem' | 'palavra_chave' | 'comentario_instagram' | 'etapa_funil' | 'webhook' | 'agendamento';
  trigger_config: Record<string, unknown> | null;
  nodes: AutomationNode[] | null;
  is_active: boolean | null;
  runs_count: number | null;
  last_run_at: string | null;
  created_at: string;
}

export interface Campaign {
  id: string;
  workspace_id: string;
  name: string;
  channel: string;
  template_name: string | null;
  template_content: string | null;
  segment_type: 'tag' | 'etapa_funil' | 'csv' | 'todos';
  segment_config: Record<string, unknown> | null;
  status: 'rascunho' | 'agendada' | 'em_andamento' | 'concluida' | 'pausada';
  scheduled_at: string | null;
  batch_size: number | null;
  batch_interval_minutes: number | null;
  total_recipients: number;
  sent_count: number;
  delivered_count: number;
  read_count: number;
  replied_count: number;
  failed_count: number;
  opt_out_count: number;
  created_at: string;
}

export interface Payment {
  id: string;
  workspace_id: string;
  deal_id: string | null;
  contact_id: string | null;
  amount: number;
  method: 'pix' | 'credit_card' | 'boleto' | 'checkout';
  status: 'pendente' | 'pago' | 'falhou' | 'estornado' | 'expirado';
  gateway: string | null;
  payment_link: string | null;
  description: string | null;
  paid_at: string | null;
  expires_at: string | null;
  gateway_ref: string | null;
  receipt_url: string | null;
  paid_amount: number | null;
  created_at: string;
}

export interface LeadAttribution {
  id: string;
  workspace_id: string;
  contact_id: string;
  utm_source: string | null;
  utm_medium: string | null;
  utm_campaign: string | null;
  utm_content: string | null;
  utm_term: string | null;
  fbclid: string | null;
  gclid: string | null;
  channel: string | null;
  landing_page: string | null;
  event_type: 'primeiro_clique' | 'visita' | 'conversao' | 'venda';
  occurred_at: string;
}

export interface Webhook {
  id: string;
  workspace_id: string;
  name: string;
  url: string;
  events: string[] | null;
  is_active: boolean | null;
  last_delivery_at: string | null;
  last_status: string | null;
  created_at: string;
}

export interface ApiKey {
  id: string;
  workspace_id: string;
  name: string;
  key_prefix: string;
  key_masked: string;
  permissions: string[] | null;
  last_used_at: string | null;
  is_active: boolean | null;
  created_at: string;
}

export type AppointmentStatus = 'agendado' | 'confirmado' | 'compareceu' | 'faltou' | 'cancelado';

export interface Service {
  id: string;
  workspace_id: string;
  name: string;
  duration_minutes: number;
  price: number | null;
  is_active: boolean;
  created_at: string;
}

export interface Professional {
  id: string;
  workspace_id: string;
  name: string;
  is_active: boolean;
  created_at: string;
}

export interface AvailabilityRule {
  id: string;
  workspace_id: string;
  professional_id: string;
  /** 0 = domingo ... 6 = sábado */
  weekday: number;
  start_time: string;
  end_time: string;
}

export interface Appointment {
  id: string;
  workspace_id: string;
  contact_id: string;
  professional_id: string;
  service_id: string;
  starts_at: string;
  ends_at: string;
  status: AppointmentStatus;
  source: 'manual' | 'ia' | 'site';
  notes: string | null;
  created_at: string;
  contacts: { name: string; phone: string | null } | null;
  services: { name: string; duration_minutes: number } | null;
  professionals: { name: string } | null;
}

export interface Slot {
  professional_id: string;
  professional_name: string;
  starts_at: string;
  ends_at: string;
}
