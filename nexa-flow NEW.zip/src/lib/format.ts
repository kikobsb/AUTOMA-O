import type { Channel, ConversationStatus, Temperature } from './types';

export function formatCurrency(value: number | null | undefined): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value ?? 0);
}

export function formatCompactCurrency(value: number): string {
  if (Math.abs(value) >= 1_000_000) return `R$ ${(value / 1_000_000).toFixed(1).replace('.', ',')}M`;
  if (Math.abs(value) >= 1_000) return `R$ ${(value / 1_000).toFixed(1).replace('.', ',')}k`;
  return formatCurrency(value);
}

export function formatRelativeTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60_000);
  if (mins < 1) return 'agora';
  if (mins < 60) return `${mins} min`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d`;
  return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

export const channelLabels: Record<Channel, string> = {
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
  site_chat: 'Chat do Site',
  email: 'E-mail',
  telegram: 'Telegram',
};

export const channelColors: Record<Channel, string> = {
  whatsapp: '#25D366',
  instagram: '#E1306C',
  site_chat: '#0EA5E9',
  email: '#F59E0B',
  telegram: '#2AABEE',
};

export const statusLabels: Record<ConversationStatus, string> = {
  aberta: 'Aberta',
  em_atendimento: 'Em atendimento',
  aguardando: 'Aguardando',
  resolvida: 'Resolvida',
};

export const statusStyles: Record<ConversationStatus, string> = {
  aberta: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  em_atendimento: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  aguardando: 'bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300',
  resolvida: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
};

export const temperatureStyles: Record<Temperature, string> = {
  quente: 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300',
  morno: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  frio: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
};

export const temperatureLabels: Record<Temperature, string> = {
  quente: 'Quente',
  morno: 'Morno',
  frio: 'Frio',
};

export const sourceLabels: Record<string, string> = {
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
  site_chat: 'Chat do Site',
  email: 'E-mail',
  telegram: 'Telegram',
  google: 'Google',
  facebook: 'Facebook',
  indicacao: 'Indicação',
};

export function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase();
}

const avatarPalette = [
  'bg-rose-500', 'bg-amber-500', 'bg-emerald-500', 'bg-sky-500', 'bg-violet-500',
  'bg-pink-500', 'bg-teal-500', 'bg-orange-500', 'bg-indigo-500', 'bg-lime-600',
];

export function avatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  return avatarPalette[hash % avatarPalette.length];
}

export function initialsAvatar(name: string): string {
  return name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

export function formatMoney(v: number | null | undefined): string {
  if (v == null) return '—';
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
