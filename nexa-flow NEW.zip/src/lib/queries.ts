import { useEffect, useState } from 'react';
import { supabase } from './supabase';
export { supabase };
import type {
  AiAgent, ApiKey, Appointment, AvailabilityRule, Automation, Campaign, Contact, Conversation, Deal,
  DealActivity, LeadAttribution, Message, Payment, Pipeline, Professional, Profile, QuickReply,
  Service, Stage, Webhook, Workspace,
} from './types';

export function useWorkspaces() {
  return useQuery<Workspace>('workspaces', q => q.select('*').limit(1));
}
export function useProfiles() {
  return useQuery<Profile>('profiles', q => q.select('*').order('name'));
}
export function useContacts() {
  return useQuery<Contact>('contacts', q => q.select('*').order('name'));
}
export function useConversations() {
  return useQuery<Conversation>('conversations', q => q.select('*').order('last_message_at', { ascending: false }));
}
export function useMessages(conversationId: string | null) {
  return useQuery<Message>(
    'messages',
    q => q.select('*').eq('conversation_id', conversationId!).order('created_at'),
    { enabled: !!conversationId, deps: [conversationId] }
  );
}
export function useQuickReplies() {
  return useQuery<QuickReply>('quick_replies', q => q.select('*').order('shortcut'));
}
export function usePipelines() {
  return useQuery<Pipeline>('pipelines', q => q.select('*').order('name'));
}
export function useStages() {
  return useQuery<Stage>('stages', q => q.select('*').order('position'));
}
export function useDeals() {
  return useQuery<Deal>('deals', q => q.select('*').order('created_at', { ascending: false }));
}
export function useDealActivities(dealId: string | null) {
  return useQuery<DealActivity>(
    'deal_activities',
    q => q.select('*').eq('deal_id', dealId!).order('created_at', { ascending: false }),
    { enabled: !!dealId, deps: [dealId] }
  );
}
export function useAiAgents() {
  return useQuery<AiAgent>('ai_agents', q => q.select('*').order('name'));
}
export function useAutomations() {
  return useQuery<Automation>('automations', q => q.select('*').order('name'));
}
export function useCampaigns() {
  return useQuery<Campaign>('campaigns', q => q.select('*').order('created_at', { ascending: false }));
}
export function usePayments() {
  return useQuery<Payment>('payments', q => q.select('*').order('created_at', { ascending: false }));
}
export function useLeadAttributions() {
  return useQuery<LeadAttribution>('lead_attributions', q => q.select('*').order('occurred_at', { ascending: false }));
}
// O banco NEGA `select *` nestas duas tabelas de propósito: segredo de webhook e hash de chave
// nunca chegam ao navegador. Por isso as colunas são listadas explicitamente.
export function useWebhooks() {
  return useQuery<Webhook>('webhooks', q =>
    q.select('id, workspace_id, name, url, events, is_active, last_delivery_at, last_status, created_at').order('name'));
}
export function useApiKeys() {
  return useQuery<ApiKey>('api_keys', q =>
    q.select('id, workspace_id, name, key_prefix, key_masked, permissions, last_used_at, is_active, created_at').order('name'));
}
export function useServices() {
  return useQuery<Service>('services', q => q.select('*').order('name'));
}
export function useProfessionals() {
  return useQuery<Professional>('professionals', q => q.select('*').order('name'));
}
export function useAvailabilityRules() {
  return useQuery<AvailabilityRule>('availability_rules', q => q.select('*').order('weekday').order('start_time'));
}
export function useAppointments(fromIso: string, toIso: string) {
  return useQuery<Appointment>(
    'appointments',
    q => q
      .select('*, contacts(name, phone), services(name, duration_minutes), professionals(name)')
      .gte('starts_at', fromIso)
      .lt('starts_at', toIso)
      .order('starts_at'),
    { deps: [fromIso, toIso] }
  );
}

interface QueryOptions {
  enabled?: boolean;
  deps?: unknown[];
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type QueryBuilder = { [method: string]: (...args: any[]) => any };

function useQuery<T>(
  table: string,
  build: (q: QueryBuilder) => PromiseLike<{ data: unknown; error: unknown }>,
  options: QueryOptions = {}
) {
  const { enabled = true, deps = [] } = options;
  const [data, setData] = useState<T[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    Promise.resolve(build(supabase.from(table) as unknown as QueryBuilder))
      .then(({ data: rows, error: err }) => {
        if (cancelled) return;
        if (err) {
          setError(errorMessage(err));
          setData(null);
        } else {
          setData((rows as T[]) ?? []);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table, enabled, tick, ...deps]);

  return { data, loading, error, refetch: () => setTick(t => t + 1) };
}

export function errorMessage(err: unknown): string {
  if (err && typeof err === 'object' && 'message' in err && typeof (err as { message: unknown }).message === 'string') {
    return (err as { message: string }).message;
  }
  return 'Erro inesperado';
}
